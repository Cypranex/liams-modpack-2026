materialMask = OSIEBCA; // Intense Fresnel

float factor = GetLuminance(color.rgb) + 0.3;
float factor2 = pow2(factor);
float factor4 = pow2(factor2);

smoothnessG = factor - factor4 * 0.1;
highlightMult = 3.0 * factor2;

smoothnessD = factor4 * 0.75;

#ifdef COATED_TEXTURES
	noiseFactor = 0.5;
#endif
