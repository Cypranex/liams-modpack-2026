if (abs(materialMaskInt - 149.5) < 50.0) { // Entity Reflection Handling (see common.glsl for details)
    materialMaskInt -= 100;
    entityOrParticle = true;
}

if (materialMaskInt != 0) {
    if (materialMaskInt < 9) {
        if (materialMaskInt < 5) {
            if (materialMaskInt < 3) {
                if (materialMaskInt == 1) { // Intense Fresnel
                    intenseFresnel = 1.0;
                } else /*if (materialMaskInt == 2)*/ { // Copper Fresnel
                    intenseFresnel = 1.0;
                    reflectColor = mix(vec3(0.5, 0.75, 0.5), vec3(1.0, 0.45, 0.3), sqrt1(smoothnessD));
                }
            } else {
                if (materialMaskInt == 3) { // Gold Fresnel
                    intenseFresnel = 1.0;
                    reflectColor = vec3(1.0, 0.8, 0.5);
                } else /*if (materialMaskInt == 4)*/ { //

                }
            }
        } else {
            if (materialMaskInt < 7) {
                if (materialMaskInt == 5) { // Redstone Fresnel
                    intenseFresnel = 1.0;
                    reflectColor = vec3(1.0, 0.3, 0.2);
                } else /*if (materialMaskInt == 6)*/ { //

                }
            } else {
                if (materialMaskInt == 7) { //

                } else /*if (materialMaskInt == 8)*/ { //

                }
            }
        }
    } else {
        if (materialMaskInt < 13) {
            if (materialMaskInt < 11) {
                if (materialMaskInt == 9) { //

                } else /*if (materialMaskInt == 10)*/ { //

                }
            } else {
                if (materialMaskInt == 11) { //

                } else /*if (materialMaskInt == 12)*/ { //

                }
            }
        } else {
            if (materialMaskInt < 15) {
                if (materialMaskInt == 13) { //

                } else /*if (materialMaskInt == 14)*/ { //

                }
            } else {
                if (materialMaskInt == 15) { //

                } else { // materialMaskInt >= 16 && <= 240
                    if (materialMaskInt < 48) {
                        if (materialMaskInt < 32) {
                            if (materialMaskInt < 24) {
                                if (materialMaskInt < 20) {
                                    if (materialMaskInt < 18) {
                                        if (materialMaskInt < 17) {
                                            // necronium
                                            intenseFresnel = 1.0;
                                            reflectColor = vec3(0.75, 1.0, 0.88);
                                        } else /*if (materialMaskInt < 18)*/ {
                                            // sanguine
                                            intenseFresnel = 1.0;
                                            reflectColor = vec3(1.0, 0.5, 0.6);
                                        }
                                    } else /*if (materialMaskInt < 20)*/ {
                                        if (materialMaskInt < 19) {
                                            // tin
                                            intenseFresnel = 1.0;
                                            reflectColor = vec3(1.0, 0.88, 0.76);
                    
                                        } else /*if (materialMaskInt < 20)*/ {
                                            // stained_scrap
                                            intenseFresnel = 1.0;
                                            if (color.b > color.r) {
                                                reflectColor = vec3(0.5, 0.8, 1.0);
                                            } else {
                                                reflectColor = vec3(1.0, 0.1, 0.77);
                                            }
                                        }
                                    }
                                } else /*if (materialMaskInt < 24)*/ {
                                    if (materialMaskInt < 22) {
                                        if (materialMaskInt < 21) {
                                            // shadoline
                                            intenseFresnel = 1.0;
                                            reflectColor = vec3(0.5, 1.0, 0.9);
                                        } else /*if (materialMaskInt < 22)*/ {
                                            // electrum
                                            intenseFresnel = 1.0;
                                            reflectColor = vec3(1.0, 0.9, 0.6);
                                        }
                                    } else /*if (materialMaskInt < 24)*/ {
                                        if (materialMaskInt < 23) {
                                            // lead
                                            intenseFresnel = 1.0;
                                            reflectColor = vec3(0.66, 0.66, 1.0);
                                        } else /*if (materialMaskInt < 24)*/ {
                                            // pigsteel
                                            intenseFresnel = 1.0;
                                            reflectColor = vec3(1.0, 0.5, 0.88);
                                        }
                                    }
                                }
                            } else /*if (materialMaskInt < 32)*/ {
                                if (materialMaskInt < 28) {
                                    if (materialMaskInt < 26) {
                                        if (materialMaskInt < 25) {
                                            // blast_proof_plates
                                            intenseFresnel = 1.0;
                                            if (color.g > color.r) {
                                                reflectColor = vec3(0.75, 1.0, 0.5);
                                            } else {
                                                reflectColor = vec3(1.0, 0.85, 0.3);
                                            }
                                        } else /*if (materialMaskInt < 26)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 28)*/ {
                                        if (materialMaskInt < 27) {
                    
                                        } else /*if (materialMaskInt < 28)*/ {
                    
                                        }
                                    }
                                } else /*if (materialMaskInt < 32)*/ {
                                    if (materialMaskInt < 30) {
                                        if (materialMaskInt < 29) {
                    
                                        } else /*if (materialMaskInt < 30)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 32)*/ {
                                        if (materialMaskInt < 31) {
                    
                                        } else /*if (materialMaskInt < 32)*/ {
                    
                                        }
                                    }
                                }
                            }
                        } else /*if (materialMaskInt < 48)*/ {
                            if (materialMaskInt < 40) {
                                if (materialMaskInt < 36) {
                                    if (materialMaskInt < 34) {
                                        if (materialMaskInt < 33) {
                    
                                        } else /*if (materialMaskInt < 34)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 36)*/ {
                                        if (materialMaskInt < 35) {
                    
                                        } else /*if (materialMaskInt < 36)*/ {
                    
                                        }
                                    }
                                } else /*if (materialMaskInt < 40)*/ {
                                    if (materialMaskInt < 38) {
                                        if (materialMaskInt < 37) {
                    
                                        } else /*if (materialMaskInt < 38)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 40)*/ {
                                        if (materialMaskInt < 39) {
                    
                                        } else /*if (materialMaskInt < 40)*/ {
                    
                                        }
                                    }
                                }
                            } else /*if (materialMaskInt < 48)*/ {
                                if (materialMaskInt < 44) {
                                    if (materialMaskInt < 42) {
                                        if (materialMaskInt < 41) {
                    
                                        } else /*if (materialMaskInt < 42)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 44)*/ {
                                        if (materialMaskInt < 43) {
                    
                                        } else /*if (materialMaskInt < 44)*/ {
                    
                                        }
                                    }
                                } else /*if (materialMaskInt < 48)*/ {
                                    if (materialMaskInt < 46) {
                                        if (materialMaskInt < 45) {
                    
                                        } else /*if (materialMaskInt < 46)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 48)*/ {
                                        if (materialMaskInt < 47) {
                    
                                        } else /*if (materialMaskInt < 48)*/ {
                    
                                        }
                                    }
                                }
                            }
                        }
                    } else /*if (materialMaskInt < 80)*/ {
                        if (materialMaskInt < 64) {
                            if (materialMaskInt < 56) {
                                if (materialMaskInt < 52) {
                                    if (materialMaskInt < 50) {
                                        if (materialMaskInt < 49) {
                    
                                        } else /*if (materialMaskInt < 50)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 52)*/ {
                                        if (materialMaskInt < 51) {
                    
                                        } else /*if (materialMaskInt < 52)*/ {
                    
                                        }
                                    }
                                } else /*if (materialMaskInt < 56)*/ {
                                    if (materialMaskInt < 54) {
                                        if (materialMaskInt < 53) {
                    
                                        } else /*if (materialMaskInt < 54)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 56)*/ {
                                        if (materialMaskInt < 55) {
                    
                                        } else /*if (materialMaskInt < 56)*/ {
                    
                                        }
                                    }
                                }
                            } else /*if (materialMaskInt < 64)*/ {
                                if (materialMaskInt < 60) {
                                    if (materialMaskInt < 58) {
                                        if (materialMaskInt < 57) {
                    
                                        } else /*if (materialMaskInt < 58)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 60)*/ {
                                        if (materialMaskInt < 59) {
                    
                                        } else /*if (materialMaskInt < 60)*/ {
                    
                                        }
                                    }
                                } else /*if (materialMaskInt < 64)*/ {
                                    if (materialMaskInt < 62) {
                                        if (materialMaskInt < 61) {
                    
                                        } else /*if (materialMaskInt < 62)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 64)*/ {
                                        if (materialMaskInt < 63) {
                    
                                        } else /*if (materialMaskInt < 64)*/ {
                    
                                        }
                                    }
                                }
                            }
                        } else /*if (materialMaskInt < 80)*/ {
                            if (materialMaskInt < 72) {
                                if (materialMaskInt < 68) {
                                    if (materialMaskInt < 66) {
                                        if (materialMaskInt < 65) {
                    
                                        } else /*if (materialMaskInt < 66)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 68)*/ {
                                        if (materialMaskInt < 67) {
                    
                                        } else /*if (materialMaskInt < 68)*/ {
                    
                                        }
                                    }
                                } else /*if (materialMaskInt < 72)*/ {
                                    if (materialMaskInt < 70) {
                                        if (materialMaskInt < 69) {
                    
                                        } else /*if (materialMaskInt < 70)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 72)*/ {
                                        if (materialMaskInt < 71) {
                    
                                        } else /*if (materialMaskInt < 72)*/ {
                    
                                        }
                                    }
                                }
                            } else /*if (materialMaskInt < 80)*/ {
                                if (materialMaskInt < 76) {
                                    if (materialMaskInt < 74) {
                                        if (materialMaskInt < 73) {
                    
                                        } else /*if (materialMaskInt < 74)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 76)*/ {
                                        if (materialMaskInt < 75) {
                    
                                        } else /*if (materialMaskInt < 76)*/ {
                    
                                        }
                                    }
                                } else /*if (materialMaskInt < 80)*/ {
                                    if (materialMaskInt < 78) {
                                        if (materialMaskInt < 77) {
                    
                                        } else /*if (materialMaskInt < 78)*/ {
                    
                                        }
                                    } else /*if (materialMaskInt < 80)*/ {
                                        if (materialMaskInt < 79) {
                    
                                        } else /*if (materialMaskInt < 80)*/ {
                    
                                        }
                                    }
                                }
                            }
                        }
                    }
                    

                }
            }
        }
    }
}
