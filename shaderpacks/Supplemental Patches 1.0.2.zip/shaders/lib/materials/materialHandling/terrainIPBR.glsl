#include "/lib/shaderSettings/materials.glsl"
#include "/lib/shaderSettings/water.glsl"
#include "/lib/shaderSettings/blueScreen.glsl"
#include "/lib/shaderSettings/emissiveFlowers.glsl"

if (mat >= 10000) {
if (mat < 11024) {
    if (mat < 10512) {
        if (mat < 10256) {
            if (mat < 10126) { // MV: Normal Mycelium
                if (mat < 10064) {
                    if (mat < 10032) {
                        if (mat < 10014) { // MV: Foliage
                            if (mat < 10006) { // MV: Leaves
                                if (mat < 10002) { // No directional shading, MV: Flowers
                                    noDirectionalShading = true;

                                    sandNoiseIntensity = 0.4, mossNoiseIntensity = 0.0, isFoliage = true;
                                }
                                else /*if (mat < 10006)*/ { // Grounded Waving Foliage
                                    subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

                                    #if defined GBUFFERS_TERRAIN || defined VOXY_PATCH
                                        DoFoliageColorTweaks(color.rgb, shadowMult, snowMinNdotU, viewPos, nViewPos, lViewPos, dither);

                                        #ifdef COATED_TEXTURES
                                            doTileRandomisation = false;
                                        #endif
                                    #endif

                                    #if SHADOW_QUALITY == -1 && !defined VOXY_PATCH
                                        shadowMult *= 1.0 - 0.3 * (signMidCoordPos.y + 1.0) * (1.0 - abs(signMidCoordPos.x))
                                        + 0.5 * (1.0 - signMidCoordPos.y) * invNoonFactor; // consistency357381
                                    #endif

                                    sandNoiseIntensity = 0.8, mossNoiseIntensity = 0.0, isFoliage = true;

                                    #if EMISSIVE_FLOWERS > 0 || defined EMISSIVE_BLOOD_MOON_FLOWERS
                                        if (mat == 10003 && isNonGreen(color.rgb)) { // Flowers
                                            emission = 2.0 * skyLightCheck;
                                            #if EMISSIVE_FLOWERS == 2
                                                emission = max(emission, rainFactor + 1.0 * rainFactor);
                                            #endif
                                            #if EMISSIVE_FLOWERS > 0
                                                #if EMISSIVE_FLOWERS_TYPE == 1
                                                    if (color.b < max(color.r, color.g * 1.1) * 0.95) emission = 0.0;
                                                #elif EMISSIVE_FLOWERS_TYPE == 2
                                                    if (color.r < max(color.b * 1.15, color.g * 1.1) * 0.95) emission = 0.0;
                                                #endif
                                            #else
                                                emission = int(color.r > max(color.b * 1.15, color.g * 2.5) * 0.95) * getBloodMoon(sunVisibility);
                                            #endif
                                            emission *= EMISSIVE_FLOWERS_STRENGTH;
                                        }
                                    #endif
                                }
                            } else {
                                if (mat < 10013) { // Leaves
                                    #include "/lib/materials/specificMaterials/terrain/leaves.glsl"

                                    #if EMISSIVE_FLOWERS > 0 && EMISSIVE_FLOWERS_TYPE < 2
                                        if ((mat == 10011 || mat == 10012) && isNonGreen(color.rgb)) { // Flowering Azalea Leaves
                                            emission = skyLightCheck;

                                            #if EMISSIVE_FLOWERS == 2
                                                emission = max(emission, rainFactor + 1.0 * rainFactor);
                                            #endif
                                            emission *= EMISSIVE_FLOWERS_STRENGTH;
                                        }
                                    #endif
                                    #ifdef PINKER_CHERRY_LEAVES
                                        if (mat == 10007 && color.b > 0.5 && color.r > 0.85) {
                                            color.rgb *= vec3(1.0, 0.66, 0.87) + 0.2;
                                            color.rgb = clamp01(color.rgb);
                                        }
                                    #endif
                                }
                                // else /*if (mat < 10014)*/ { //

                                // }
                            }
                        } else {
                            if (mat < 10024) {
                                if (mat < 10020) { // Non-waving Foliage
                                    subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0, isFoliage = true;
                                    if (mat == 10019) {
                                        #if EMISSIVE_FLOWERS > 0 && EMISSIVE_FLOWERS_TYPE < 2
                                            if (isNonGreen(vec3(color.r * 0.97, color.g, color.b * 1.23))) { // Flowers
                                                emission = 1.5 * skyLightCheck;

                                                #if EMISSIVE_FLOWERS == 2
                                                    emission = max(emission, rainFactor + 1.0 * rainFactor);
                                                #endif
                                                emission *= EMISSIVE_FLOWERS_STRENGTH;
                                            }
                                        #endif
                                        #ifdef PINKER_CHERRY_LEAVES
                                            if (color.b > 0.5 && color.r > 0.85) color.rgb *= vec3(1.0, 0.87, 0.97); // Pink Petals
                                        #endif
                                    }
                                }
                                else /*if (mat < 10024)*/ { // Upper Waving Foliage
                                    subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

                                    #if defined GBUFFERS_TERRAIN || defined VOXY_PATCH
                                        DoFoliageColorTweaks(color.rgb, shadowMult, snowMinNdotU, viewPos, nViewPos, lViewPos, dither);

                                        #ifdef COATED_TEXTURES
                                            doTileRandomisation = false;
                                        #endif
                                    #endif

                                    #if SHADOW_QUALITY == -1 && !defined VOXY_PATCH
                                        shadowMult *= 1.0 + invNoonFactor; // consistency357381
                                    #endif

                                    sandNoiseIntensity = 0.8, mossNoiseIntensity = 0.0, isFoliage = true;

                                    #if EMISSIVE_FLOWERS > 0 || defined EMISSIVE_BLOOD_MOON_FLOWERS
                                        if (mat == 10023 && isNonGreen(color.rgb)) { // Large Flowers Upper Half
                                            #if EMISSIVE_FLOWERS > 0
                                                emission = 2.0 * skyLightCheck;
                                                #if EMISSIVE_FLOWERS == 2
                                                    emission = max(emission, rainFactor + 1.0 * rainFactor);
                                                #endif
                                                #if EMISSIVE_FLOWERS_TYPE == 1
                                                    if (color.b < max(color.r, color.g * 1.1) * 0.95) emission = 0.0;
                                                #elif EMISSIVE_FLOWERS_TYPE == 2
                                                    if (color.r < max(color.b * 1.15, color.g * 1.1) * 0.95) emission = 0.0;
                                                #endif
                                            #else
                                                emission = int(color.r > max(color.b * 1.15, color.g * 2.5) * 0.95) * getBloodMoon(sunVisibility);
                                            #endif
                                            emission *= EMISSIVE_FLOWERS_STRENGTH;
                                        }
                                    #endif
                                }
                            } else {
                                if (mat < 10025) { // Auto Modded Ores - Stone
                                    #if defined GLOWING_ORE_MODDED && !defined VOXY_PATCH
                                        #include "/lib/materials/specificMaterials/terrain/autoModdedOres.glsl"
                                        if (emission < 0.1) {
                                            #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                        }
                                        emission *= GLOWING_ORE_MULT;
                                        //color.rgb = avgBorderColor;

                                        #ifdef SITUATIONAL_ORES
                                            emission *= skyLightCheck;
                                        #endif
                                    #endif
                                } else if (mat < 10026) {  // Short Foliage / Foliage Lower Half - No Subsurface Scattering
                                    noSmoothLighting = true;

                                    #if defined GBUFFERS_TERRAIN || defined VOXY_PATCH
                                        DoFoliageColorTweaks(color.rgb, shadowMult, snowMinNdotU, viewPos, nViewPos, lViewPos, dither);
                                    #endif

                                    #if SHADOW_QUALITY == -1 && !defined VOXY_PATCH
                                        shadowMult *= 1.0 - 0.3 * (signMidCoordPos.y + 1.0) * (1.0 - abs(signMidCoordPos.x))
                                        + 0.5 * (1.0 - signMidCoordPos.y) * invNoonFactor; // consistency357381
                                    #endif

                                    sandNoiseIntensity = 0.8, mossNoiseIntensity = 0.0, isFoliage = true;

                                } else if (mat < 10027) { // Auto Modded Ores - Netherrack
                                    #if defined GLOWING_ORE_MODDED && !defined VOXY_PATCH
                                        #include "/lib/materials/specificMaterials/terrain/autoModdedOres.glsl"
                                        if (emission < 0.1) {
                                            #include "/lib/materials/specificMaterials/terrain/netherrack.glsl"
                                        }
                                        emission *= GLOWING_ORE_MULT;
                                        //color.rgb = avgBorderColor;

                                        #ifdef SITUATIONAL_ORES
                                            emission *= skyLightCheck;
                                        #endif
                                    #endif
                                } else if (mat < 10028) { // Tall Foliage / Foliage Upper Half - No Subsurface Scattering
                                    noSmoothLighting = true;

                                    #if defined GBUFFERS_TERRAIN || defined VOXY_PATCH
                                        DoFoliageColorTweaks(color.rgb, shadowMult, snowMinNdotU, viewPos, nViewPos, lViewPos, dither);
                                    #endif

                                    #if SHADOW_QUALITY == -1 && !defined VOXY_PATCH
                                        shadowMult *= 1.0 + invNoonFactor; // consistency357381
                                    #endif

                                    sandNoiseIntensity = 0.8, mossNoiseIntensity = 0.0, isFoliage = true;

                                } else if (mat < 10029) { // Auto Modded Ores - Endstone
                                    #if defined GLOWING_ORE_MODDED && !defined VOXY_PATCH
                                        #include "/lib/materials/specificMaterials/terrain/autoModdedOres.glsl"
                                        if (emission < 0.1) {
                                            #include "/lib/materials/specificMaterials/terrain/endStone.glsl"
                                        }
                                        emission *= GLOWING_ORE_MULT;
                                        //color.rgb = avgBorderColor;

                                        #ifdef SITUATIONAL_ORES
                                            emission *= skyLightCheck;
                                        #endif
                                    #endif
                                } else if (mat < 10030) { // Crimson Roots
                                    subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

                                    #if defined GBUFFERS_TERRAIN || defined VOXY_PATCH
                                        DoFoliageColorTweaks(color.rgb, shadowMult, snowMinNdotU, viewPos, nViewPos, lViewPos, dither);
                                    #endif

                                    #if SHADOW_QUALITY == -1 && !defined VOXY_PATCH
                                        shadowMult *= 1.0 - 0.3 * (signMidCoordPos.y + 1.0) * (1.0 - abs(signMidCoordPos.x))
                                        + 0.5 * (1.0 - signMidCoordPos.y) * invNoonFactor; // consistency357381
                                    #endif

                                    #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                        color.rgb = mix(color.rgb, saturateColors(color.rgb * vec3(0.9, 0.7, 0.1), 0.85), inSoulValley); // Color curve to make it look better
                                    #endif

                                    sandNoiseIntensity = 0.8, mossNoiseIntensity = 0.0, isFoliage = true;
                                } else if (mat < 10032) { // Short foliage - no interactive foliage
                                    subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

                                    #if defined GBUFFERS_TERRAIN || defined VOXY_PATCH
                                        DoFoliageColorTweaks(color.rgb, shadowMult, snowMinNdotU, viewPos, nViewPos, lViewPos, dither);

                                        #ifdef COATED_TEXTURES
                                            doTileRandomisation = false;
                                        #endif
                                    #endif

                                    #if SHADOW_QUALITY == -1 && !defined VOXY_PATCH
                                        shadowMult *= 1.0 - 0.3 * (signMidCoordPos.y + 1.0) * (1.0 - abs(signMidCoordPos.x))
                                        + 0.5 * (1.0 - signMidCoordPos.y) * invNoonFactor; // consistency357381
                                    #endif

                                    sandNoiseIntensity = 0.8, mossNoiseIntensity = 0.0, isFoliage = true;
                                }
                            }
                        }
                    } else {
                        if (mat < 10048) {
                            if (mat < 10040) {
                                if (mat < 10036) { // Stone Bricks++
                                    #include "/lib/materials/specificMaterials/terrain/stone.glsl"

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
                                }
                                else if (mat < 10038){ // Anvil+
                                    #include "/lib/materials/specificMaterials/terrain/anvil.glsl"
                                }
                                else /*if (mat < 10040)*/ { // Sugar Cane
                                    subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0, isFoliage = true;
                                }
                            } else {
                                if (mat < 10044) { // Rails
                                    color = texture2DLod(tex, texCoord, 0);

                                    noSmoothLighting = true;
                                    if (color.r > 0.1 && color.g + color.b < 0.1) { // Redstone Parts
                                        noSmoothLighting = true; noDirectionalShading = true;
                                        lmCoordM.x = min(lmCoordM.x * 0.9, 0.77);

                                        if (color.r > 0.5) {
                                            color.rgb *= color.rgb;
                                            emission = 8.0 * color.r;

                                            overlayNoiseIntensity = 0.35, overlayNoiseEmission = 0.2;
                                        } else if (color.r > color.g * 2.0) {
                                            materialMask = OSIEBCA * 5.0; // Redstone Fresnel

                                            float factor = pow2(color.r);
                                            smoothnessG = 0.4;
                                            highlightMult = factor + 0.4;

                                            smoothnessD = factor * 0.7 + 0.3;
                                        }
                                    } else if (abs(color.r - color.b) < 0.15) { // Iron Parts
                                        #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                                    } else if (color.g > color.b * 2.0) { // Gold Parts
                                        #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                                    } else { // Wood Parts
                                        #include "/lib/materials/specificMaterials/planks/oakPlanks.glsl"
                                    }
                                }
                                else /*if (mat < 10048)*/ { // Empty Cauldron, Hopper
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.9333);

                                    #include "/lib/materials/specificMaterials/terrain/anvil.glsl"

                                    if (mat == 10047) { // Disabled Hopper
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        } else {
                            if (mat < 10056) {
                                if (mat < 10052) { // Water Cauldron
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.9333);

                                    vec3 worldPos = playerPos + cameraPosition;
                                    vec3 fractPos = fract(worldPos.xyz);
                                    vec2 coordM = abs(fractPos.xz - 0.5);
                                    bool cauldronInteriorCheck = (max(coordM.x, coordM.y) < 0.375 && fractPos.y > 0.3);
                                    #ifdef GBUFFERS_COLORWHEEL
                                        vec2 centered = abs(fract(texCoord));
                                        cauldronInteriorCheck = max(centered.x, centered.y) > 0.9;
                                    #endif
                                    if (cauldronInteriorCheck && NdotU > 0.9) {
                                        #ifdef SHADER_WATER
                                            #if WATER_STYLE < 3 || PIXEL_WATER == 1
                                                vec3 colorP = color.rgb / glColor.rgb;
                                                smoothnessG = min(pow2(pow2(dot(colorP.rgb, colorP.rgb) * 0.4)), 1.0);
                                                highlightMult = 3.25;
                                                smoothnessD = 0.8;
                                            #else
                                                smoothnessG = 0.3;
                                                smoothnessD = 1.0;
                                            #endif

                                            #ifdef GBUFFERS_TERRAIN
                                                #ifdef WATER_CAULDRON_COLOR_OVERRIDE
                                                    #undef WATERCOLOR_CHANGED
                                                #endif
                                                #include "/lib/materials/specificMaterials/translucents/water.glsl"
                                            #endif

                                            #ifdef COATED_TEXTURES
                                                noiseFactor = 0.0;
                                            #endif
                                        #endif

                                        overlayNoiseIntensity = 0.0;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/anvil.glsl"
                                    }
                                }
                                else /*if (mat < 10056)*/ { // Powder Snow Cauldron
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.9333);

                                    vec3 worldPos = playerPos + cameraPosition;
                                    vec3 fractPos = fract(worldPos.xyz);
                                    vec2 coordM = abs(fractPos.xz - 0.5);
                                    bool cauldronInteriorCheck = (max(coordM.x, coordM.y) < 0.375 && fractPos.y > 0.3);
                                    #ifdef GBUFFERS_COLORWHEEL
                                        vec2 centered = abs(fract(texCoord));
                                        cauldronInteriorCheck = max(centered.x, centered.y) > 0.9;
                                    #endif
                                    if (cauldronInteriorCheck && NdotU > 0.9) {

                                        #include "/lib/materials/specificMaterials/terrain/snow.glsl"

                                        overlayNoiseIntensity = 0.4;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/anvil.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10060) { // Lava Cauldron
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.9333);

                                    vec3 worldPos = playerPos + cameraPosition;
                                    vec3 fractPos = fract(worldPos.xyz);
                                    vec2 coordM = abs(fractPos.xz - 0.5);
                                    bool cauldronInteriorCheck = (max(coordM.x, coordM.y) < 0.375 && fractPos.y > 0.3);
                                    #ifdef GBUFFERS_COLORWHEEL
                                        vec2 centered = abs(fract(texCoord));
                                        cauldronInteriorCheck = max(centered.x, centered.y) > 0.9;
                                    #endif

                                    if (cauldronInteriorCheck && NdotU > 0.9) {

                                        #include "/lib/materials/specificMaterials/terrain/lava.glsl"

                                        sandNoiseIntensity = 0.0, mossNoiseIntensity = 0.0;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/anvil.glsl"
                                    }
                                }
                                else /*if (mat < 10061)*/ { // Lever
                                    if (color.r > color.g + color.b) {
                                        color.rgb *= color.rgb;
                                        emission = 4.0;

                                        overlayNoiseIntensity = 0.1, overlayNoiseEmission = 0.3;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10096) {
                        if (mat < 10080) {
                            if (mat < 10072) {
                                if (mat < 10068) { // Lectern
                                    #include "/lib/materials/specificMaterials/planks/oakPlanks.glsl"
                                }
                                else /*if (mat < 10072)*/ { // Lava
                                    #include "/lib/materials/specificMaterials/terrain/lava.glsl"

                                    #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                        doTileRandomisation = false;
                                    #endif

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 4.5, lViewPos);
                                    #endif

                                    sandNoiseIntensity = 0.0, mossNoiseIntensity = 0.0;
                                }
                            } else {
                                if (mat < 10076) { // Fire
                                    noSmoothLighting = true, noDirectionalShading = true;
                                    emission = 2.35;
                                    color.rgb *= sqrt1(GetLuminance(color.rgb));

                                    overlayNoiseIntensity = 0.0;

                                    #if (defined SOUL_SAND_VALLEY_OVERHAUL_INTERNAL || defined PURPLE_END_FIRE_INTERNAL) && defined GBUFFERS_TERRAIN
                                        float uniformValue = 1.0;
                                        vec3 colorFire = vec3(0.0);
                                        #ifdef NETHER
                                            uniformValue = inSoulValley;
                                            colorFire = colorSoul;
                                            float gradient = mix(1.0, 0.0, clamp01(blockUV.y + 3.0 * blockUV.y));
                                        #endif
                                        #ifdef END
                                            uniformValue = 1.0;
                                            colorFire = colorEndBreath * 1.5;
                                            float gradient = mix(1.0, 0.0, clamp01(blockUV.y + 0.15 - 1.1 * clamp01(sin(texture2DLod(noisetex, vec2(frameTimeCounter * 0.01), 0.0).r) * blockUV.y)));
                                        #endif
                                        color.rgb = mix(color.rgb, mix(color.rgb, vec3(GetLuminance(color.rgb)), 0.88), uniformValue * gradient);
                                        color.rgb *= mix(vec3(1.0), colorFire * 2.0, uniformValue * gradient);
                                    #endif
                                } else {
                                    if (mat < 10079) { // Soul Fire
                                        noSmoothLighting = true, noDirectionalShading = true;
                                        emission = 1.5;
                                        color.rgb = pow1_5(color.rgb);

                                        overlayNoiseIntensity = 0.0;
                                    } else /*if (mat < 10080)*/{ // Powered Stone Pressure Plate and Stone Button
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                        redstoneIPBR(color.rgb, emission);
                                    }

                                }
                            }
                        } else {
                            if (mat < 10088) {
                                if (mat < 10084) { // Stone+, Coal Ore, Smooth Stone+, Grindstone, Stonecutter
                                    #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                }
                                else /*if (mat < 10088)*/ { // Granite+
                                    smoothnessG = pow2(pow2(color.r)) * 0.75;
                                    smoothnessD = smoothnessG;
                                }
                            } else {
                                if (mat < 10092) { // Diorite+
                                    smoothnessG = pow2(pow2(color.g)) * 0.5;
                                    smoothnessD = smoothnessG;

                                    #ifdef GBUFFERS_TERRAIN
                                        DoBrightBlockTweaks(color.rgb, 0.75, shadowMult, highlightMult);
                                    #endif
                                }
                                else /*if (mat < 10096)*/ { // Andesite+
                                    smoothnessG = pow2(pow2(color.g)) * 1.3;
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;
                                }
                            }
                        }
                    } else {
                        if (mat < 10112) {
                            if (mat < 10104) {
                                if (mat < 10100) { // Polished Granite+
                                    smoothnessG = 0.1 + color.r * 0.4;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                                else /*if (mat < 10104)*/ { // Polished Diorite+
                                    smoothnessG = pow2(color.g) * 0.7;
                                    smoothnessD = smoothnessG;

                                    #ifdef GBUFFERS_TERRAIN
                                        DoBrightBlockTweaks(color.rgb, 0.75, shadowMult, highlightMult);
                                    #endif

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                            } else {
                                if (mat < 10108) { // Polished Andesite+, Packed Mud, Mud Bricks+, Bricks+
                                    smoothnessG = pow2(color.g);
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                                else /*if (mat < 10112)*/ { // Deepslate:Non-polished Variants, Deepslate Coal Ore
                                    #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                }
                            }
                        } else {
                            if (mat < 10120) {
                                if (mat < 10116) { // Deepslate:Polished Variants, Mud, Mangrove Roots, Muddy Mangrove Roots
                                    #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                                else /*if (mat < 10120)*/ { // Calcite
                                    highlightMult = pow2(color.g) + 1.0;
                                    smoothnessG = 1.0 - color.g * 0.5;
                                    smoothnessD = smoothnessG;

                                    #ifdef GBUFFERS_TERRAIN
                                        DoBrightBlockTweaks(color.rgb, 0.75, shadowMult, highlightMult);
                                    #endif
                                }
                            } else {
                                if (mat < 10124) { // Dripstone+, Daylight Detector
                                    smoothnessG = pow2(GetLuminance(color.rgb)) * 0.9 + 0.1;
                                    smoothnessD = smoothnessG;

                                    if (mat == 10123) { // Pointed Dripstone
                                        noDirectionalShading = true;
                                    }

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif

                                    #ifdef REDSTONE_IPBR
                                        if (mat == 10121) { // Daylight Detector
                                            if (color.r > 0.5 && color.g > 0.5 && color.b > 0.5) smoothnessD = 1.0;
                                            redstoneIPBR(color.rgb, emission);
                                        }
                                    #endif
                                }
                                else /*if (mat < 10128)*/ { // Snowy Variants of Grass Block, Podzol, Mycelium
                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (dotColor > 1.5) { // Snowy Variants:Snowy Part
                                        #include "/lib/materials/specificMaterials/terrain/snow.glsl"

                                        overlayNoiseIntensity = 0.0;
                                    } else { // Snowy Variants:Dirt Part
                                        #include "/lib/materials/specificMaterials/terrain/dirt.glsl"
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (mat < 10192) {
                    if (mat < 10160) {
                        if (mat < 10144) {
                            if (mat < 10136) {
                                if (mat < 10132) { // Dirt, Coarse Dirt, Rooted Dirt, Podzol:Normal, Mycelium:Normal, Farmland:Dry
                                    #include "/lib/materials/specificMaterials/terrain/dirt.glsl"
                                }
                                else /*if (mat < 10136)*/ { // Grass Block:Normal
                                    if (glColor.b < 0.98) { // Grass Block:Normal:Grass Part
                                        smoothnessG = pow2(color.g);

                                        #ifdef SNOWY_WORLD
                                            snowMinNdotU = min(pow2(pow2(color.g)) * 1.9, 0.1);
                                            color.rgb = color.rgb * 0.5 + 0.5 * (color.rgb / glColor.rgb);
                                        #endif
                                    } else { //Grass Block:Normal:Dirt Part
                                        #include "/lib/materials/specificMaterials/terrain/dirt.glsl"

                                        #ifdef DURING_WORLDSPACE_REF
                                            // Fix ultra green grass side texture
                                            color.rgb *= pow(1.0 - max0(color.g - color.r), 2.0 * color.g);
                                        #endif
                                    }
                                }
                            } else {
                                if (mat < 10140) { // Farmland:Wet
                                    if (NdotU > 0.99) { // Farmland:Wet:Top Part
                                        #if MC_VERSION >= 11300
                                            smoothnessG = clamp(pow2(pow2(1.0 - color.r)) * 2.5, 0.5, 1.0);
                                            highlightMult = 0.5 + pow2(smoothnessG);
                                            smoothnessD = pow2(smoothnessG) * 0.5;
                                        #else
                                            smoothnessG = 0.5 * (1.0 + abs(color.r - color.b) + color.b);
                                            smoothnessD = smoothnessG * 0.5;
                                        #endif
                                    } else { // Farmland:Wet:Dirt Part
                                        #include "/lib/materials/specificMaterials/terrain/dirt.glsl"
                                    }
                                }
                                else /*if (mat < 10144)*/ { // Netherrack
                                    #include "/lib/materials/specificMaterials/terrain/netherrack.glsl"
                                }
                            }
                        } else {
                            if (mat < 10151) { // MV: Piston, Dispenser, Dropper
                                if (mat < 10148) { // Warped Nylium, Warped Wart Block
                                    if (color.g == color.b && color.g > 0.0001) { // Warped Nylium:Netherrack Part
                                        #include "/lib/materials/specificMaterials/terrain/netherrack.glsl"
                                    } else { // Warped Nylium:Nylium Part, Warped Wart Block
                                        smoothnessG = color.g * 0.5;
                                        smoothnessD = smoothnessG;

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.77;
                                        #endif

                                        #ifdef GLOWING_WART
                                            if (mat == 10146 && color.g > 0.7) { // Warped Wart Block
                                                overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.8;
                                                emission = 2.4;
                                                #ifdef GBUFFERS_TERRAIN
                                                    vec2 bpos = floor(playerPos.xz + cameraPosition.xz + 0.5)
                                                              + floor(playerPos.y + cameraPosition.y + 0.5);
                                                    bpos = bpos * 0.01 + 0.005 * frameTimeCounter;
                                                    emission *= pow2(texture2DLod(noisetex, bpos, 0.0).r * pow1_5(texture2DLod(noisetex, bpos * 0.5, 0.0).r));
                                                    emission *= 4.0;
                                                #endif
                                            }
                                        #endif
                                    }
                                }
                                else /*if (mat < 10152)*/ { // Crimson Nylium, Nether Wart Block
                                    if (color.g == color.b && color.g > 0.0001 && color.r < 0.522) { // Crimson Nylium:Netherrack Part
                                        #include "/lib/materials/specificMaterials/terrain/netherrack.glsl"
                                    } else { // Crimson Nylium:Nylium Part, Nether Wart Block
                                        smoothnessG = color.r * 0.5;
                                        smoothnessD = smoothnessG;

                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            if (mat == 10148) color.rgb = mix(color.rgb, saturateColors(color.rgb * vec3(1.2, 0.7, 0.8) * 0.7, 0.8), inSoulValley); // Color curve to make it look better
                                        #endif

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.77;
                                        #endif

                                        #ifdef GLOWING_WART
                                            if (mat == 10150 && color.r > 0.6) { // Nether Wart Block
                                                overlayNoiseEmission = 0.28;
                                                emission = 16.0 * color.g;
                                                #ifdef GBUFFERS_TERRAIN
                                                    vec2 bpos = floor(playerPos.xz + cameraPosition.xz + 0.5)
                                                              + floor(playerPos.y + cameraPosition.y + 0.5);
                                                    bpos = bpos * 0.01 + 0.005 * frameTimeCounter;
                                                    emission *= pow2(texture2DLod(noisetex, bpos, 0.0).r * pow1_5(texture2DLod(noisetex, bpos * 0.5, 0.0).r));
                                                    emission *= 4.0;
                                                #endif
                                            }
                                        #endif
                                    }
                                }
                            } else {
                                if (mat < 10156) { // Cobblestone+, Mossy Cobblestone+, Furnace:Unlit, Smoker:Unlit, Blast Furnace:Unlit, Lodestone, Piston, Sticky Piston, Dispenser, Dropper
                                    #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                }
                                else /*if (mat < 10160)*/ { // Oak Planks++:Clean Variants, Bookshelf, Crafting Table, Tripwire Hook
                                    #include "/lib/materials/specificMaterials/planks/oakPlanks.glsl"
                                }
                            }
                        }
                    } else {
                        if (mat < 10176) {
                            if (mat < 10168) {
                                if (mat < 10164) { // Oak Log, Oak Wood
                                    if (color.g > 0.48 ||
                                        CheckForColor(color.rgb, vec3(126, 98, 55)) ||
                                        CheckForColor(color.rgb, vec3(150, 116, 65))) { // Oak Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/oakPlanks.glsl"
                                    } else { // Oak Log:Wood Part, Oak Wood
                                        #include "/lib/materials/specificMaterials/terrain/oakWood.glsl"
                                    }
                                }
                                else /*if (mat < 10168)*/ { // Spruce Planks++:Clean Variants
                                    #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                                }
                            } else {
                                if (mat < 10172) { // Spruce Log, Spruce Wood
                                    if (color.g > 0.25) { // Spruce Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                                    } else { // Spruce Log:Wood Part, Spruce Wood
                                        smoothnessG = pow2(color.g) * 2.5;
                                        smoothnessG = min1(smoothnessG);
                                        smoothnessD = smoothnessG;
                                    }
                                }
                                else /*if (mat < 10176)*/ { // Birch Planks++:Clean Variants, Scaffolding, Loom
                                    #include "/lib/materials/specificMaterials/planks/birchPlanks.glsl"
                                }
                            }
                        } else {
                            if (mat < 10184) {
                                if (mat < 10180) { // Birch Log, Birch Wood
                                    if (color.r - color.b > 0.15) { // Birch Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/birchPlanks.glsl"
                                    } else { // Birch Log:Wood Part, Birch Wood
                                        smoothnessG = pow2(color.g) * 0.25;
                                        smoothnessD = smoothnessG;

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 1.25;
                                        #endif
                                    }
                                }
                                else /*if (mat < 10184)*/ { // Jungle Planks++:Clean Variants, Composter
                                    #include "/lib/materials/specificMaterials/planks/junglePlanks.glsl"
                                }
                            } else {
                                if (mat < 10188) { // Jungle Log, Jungle Wood
                                    if (color.g > 0.405) { // Jungle Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/junglePlanks.glsl"
                                    } else { // Jungle Log:Wood Part, Jungle Wood
                                        smoothnessG = pow2(pow2(color.g)) * 5.0;
                                        smoothnessG = min1(smoothnessG);
                                        smoothnessD = smoothnessG;

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.77;
                                        #endif
                                    }
                                }
                                else /*if (mat < 10192)*/ { // Acacia Planks++:Clean Variants
                                    #include "/lib/materials/specificMaterials/planks/acaciaPlanks.glsl"
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10224) {
                        if (mat < 10208) {
                            if (mat < 10200) {
                                if (mat < 10196) { // Acacia Log, Acacia Wood
                                    if (color.r - color.b > 0.2) { // Acacia Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/acaciaPlanks.glsl"
                                    } else { // Acacia Log:Wood Part, Acacia Wood
                                        smoothnessG = pow2(color.b) * 1.3;
                                        smoothnessG = min1(smoothnessG);
                                        smoothnessD = smoothnessG;

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.66;
                                        #endif
                                    }
                                }
                                else /*if (mat < 10200)*/ { // Dark Oak Planks++:Clean Variants
                                    #include "/lib/materials/specificMaterials/planks/darkOakPlanks.glsl"
                                }
                            } else {
                                if (mat < 10204) { // Dark Oak Log, Dark Oak Wood
                                    if (color.r - color.g > 0.08 ||
                                        CheckForColor(color.rgb, vec3(48, 30, 14))) { // Dark Oak Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/darkOakPlanks.glsl"
                                    } else { // Dark Oak Log:Wood Part, Dark Oak Wood
                                        smoothnessG = color.r * 0.4;
                                        smoothnessD = smoothnessG;
                                    }
                                }
                                else /*if (mat < 10208)*/ { // Mangrove Planks++:Clean Variants
                                    #include "/lib/materials/specificMaterials/planks/mangrovePlanks.glsl"
                                }
                            }
                        } else {
                            if (mat < 10216) {
                                if (mat < 10212) { // Mangrove Log, Mangrove Wood
                                    if (color.r - color.g > 0.2) { // Mangrove Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/mangrovePlanks.glsl"
                                    } else { // Mangrove Log:Wood Part, Mangrove Wood
                                        smoothnessG = pow2(color.r) * 0.6;
                                        smoothnessD = smoothnessG;
                                    }
                                }
                                else /*if (mat < 10216)*/ { // Crimson Planks++:Clean Variants
                                    #include "/lib/materials/specificMaterials/planks/crimsonPlanks.glsl"
                                }
                            } else {
                                if (mat < 10220) { // Crimson Stem, Crimson Hyphae
                                    if (color.r / color.b <= 2.5) { // Flat Part
                                        #include "/lib/materials/specificMaterials/planks/crimsonPlanks.glsl"

                                    #ifdef GLOWING_NETHER_TREES
                                    } else { // Emissive Part
                                        emission = pow2(color.r) * 6.5;
                                        color.gb *= 0.5;
                                        overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.15;
                                    #endif
                                    }
                                }
                                else /*if (mat < 10224)*/ { // Warped Planks++:Clean Variants
                                    #include "/lib/materials/specificMaterials/planks/warpedPlanks.glsl"
                                }
                            }
                        }
                    } else {
                        if (mat < 10240) {
                            if (mat < 10232) {
                                if (mat < 10228) { // Warped Stem, Warped Hyphae
                                    //if (color.r < 0.12 || color.r + color.g * 3.0 < 3.4 * color.b) { // Emissive Part
                                    if (color.r >= 0.37 * color.b && color.r + color.g * 3.0 >= 3.4 * color.b) { // Flat Part
                                        #include "/lib/materials/specificMaterials/planks/warpedPlanks.glsl"

                                    #ifdef GLOWING_NETHER_TREES
                                    } else { // Emissive Part
                                        emission = pow2(color.g + 0.2 * color.b) * 4.5 + 0.15;
                                        overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.3;
                                    #endif
                                    }
                                }
                                else /*if (mat < 10232)*/ { // Bedrock
                                    smoothnessG = color.b * 0.2 + 0.1;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 1.5;
                                    #endif
                                }
                            } else {
                                if (mat < 10236) { // Sand, Suspicious Sand
                                    smoothnessG = pow(color.g, 16.0) * 2.0;
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;
                                    highlightMult = 2.0;

                                    #ifdef GBUFFERS_TERRAIN
                                        DoBrightBlockTweaks(color.rgb, 0.5, shadowMult, highlightMult);

                                        DoOceanBlockTweaks(smoothnessD);
                                    #endif

                                    #if RAIN_PUDDLES >= 1
                                        noPuddles = 1.0;
                                    #endif
                                }
                                else /*if (mat < 10240)*/ { // Red Sand
                                    smoothnessG = pow(color.r, 10.0);
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;
                                    highlightMult = 2.0;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif

                                    #if RAIN_PUDDLES >= 1
                                        noPuddles = 1.0;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10248) {
                                if (mat < 10244) { // Sandstone+
                                    highlightMult = 2.0;
                                    smoothnessG = pow2(pow2(color.g)) * 0.5;
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;

                                    #ifdef GBUFFERS_TERRAIN
                                        DoBrightBlockTweaks(color.rgb, 0.5, shadowMult, highlightMult);
                                    #endif

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                                else /*if (mat < 10248)*/ { // Red Sandstone+
                                    highlightMult = 2.0;
                                    smoothnessG = pow2(pow2(color.r)) * 0.35;
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif
                                }
                            } else {
                                if (mat < 10252) { // Netherite Block
                                    #include "/lib/materials/specificMaterials/terrain/netheriteBlock.glsl"
                                }
                                else /*if (mat < 10256)*/ { // Ancient Debris
                                    smoothnessG = pow2(color.r);
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 1.5;
                                    #endif

                                    #ifdef GLOWING_ORE_ANCIENTDEBRIS
                                        #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                            if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                        #endif
                                        {
                                            emission = 1.5 + 0.6 * min(pow2(color.g * 6.0), 8.0);
                                            overlayNoiseIntensity = 0.2, overlayNoiseEmission = 0.8;
                                            #ifdef SITUATIONAL_ORES
                                                emission *= skyLightCheck;
                                                color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.75 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                            #else
                                                color.rgb *= pow(color.rgb, vec3(0.75 * min1(GLOWING_ORE_MULT)));
                                            #endif
                                            emission *= GLOWING_ORE_MULT;
                                        }
                                    #endif
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (mat < 10384) {
                if (mat < 10320) {
                    if (mat < 10288) {
                        if (mat < 10272) {
                            if (mat < 10264) {
                                if (mat < 10260) { // Iron Bars
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                                }
                                else /*if (mat < 10264)*/ { // ACT solid blocks with no properties

                                }
                            } else {
                                if (mat < 10268) { // Iron Block, Heavy Weighted Pressure Plate
                                    #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                                    color.rgb *= max(color.r, 0.85) * 0.9;

                                    // color.rgb = vec3(0.0);
                                    // smoothnessD = 1.0;
                                    // smoothnessG = smoothnessD;
                                    // noGeneratedNormals = true;
                                    // overlayNoiseIntensity = 0.0;

                                    if (mat == 10267) { // Powered Heavy Weighted Pressure Plate
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10272)*/ { // Raw Iron Block
                                    #include "/lib/materials/specificMaterials/terrain/rawIronBlock.glsl"
                                    #ifdef GLOWING_RAW_BLOCKS
                                        emission = pow1_5(color.r) * 1.5;

                                        overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                        #ifdef SITUATIONAL_ORES
                                            emission *= skyLightCheck;
                                            color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                        #else
                                            color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                        #endif
                                        emission *= GLOWING_ORE_MULT;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10280) {
                                if (mat < 10276) { // Iron Ore
                                    if (color.r != color.g) { // Iron Ore:Raw Iron Part
                                        #include "/lib/materials/specificMaterials/terrain/rawIronBlock.glsl"
                                        #ifdef GLOWING_ORE_IRON
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if (color.r - color.b > 0.15) {
                                                emission = pow1_5(color.r) * 1.5;

                                                overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Iron Ore:Stone Part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                }
                                else /*if (mat < 10280)*/ { // Deepslate Iron Ore
                                    if (color.r != color.g) { // Deepslate Iron Ore:Raw Iron Part
                                        #include "/lib/materials/specificMaterials/terrain/rawIronBlock.glsl"
                                        #ifdef GLOWING_ORE_IRON
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if (color.r - color.b > 0.15) {
                                                emission = pow1_5(color.r) * 1.5;

                                                overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Deepslate Iron Ore:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10284) { // Raw Copper Block
                                    #include "/lib/materials/specificMaterials/terrain/rawCopperBlock.glsl"
                                    #ifdef GLOWING_RAW_BLOCKS
                                        emission = pow2(color.r) * 1.5 + color.g * 1.3 + 0.2;

                                        overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                        #ifdef SITUATIONAL_ORES
                                            emission *= skyLightCheck;
                                            color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                        #else
                                            color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                        #endif
                                        emission *= GLOWING_ORE_MULT;
                                    #endif
                                }
                                else /*if (mat < 10288)*/ { // Copper Ore
                                    if (color.r != color.g) { // Copper Ore:Raw Copper Part
                                        #include "/lib/materials/specificMaterials/terrain/rawCopperBlock.glsl"
                                        #ifdef GLOWING_ORE_COPPER
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if ((max(color.r * 0.5, color.g) - color.b > 0.05) && (color.r + color.g > 1.9 || color.r + color.g + color.b < 1.9)) {
                                                emission = color.r * 2.0 + 0.7;

                                                overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Copper Ore:Stone Part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                }
                            }
                        }
                    } else {
                        if (mat < 10304) {
                            if (mat < 10296) {
                                if (mat < 10291) { // Deepslate Copper Ore
                                    if (color.r != color.g) { // Deepslate Copper Ore:Raw Copper Part
                                        #include "/lib/materials/specificMaterials/terrain/rawCopperBlock.glsl"
                                        #ifdef GLOWING_ORE_COPPER
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if (max(color.r * 0.5, color.g) - color.b > 0.05) {
                                                emission = color.r * 2.0 + 0.7;

                                                overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Deepslate Copper Ore:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                }
                                else /*if (mat < 10296)*/ { // Copper Block++:All Non-raw Variants
                                    #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"
                                }
                            } else {
                                if (mat < 10300) { // Raw Gold Block
                                    #include "/lib/materials/specificMaterials/terrain/rawGoldBlock.glsl"
                                    #ifdef GLOWING_RAW_BLOCKS
                                        emission = color.g * 1.5;

                                        overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                        #ifdef SITUATIONAL_ORES
                                            emission *= skyLightCheck;
                                            color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                        #else
                                            color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                        #endif
                                        emission *= GLOWING_ORE_MULT;
                                    #endif
                                }
                                else if (mat < 10302) { // Gold Ore
                                    if ((color.g - color.b > 0.15 || color.r > 0.99) && (color.r + color.g > 1.9 || color.r + color.g + color.b < 1.9)) { // Gold Ore:Raw Gold Part
                                        #include "/lib/materials/specificMaterials/terrain/rawGoldBlock.glsl"
                                        #ifdef GLOWING_ORE_GOLD
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if (color.g - color.b > 0.15 || color.r > 0.99) {
                                                emission = color.r + 1.0;

                                                overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Gold Ore:Stone Part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                } else /*if (mat < 10302)*/ { // Deepslate Gold Ore
                                    if (color.r != color.g || color.r > 0.99) { // Deepslate Gold Ore:Raw Gold Part
                                        #include "/lib/materials/specificMaterials/terrain/rawGoldBlock.glsl"
                                        #ifdef GLOWING_ORE_GOLD
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if (color.g - color.b > 0.15 || color.r > 0.99) {
                                                emission = color.r + 1.0;

                                                overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Deepslate Gold Ore:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                }
                            }
                        } else {
                            if (mat < 10312) {
                                if (mat < 10308) { // Pink and Purple Modded Ores
                                    // if (mat < 10306) { // Pink Modded Ores
                                        if (color.r - color.g > 0.1) { // Redstone Ore:Lit:Redstone Part
                                            #if defined GLOWING_ORE_MODDED && !defined VOXY_PATCH
                                                emission = min(1.5, pow2(color.r) * color.r * 4.5 * color.b);
                                                overlayNoiseIntensity = 0.5, overlayNoiseEmission = 0.5;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                #endif
                                            #endif
                                        } else { // Redstone Ore:Lit:Stone Part
                                            #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                        }
                                        noSmoothLighting = true;
                                    // } else { // Purple Modded Ores

                                    // }
                                }
                                else /*if (mat < 10312)*/ { // Nether Gold Ore
                                    if (color.g != color.b) { // Nether Gold Ore:Raw Gold Part
                                        #include "/lib/materials/specificMaterials/terrain/rawGoldBlock.glsl"
                                        #ifdef GLOWING_ORE_NETHERGOLD
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = color.g * 1.5;
                                                emission *= GLOWING_ORE_MULT;
                                                overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                #endif
                                            }
                                        #endif
                                    } else { // Nether Gold Ore:Netherrack Part
                                        #include "/lib/materials/specificMaterials/terrain/netherrack.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10316) { // Gold Block, Light Weighted Pressure Plate
                                    #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"

                                    if (mat == 10315) { // Powered Light Weighted Pressure Plate
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10320)*/ { // Diamond Block
                                    #include "/lib/materials/specificMaterials/terrain/diamondBlock.glsl"
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10352) {
                        if (mat < 10336) {
                            if (mat < 10328) {
                                if (mat < 10324) { // Diamond Ore
                                    if (color.b / color.r > 1.5 || color.b > 0.75) { // Diamond Ore:Diamond Part
                                        #include "/lib/materials/specificMaterials/terrain/diamondBlock.glsl"
                                        #ifdef GLOWING_ORE_DIAMOND
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = color.g + 1.5;

                                                overlayNoiseIntensity = 0.75, overlayNoiseEmission = 0.4;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Diamond Ore:Stone Part, Diamond Ore:StoneToDiamond part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                }
                                else /*if (mat < 10328)*/ { // Deepslate Diamond Ore
                                    if (color.b / color.r > 1.5 || color.b > 0.8) { // Deepslate Diamond Ore:Diamond Part
                                        #include "/lib/materials/specificMaterials/terrain/diamondBlock.glsl"
                                        #ifdef GLOWING_ORE_DIAMOND
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = color.g + 1.5;

                                                overlayNoiseIntensity = 0.75, overlayNoiseEmission = 0.4;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Deepslate Diamond Ore:Deepslate Part, Deepslate Diamond Ore:DeepslateToDiamond part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10332) { // Amethyst Block, Budding Amethyst
                                    #include "/lib/materials/specificMaterials/terrain/amethyst.glsl"

                                    #if GLOWING_AMETHYST >= 2
                                        emission = dot(color.rgb, color.rgb) * 0.3;
                                        overlayNoiseEmission = 0.5;
                                    #endif

                                    #if ALTERNATIVE_AMETHYST_STYLE == 1
                                        smoothnessG = max(sqrt(1.0 - factor), 0.04);
                                        smoothnessD = factor * 2;
                                        color.rgb *= 1.75 - 0.4 * GetLuminance(color.rgb);
                                        color.g *= 0.85 * pow2(color.g);
                                        color.rgb = saturateColors(color.rgb, 0.6);
                                    #endif

                                    color.rgb *= 0.7 + 0.3 * GetLuminance(color.rgb);

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
                                }
                                else /*if (mat < 10336)*/ { // Amethyst Cluster, Amethyst Buds
                                    #include "/lib/materials/specificMaterials/terrain/amethyst.glsl"

                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.85;

                                    #if GLOWING_AMETHYST >= 1
                                        #if defined GBUFFERS_TERRAIN && !defined IPBR_COMPAT_MODE
                                            // vec3 worldPos = playerPos.xyz + cameraPosition.xyz;
                                            // vec3 blockPos = abs(fract(worldPos) - vec3(0.5));
                                            // float maxBlockPos = max(blockPos.x, max(blockPos.y, blockPos.z));
                                            float maxBlockPos = maxOf(abs(fract(blockUV) - vec3(0.5))); // change to blockUV to make it work with colorwheel
                                            emission = pow2(max0(1.0 - maxBlockPos * 1.85) * color.g) * 7.0;

                                            if (CheckForColor(color.rgb, vec3(254, 203, 230)))
                                                emission = pow(emission, max0(1.0 - 0.2 * max0(emission - 1.0)));

                                            color.g *= 1.0 - emission * 0.07;

                                            emission *= 1.3;
                                        #else
                                            emission = pow2(color.g + color.b) * 0.4;
                                        #endif

                                        overlayNoiseIntensity = 0.5;
                                    #endif

                                    #if ALTERNATIVE_AMETHYST_STYLE == 1
                                        color.rgb = pow1_5(color.rgb);
                                        color.rgb *= 1.5;
                                        color.g *= 0.6;
                                        color.rgb = saturateColors(color.rgb, 0.7);
                                    #endif

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10344) {
                                if (mat < 10340) { // Emerald Block
                                    #include "/lib/materials/specificMaterials/terrain/emeraldBlock.glsl"

                                    #ifdef GLOWING_EMERALD_BLOCK
                                        emission = pow2(pow(color.g, 2.8)) * 3.0 + 0.3;
                                        color.rgb *= color.rgb;
                                        overlayNoiseIntensity = 0.5;
                                    #endif
                                }
                                else /*if (mat < 10344)*/ { // Emerald Ore
                                    float dif = GetMaxColorDif(color.rgb);
                                    if (dif > 0.25 || color.b > 0.85) { // Emerald Ore:Emerald Part
                                        #include "/lib/materials/specificMaterials/terrain/emeraldBlock.glsl"
                                        #ifdef GLOWING_ORE_EMERALD
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = 2.0;

                                                overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.3;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Emerald Ore:Stone Part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10348) { // Deepslate Emerald Ore
                                    float dif = GetMaxColorDif(color.rgb);
                                    if (dif > 0.25 || color.b > 0.85) { // Deepslate Emerald Ore:Emerald Part
                                        #include "/lib/materials/specificMaterials/terrain/emeraldBlock.glsl"
                                        #ifdef GLOWING_ORE_EMERALD
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = 2.0;

                                                overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.3;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Deepslate Emerald Ore:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                }
                                else /*if (mat < 10352)*/ { // Azalea, Flowering Azalea
                                    #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0, isFoliage = true;

                                    #if EMISSIVE_FLOWERS > 0 && EMISSIVE_FLOWERS_TYPE < 2
                                        if (isNonGreen(vec3(color.r * 0.7, color.g, color.b))) {
                                            emission = skyLightCheck;

                                            #if EMISSIVE_FLOWERS == 2
                                                emission = max(emission, rainFactor + 1.0 * rainFactor);
                                            #endif
                                            emission *= EMISSIVE_FLOWERS_STRENGTH;
                                        }
                                    #endif
                                }
                            }
                        }
                    } else {
                        if (mat < 10368) {
                            if (mat < 10360) {
                                if (mat < 10356) { // Lapis Block
                                    #include "/lib/materials/specificMaterials/terrain/lapisBlock.glsl"

                                    #ifdef EMISSIVE_LAPIS_BLOCK
                                        emission = pow2(dot(color.rgb, color.rgb)) * 10.0;

                                        overlayNoiseIntensity = 0.4, overlayNoiseEmission = 0.28;
                                    #endif
                                }
                                else /*if (mat < 10360)*/ { // Lapis Ore
                                    if (color.r != color.g) { // Lapis Ore:Lapis Part
                                        #include "/lib/materials/specificMaterials/terrain/lapisBlock.glsl"
                                        smoothnessG *= 0.5;
                                        smoothnessD *= 0.5;
                                        #ifdef GLOWING_ORE_LAPIS
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if (color.b - color.r > 0.2) {
                                                emission = 2.0;

                                                overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Lapis Ore:Stone Part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10364) { // Deepslate Lapis Ore
                                    if (color.r != color.g) { // Deepslate Lapis Ore:Lapis Part
                                        #include "/lib/materials/specificMaterials/terrain/lapisBlock.glsl"
                                        smoothnessG *= 0.5;
                                        smoothnessD *= 0.5;
                                        #ifdef GLOWING_ORE_LAPIS
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            if (color.b - color.r > 0.2) {
                                                emission = 2.0;

                                                overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(min1(GLOWING_ORE_MULT))), skyLightCheck);
                                                #else
                                                    color.rgb *= pow(color.rgb, vec3(min1(GLOWING_ORE_MULT)));
                                                #endif
                                                emission *= GLOWING_ORE_MULT;
                                            }
                                        #endif
                                    } else { // Deepslate Lapis Ore:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                }
                                else /*if (mat < 10368)*/ { // Quartz Block++
                                    #include "/lib/materials/specificMaterials/terrain/quartzBlock.glsl"
                                }
                            }
                        } else {
                            if (mat < 10376) {
                                if (mat < 10372) { // Nether Quartz Ore
                                    if (color.g != color.b) { // Nether Quartz Ore:Quartz Part
                                        #include "/lib/materials/specificMaterials/terrain/quartzBlock.glsl"
                                        #ifdef GLOWING_ORE_NETHERQUARTZ
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = pow2(color.b * 1.6);
                                                emission *= GLOWING_ORE_MULT;

                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                #endif
                                            }
                                        #endif
                                    } else { // Nether Quartz Ore:Netherrack Part
                                        #include "/lib/materials/specificMaterials/terrain/netherrack.glsl"
                                    }
                                }
                                else /*if (mat < 10376)*/ { // Obsidian
                                    #include "/lib/materials/specificMaterials/terrain/obsidian.glsl"
                                }
                            } else {
                                if (mat < 10380) { // Purpur Block+
                                    highlightMult = 2.0;
                                    smoothnessG = pow2(color.r) * 0.6;
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif
                                }
                                else /*if (mat < 10384)*/ { // 8 Layer Snow, Snow Block, Powder Snow
                                    #include "/lib/materials/specificMaterials/terrain/snow.glsl"

                                    overlayNoiseIntensity = 0.0;
                                }
                            }
                        }
                    }
                }
            } else {
                if (mat < 10448) {
                    if (mat < 10416) {
                        if (mat < 10400) {
                            if (mat < 10392) {
                                if (mat < 10388) { // Packed Ice
                                    materialMask = OSIEBCA; // Intense Fresnel
                                    float factor = pow2(color.g);
                                    float factor2 = pow2(factor);
                                    smoothnessG = 1.0 - 0.5 * factor;
                                    highlightMult = factor2 * 3.5;
                                    smoothnessD = factor;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.33;
                                    #endif

                                    #ifdef SSS_SNOW_ICE
                                        subsurfaceMode = 3, noSmoothLighting = true, noDirectionalShading = true;
                                    #endif
                                }
                                else /*if (mat < 10392)*/ { // Blue Ice
                                    materialMask = OSIEBCA; // Intense Fresnel
                                    float factor = min1(pow2(color.g) * 1.38);
                                    float factor2 = pow2(factor);
                                    smoothnessG = 1.0 - 0.5 * factor;
                                    highlightMult = factor2 * 3.5;
                                    smoothnessD = pow1_5(color.g);

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.33;
                                    #endif

                                    #ifdef SSS_SNOW_ICE
                                        subsurfaceMode = 3, noSmoothLighting = true, noDirectionalShading = true;
                                    #endif
                                }
                            } else {
                                if (mat < 10396) { // Pumpkin, Carved Pumpkin
                                    #include "/lib/materials/specificMaterials/terrain/pumpkin.glsl"
                                }
                                else /*if (mat < 10400)*/ { // Jack o'Lantern
                                    #include "/lib/materials/specificMaterials/terrain/pumpkin.glsl"
                                    noSmoothLighting = true, noDirectionalShading = true;
                                    lmCoordM.y = 0.0;
                                    lmCoordM.x = 1.0;

                                    #if MC_VERSION >= 11300
                                        if (color.b > 0.28 && color.r > 0.9) {
                                            float factor = pow2(color.g);
                                            emission = pow2(factor) * factor * 5.0;
                                            #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 1.5, colorSoul, inSoulValley);
                                            #endif
                                            #ifdef PURPLE_END_FIRE_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 1.5, colorEndBreath, 1.0);
                                            #endif
                                        }
                                    #else
                                        if (color.b < 0.4)
                                            emission = clamp01(color.g * 1.3 - color.r) * 5.0;
                                    #endif

                                    overlayNoiseIntensity = 0.3;
                                }
                            }
                        } else {
                            if (mat < 10408) {
                                if (mat < 10404) { // Sea Pickle:Not Waterlogged
                                    noSmoothLighting = true;

                                    overlayNoiseIntensity = 0.3;
                                }
                                else /*if (mat < 10408)*/ { // Sea Pickle:Waterlogged
                                    noSmoothLighting = true;

                                    #if ANISOTROPIC_FILTER == 0 && !defined IPBR_COMPAT_MODE
                                        color = texture2DLod(tex, texCoord, 0);
                                    #endif

                                    overlayNoiseIntensity = 0.3;

                                    if (color.b > 0.5) { // Sea Pickle:Emissive Part
                                        #ifdef GBUFFERS_TERRAIN
                                            color.g *= 1.1;
                                            emission = 5.0;
                                        #endif
                                    }
                                }
                            } else {
                                if (mat < 10412) { // Basalt+
                                    smoothnessG = color.r * 0.45;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                                else /*if (mat < 10416)*/ { // Glowstone
                                    noSmoothLighting = true; noDirectionalShading = true;
                                    lmCoordM = vec2(0.9, 0.0);

                                    emission = max0(color.g - 0.3) * 4.6;
                                    color.rg += emission * vec2(0.15, 0.05);

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif

                                    sandNoiseIntensity = 0.6, mossNoiseIntensity = 0.6;
                                }
                            }
                        }
                    } else {
                        if (mat < 10432) {
                            if (mat < 10424) {
                                if (mat < 10420) { // Nether Bricks+
                                    float factor = smoothstep1(min1(color.r * 1.5));
                                    factor = factor > 0.12 ? factor : factor * 0.5;
                                    smoothnessG = factor;
                                    smoothnessD = factor;
                                }
                                else /*if (mat < 10424)*/ { // Red Nether Bricks+
                                    float factor = color.r * 0.9;
                                    factor = color.r > 0.215 ? factor : factor * 0.25;
                                    smoothnessG = factor;
                                    smoothnessD = factor;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                            } else {
                                if (mat < 10428) { // Melon
                                    smoothnessG = color.r * 0.75;
                                    smoothnessD = color.r * 0.5;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
                                }
                                else /*if (mat < 10432)*/ { // End Stone++,
                                    #include "/lib/materials/specificMaterials/terrain/endStone.glsl"
                                }
                            }
                        } else {
                            if (mat < 10440) {
                                if (mat < 10436) { // Terracotta+
                                    smoothnessG = 0.25;
                                    highlightMult = 1.5;
                                    smoothnessD = 0.17;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.33;
                                    #endif
                                }
                                else /*if (mat < 10440)*/ { // Glazed Terracotta+
                                    smoothnessG = 0.75;
                                    smoothnessD = 0.35;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif
                                }
                            } else {
                                if (mat < 10444) { // Prismarine+, Prismarine Bricks+
                                    smoothnessG = pow2(color.g) * 0.8;
                                    highlightMult = 1.5;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
                                }
                                else /*if (mat < 10448)*/ { // Dark Prismarine+
                                    smoothnessG = min1(pow2(color.g) * 2.0);
                                    highlightMult = 1.5;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10480) {
                        if (mat < 10464) {
                            if (mat < 10456) {
                                if (mat < 10452) { // Sea Lantern
                                    noSmoothLighting = true; noDirectionalShading = true;
                                    lmCoordM.x = 0.85;

                                    smoothnessD = min1(max0(0.5 - color.r) * 2.0);
                                    smoothnessG = color.g;

                                    #ifndef IPBR_COMPAT_MODE
                                        float blockRes = absMidCoordPos.x * atlasSize.x;
                                        vec2 signMidCoordPosM = (floor((signMidCoordPos + 1.0) * blockRes) + 0.5) / blockRes - 1.0;
                                        float dotsignMidCoordPos = dot(signMidCoordPosM, signMidCoordPosM);
                                        float factor = pow2(max0(1.0 - 1.7 * pow2(pow2(dotsignMidCoordPos))));
                                    #else
                                        float factor = pow2(pow2(min(dot(color.rgb, color.rgb), 2.5) / 2.5));
                                    #endif

                                    emission = pow2(color.b) * 1.6 + 2.2 * factor;
                                    emission *= 0.4 + max0(0.6 - 0.006 * lViewPos);

                                    color.rb *= vec2(1.13, 1.1);

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif

                                    overlayNoiseIntensity = 0.5;
                                }
                                else /*if (mat < 10456)*/ { // Magma Block
                                    noSmoothLighting = true; noDirectionalShading = true;
                                    lmCoordM = vec2(0.75, 0.0);

                                    if (color.g > 0.22) { // Emissive Part
                                        emission = pow2(pow2(color.r)) * 4.0;

                                        #if RAIN_PUDDLES >= 1
                                            noPuddles = color.g * 4.0;
                                        #endif

                                        color.gb *= max(2.0 - 11.0 * pow2(color.g), 0.5);

                                        maRecolor = vec3(emission * 0.075);

                                        overlayNoiseIntensity = 0.0;

                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                        #endif
                                        #ifdef PURPLE_END_FIRE_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                        #endif
                                    } else { // Netherrack Part
                                        #include "/lib/materials/specificMaterials/terrain/netherrack.glsl"

                                        emission = 0.2;
                                    }

                                }
                            } else {
                                if (mat < 10460) { // Command Block+
                                    #ifndef IPBR_COMPAT_MODE
                                        color = texture2DLod(tex, texCoord, 0);
                                    #endif

                                    vec2 coord = signMidCoordPos;
                                    float blockRes = absMidCoordPos.x * atlasSize.x;
                                    vec2 absCoord = abs(coord);
                                    float maxCoord = max(absCoord.x, absCoord.y);

                                    float dif = GetMaxColorDif(color.rgb);

                                    if ( // This mess exists because Iris' midCoord is slightly inaccurate
                                        dif > 0.1 && maxCoord < 0.375 &&
                                        !CheckForColor(color.rgb, vec3(111, 73, 43)) &&
                                        !CheckForColor(color.rgb, vec3(207, 166, 139)) &&
                                        !CheckForColor(color.rgb, vec3(155, 139, 207)) &&
                                        !CheckForColor(color.rgb, vec3(161, 195, 180)) &&
                                        !CheckForColor(color.rgb, vec3(201, 143, 107)) &&
                                        !CheckForColor(color.rgb, vec3(135, 121, 181)) &&
                                        !CheckForColor(color.rgb, vec3(131, 181, 145))
                                    ) {
                                        emission = 6.0;
                                        color.rgb *= color.rgb;
                                        highlightMult = 2.0;
                                        maRecolor = vec3(0.5);

                                        overlayNoiseIntensity = 0.1;
                                    } else {
                                        smoothnessG = dot(color.rgb, color.rgb) * 0.33;
                                        smoothnessD = smoothnessG;
                                    }
                                }
                                else /*if (mat < 10464)*/ { // Concrete+ except Lime
                                    smoothnessG = 0.4;
                                    highlightMult = 1.5;
                                    smoothnessD = 0.3;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.2;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10472) {
                                if (mat < 10468) { // Concrete Powder+
                                    smoothnessG = 0.2;
                                    smoothnessD = 0.1;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif
                                }
                                else /*if (mat < 10472)*/ { // Coral Block+
                                    #include "/lib/materials/specificMaterials/terrain/coral.glsl"
                                    // if (abs(color.r - color.g - color.b) < lColor * 0.49 || color.b > color.g) emission = (GetLuminance(color.rgb) - color.g * 0.6) * 2.5;
                                }
                            } else {
                                if (mat < 10476) { // Coral Fan+, Coral+
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/terrain/coral.glsl"
                                    isFoliage = false;
                                }
                                else /*if (mat < 10480)*/ { // Crying Obsidian
                                    #include "/lib/materials/specificMaterials/terrain/cryingObsidian.glsl"

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif

                                    overlayNoiseIntensity = 0.7;
                                }
                            }
                        }
                    } else {
                        if (mat < 10496) {
                            if (mat < 10488) {
                                if (mat < 10484) { // Blackstone++
                                    #include "/lib/materials/specificMaterials/terrain/blackstone.glsl"
                                }
                                else /*if (mat < 10488)*/ { // Gilded Blackstone
                                    if (color.r > color.b * 3.0) { // Gilded Blackstone:Gilded Part
                                        #include "/lib/materials/specificMaterials/terrain/rawGoldBlock.glsl"
                                        #ifdef GLOWING_ORE_GILDEDBLACKSTONE
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = color.g * 1.5;
                                                emission *= GLOWING_ORE_MULT;

                                                overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;

                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                #endif
                                            }
                                        #endif
                                    } else { // Gilded Blackstone:Blackstone Part
                                        #include "/lib/materials/specificMaterials/terrain/blackstone.glsl"
                                    }

                                }
                            } else {
                                if (mat < 10492) { // Lily Pad
                                    noSmoothLighting = true;
                                    subsurfaceMode = 2;

                                    #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                        doTileRandomisation = false;
                                    #endif

                                    #ifdef IPBR
                                        float factor = min1(color.g * 2.0);
                                        smoothnessG = factor * 0.5;
                                        highlightMult = factor;
                                    #endif
                                }
                                else /*if (mat < 10496)*/ { // Dirt Path
                                    #include "/lib/materials/specificMaterials/terrain/dirt.glsl"
                                    #ifdef GBUFFERS_TERRAIN
                                        glColor.a = sqrt(glColor.a);
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10504) {
                                if (mat < 10500) { // Torch
                                    noDirectionalShading = true;

                                    if (color.r > 0.95) {
                                        noSmoothLighting = true;
                                        lmCoordM.x = 1.0;
                                        emission = GetLuminance(color.rgb);
                                        #ifdef GBUFFERS_TERRAIN
                                            emission *= 3.5;
                                        #else
                                            emission *= 2.665;
                                        #endif
                                        color.r *= 1.3;
                                        color.b *= 0.5;
                                        overlayNoiseIntensity = 0.0;

                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            if (color.g > 0.999) color.rgb = changeColorFunction(color.rgb, 1.5, colorSoul, inSoulValley);
                                        #endif
                                        #ifdef PURPLE_END_FIRE_INTERNAL
                                            if (color.g > 0.5) color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                        #endif
                                    }

                                    #ifdef GBUFFERS_TERRAIN
                                        else if (abs(NdotU) < 0.5) {
                                            #ifndef IPBR_COMPAT_MODE
                                                #if MC_VERSION >= 12102 // torch model got changed in 1.21.2
                                                    lmCoordM.x = min1(0.7 + 0.3 * smoothstep1(max0(0.4 - signMidCoordPos.y)));
                                                #else
                                                    lmCoordM.x = min1(0.7 + 0.3 * pow2(1.0 - signMidCoordPos.y));
                                                #endif
                                            #else
                                                lmCoordM.x = 0.82;
                                            #endif
                                        } else {
                                            lmCoordM.x = 0.7;
                                        }
                                    #else
                                        else {
                                            color.rgb *= 1.5;
                                        }
                                    #endif

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(color, vec4(1.0, 0.6, 0.2, 1.0), emission, 5.0, lViewPos);
                                    #endif

                                    emission += 0.0001; // No light reducing during noon
                                }
                                else /*if (mat < 10504)*/ { // End Rod
                                    noDirectionalShading = true;

                                    #ifdef GBUFFERS_TERRAIN
                                        noSmoothLighting = true;
                                        lmCoordM.x = 0.92;
                                    #else
                                        lmCoordM.x = 0.9;
                                    #endif

                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (dotColor > 2.0) {
                                        emission = 3.3;
                                        emission *= 0.4 + max0(0.6 - 0.006 * lViewPos);
                                        vec2 noiseAdd = vec2(0.0);
                                        #if RAINBOW_END_ROD_COORD_OFFSET > 0 && defined GBUFFERS_TERRAIN
                                            noiseAdd = texture2DLod(noisetex, 0.00048 * (playerPos.xz + cameraPosition.xz), 0.0).rg;
                                            noiseAdd *= RAINBOW_END_ROD_COORD_OFFSET;
                                        #endif
                                        #if END_ROD_COLOR_PROFILE == 1
                                            color.rgb = pow2(vec3(END_ROD_R, END_ROD_G, END_ROD_B) / 255) * END_ROD_I;
                                        #elif END_ROD_COLOR_PROFILE == 2 || (END_ROD_COLOR_PROFILE == 3 && defined OVERWORLD)
                                            color.rgb = pow2(getRainbowColor(noiseAdd, END_ROD_RAINBOW_ANIMATE));
                                        #else
                                            color.rgb = pow2(color.rgb);
                                            color.g *= 0.95;
                                        #endif
                                    }

                                    #if defined GBUFFERS_TERRAIN && !defined GBUFFERS_COLORWHEEL
                                        else { // Directional Self-light Effect
                                            vec3 fractPos = abs(fract(playerPos + cameraPosition) - 0.5);
                                            float maxCoord = max(fractPos.x, max(fractPos.y, fractPos.z));
                                            if (maxCoord < 0.4376) {
                                                lmCoordM.x = 1.0;
                                                color.rgb *= 1.8;
                                            }
                                        }
                                    #endif

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 4.0, lViewPos);
                                    #endif

                                    overlayNoiseIntensity = 0.3;
                                }
                            } else {
                                if (mat < 10508) { // Chorus Plant

                                }
                                else /*if (mat < 10512)*/ { // Chorus Flower:Alive
                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (dotColor > 1.0) {
                                        emission = pow2(pow2(pow2(dotColor * 0.33))) + 0.2 * dotColor;
                                        overlayNoiseIntensity = 0.5, overlayNoiseEmission = 0.6;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (mat < 10768) {
            if (mat < 10640) {
                if (mat < 10576) {
                    if (mat < 10544) {
                        if (mat < 10528) {
                            if (mat < 10520) {
                                if (mat < 10516) { // Chorus Flower:Dead
                                    #ifndef VOXY_PATCH
                                        vec3 checkColor = texture2DLod(tex, texCoord, 0).rgb;
                                    #else
                                        vec3 checkColor = color.rgb;
                                    #endif

                                    if (CheckForColor(checkColor, vec3(164, 157, 126)) ||
                                        CheckForColor(checkColor, vec3(201, 197, 176)) ||
                                        CheckForColor(checkColor, vec3(226, 221, 188)) ||
                                        CheckForColor(checkColor, vec3(153, 142, 95))
                                    ) {
                                        emission = min(GetLuminance(color.rgb), 0.75) / 0.75;
                                        emission = pow2(pow2(emission)) * 6.5;
                                        color.gb *= 0.85;

                                        overlayNoiseIntensity = 0.1, overlayNoiseEmission = 0.8;
                                    }

                                    else {
                                        emission = max0(GetLuminance(color.rgb) - 0.5) * 3.0;

                                        #ifdef VOXY_PATCH
                                            emission += sqrt(max0(color.g * 2.55 - color.r - color.b)) * 5.0;
                                        #endif
                                    }
                                }
                                else /*if (mat < 10520)*/ { // Furnace:Lit
                                    lmCoordM.x *= 0.95;

                                    #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"

                                    float dotColor = dot(color.rgb, color.rgb);
                                    emission = 2.5 * dotColor * max0(pow2(pow2(pow2(color.r))) - color.b) + pow(dotColor * 0.35, 32.0);
                                    color.r *= 1.0 + 0.1 * emission;

                                    if (color.r > color.b * 2.0 && dotColor > 0.7) {
                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                        #endif
                                        #ifdef PURPLE_END_FIRE_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                        #endif
                                        overlayNoiseIntensity = 0.0;
                                    }
                                }
                            } else {
                                if (mat < 10524) { // Cactus
                                    float factor = sqrt1(color.r);
                                    smoothnessG = factor * 0.5;
                                    highlightMult = factor;

                                    mossNoiseIntensity = 0.0, sandNoiseIntensity = 0.3;
                                }
                                else /*if (mat < 10528)*/ { // Note Block, Jukebox
                                    float factor = color.r * 0.5;
                                    smoothnessG = factor;
                                    smoothnessD = factor;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif

                                    if (mat == 10526) { // Powered Note Block
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        } else {
                            if (mat < 10536) {
                                if (mat < 10532) { // Soul Torch
                                    noSmoothLighting = true; noDirectionalShading = true;
                                    lmCoordM.x = min(lmCoordM.x * 0.9, 0.77);

                                    if (color.b > 0.6) {
                                        emission = 2.7;
                                        color.rgb = pow1_5(color.rgb);
                                        color.r = min1(color.r + 0.1);

                                        overlayNoiseIntensity = 0.0;
                                    }
                                    emission += 0.0001; // No light reducing during noon

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(color, vec4(0.5, 1.0, 1.0, 1.0), emission, 3.0, lViewPos);
                                    #endif

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                                else /*if (mat < 10536)*/ { // Brown Mushroom Block
                                    if (color.r > color.g && color.g > color.b && color.b > 0.37) {
                                        #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    } else {
                                        float factor = pow2(color.r) * color.r * 0.8;
                                        highlightMult = 1.5;
                                        smoothnessG = factor;
                                        smoothnessD = factor * 0.9;

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.33;
                                        #endif
                                    }
                                }
                            } else {
                                if (mat < 10540) { // Red Mushroom Block
                                    if (color.r > color.g && color.g > color.b && color.b > 0.37) {
                                        #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    } else {
                                        float factor = min1(pow2(color.g) + 0.25);
                                        highlightMult = 1.5;
                                        smoothnessG = factor;
                                        smoothnessD = factor * 0.7;

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.33;
                                        #endif
                                    }
                                }
                                else /*if (mat < 10544)*/ { // Mushroom Stem,
                                    if (color.r > color.g && color.g > color.b && color.b < 0.6) {
                                        #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    } else {
                                        float factor = pow2(pow2(color.g));
                                        highlightMult = 1.5;
                                        smoothnessG = factor;
                                        smoothnessD = factor * 0.5;

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.33;
                                        #endif
                                    }
                                }
                            }
                        }
                    } else {
                        if (mat < 10560) {
                            if (mat < 10552) {
                                if (mat < 10548) { // Glow Lichen
                                    noSmoothLighting = true;

                                    #if GLOWING_LICHEN > 0
                                        float dotColor = dot(color.rgb, color.rgb);
                                        emission = min(pow2(pow2(dotColor) * dotColor) * 1.4 + dotColor * 0.9, 6.0);
                                        emission = mix(emission, dotColor * 1.5, min1(lViewPos / 96.0)); // Less noise in the distance

                                        #if GLOWING_LICHEN == 1
                                            float lichenSkyLightFactor = pow2(1.0 - min1(lmCoord.y * 2.9));
                                            emission *= lichenSkyLightFactor;

                                            color.r *= 1.0 + 0.15 * lichenSkyLightFactor;
                                        #else
                                            color.r *= 1.15;
                                        #endif
                                    #endif

                                    sandNoiseIntensity = 0.0, mossNoiseIntensity = 0.0;
                                }
                                else /*if (mat < 10552)*/ { // Enchanting Table:Base
                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (dotColor < 0.19 && color.r < color.b) {
                                        #include "/lib/materials/specificMaterials/terrain/obsidian.glsl"
                                    } else if (color.g >= color.r) {
                                        #include "/lib/materials/specificMaterials/terrain/diamondBlock.glsl"
                                        #ifdef EMISSIVE_ENCHANTING_TABLE
                                            emission = color.b + 0.4 + (1.0 - pow2(color.g)) * 0.8;
                                        #endif
                                    } else {
                                        smoothnessG = color.r * 0.3 + 0.1;
                                    }

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                            } else {
                                if (mat < 10556) { // End Portal Frame:Inactive
                                    noSmoothLighting = true;

                                    if (abs(color.r - color.g - 0.05) < 0.10) {
                                        #include "/lib/materials/specificMaterials/terrain/endStone.glsl"
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/endPortalFrame.glsl"
                                    }

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                                else /*if (mat < 10560)*/ { // End Portal Frame:Active
                                    noSmoothLighting = true;

                                    if (abs(color.r - color.g - 0.05) < 0.10) {
                                        #include "/lib/materials/specificMaterials/terrain/endStone.glsl"
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/endPortalFrame.glsl"

                                        vec2 absCoord = abs(fract(playerPos.xz + cameraPosition.xz) - 0.5);
                                        float maxCoord = max(absCoord.x, absCoord.y);
                                        if (maxCoord < 0.2505) { // End Portal Frame:Eye of Ender
                                            smoothnessG = 0.5;
                                            smoothnessD = 0.5;
                                            emission = pow2(min(color.g, 0.25)) * 170.0 * (0.28 - maxCoord);

                                            overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                        } else {
                                            float minCoord = min(absCoord.x, absCoord.y);
                                            if (CheckForColor(color.rgb, vec3(153, 198, 147))
                                            && minCoord > 0.25) { // End Portal Frame:Emissive Corner Bits
                                                emission = 1.4;
                                                color.rgb = vec3(0.45, 1.0, 0.6);

                                                overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
                                            }
                                        }
                                    }

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10568) {
                                if (mat < 10564) { // Lantern
                                    noSmoothLighting = true;
                                    lmCoordM.x = 0.77;

                                    #include "/lib/materials/specificMaterials/terrain/lanternMetal.glsl"

                                    emission = 4.3 * max0(color.r - color.b);
                                    emission += min(pow2(pow2(0.75 * dot(color.rgb, color.rgb))), 5.0);
                                    color.gb *= pow(vec2(0.8, 0.7), vec2(sqrt(emission) * 0.5));

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(color, vec4(1.0, 0.6, 0.2, 1.0), emission, 5.0, lViewPos);
                                    #endif

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif

                                    overlayNoiseIntensity = 0.0;

                                    #ifdef SS_BLOCKLIGHT // fix lanterns with custom models emitting blue light
                                        if (emission < 0.01) emission = 0.0;
                                    #endif

                                    #if defined SOUL_SAND_VALLEY_OVERHAUL_INTERNAL || defined PURPLE_END_FIRE_INTERNAL
                                        if(color.g > color.b){
                                            float uniformValue = 1.0;
                                            float gradient = 1.0;
                                            vec3 colorFire = vec3(0.0);
                                            #if defined NETHER
                                                #ifdef GBUFFERS_TERRAIN
                                                    float lanternOffset = 0.0;
                                                    if (mat == 10562) lanternOffset = 0.1; // Hanging Lantern
                                                    gradient = mix(1.0, 0.0, clamp01(blockUV.y - lanternOffset + 3.0 * blockUV.y - lanternOffset));
                                                #else
                                                    gradient = 0.0;
                                                #endif
                                                uniformValue = inSoulValley;
                                                colorFire = colorSoul;
                                            #endif
                                            #ifdef END
                                                colorFire = colorEndBreath;
                                            #endif
                                            color.rgb = mix(color.rgb, mix(color.rgb, vec3(GetLuminance(color.rgb)), 0.88), uniformValue * gradient);
                                            color.rgb *= mix(vec3(1.0), colorFire * 2.0, uniformValue * gradient);
                                        }
                                    #endif
                                }
                                else /*if (mat < 10568)*/ { // Soul Lantern
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.77); // consistency748523

                                    #include "/lib/materials/specificMaterials/terrain/lanternMetal.glsl"

                                    emission = 1.45 * max0(color.g - color.r * 2.0);
                                    emission += 1.17 * min(pow2(pow2(0.55 * dot(color.rgb, color.rgb))), 3.5);

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(color, vec4(0.5, 1.0, 1.0, 1.0), emission, 3.0, lViewPos);
                                    #endif

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif

                                    overlayNoiseIntensity = 0.3;
                                }
                            } else {
                                if (mat < 10572) { // Turtle Egg, Sniffer Egg
                                    smoothnessG = (color.r + color.g) * 0.35;
                                    smoothnessD = (color.r + color.g) * 0.25;
                                }
                                else /*if (mat < 10576)*/ { // Dragon Egg
                                    #ifdef EMISSIVE_DRAGON_EGG
                                        emission = float(color.b > 0.1) * 10.0 + 1.25;
                                    #endif
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10608) {
                        if (mat < 10592) {
                            if (mat < 10584) {
                                if (mat < 10580) { // Smoker:Lit
                                    lmCoordM.x *= 0.95;

                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.r > color.b * 2.0 && dotColor > 0.7) {
                                        emission = 2.5 * dotColor;
                                        color.r *= 1.5;

                                        overlayNoiseIntensity = 0.0;

                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                        #endif
                                        #ifdef PURPLE_END_FIRE_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                        #endif
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    }
                                }
                                else /*if (mat < 10584)*/ { // Blast Furnace:Lit
                                    lmCoordM.x *= 0.95;

                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.r > color.b * 2.0 && dotColor > 0.7) {
                                        emission = pow2(color.g) * (20.0 - 13.7 * float(color.b > 0.25));
                                        color.r *= 1.5;

                                        overlayNoiseIntensity = 0.0;

                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                        #endif
                                        #ifdef PURPLE_END_FIRE_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                        #endif
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10588) { // Coal Block
                                    smoothnessG = dot(color.rgb, vec3(0.5));
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;
                                }
                                else /*if (mat < 10592)*/ { // Respawn Anchor:Unlit
                                    noSmoothLighting = true;

                                    #include "/lib/materials/specificMaterials/terrain/cryingObsidian.glsl"
                                    emission += 0.2;

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10600) {
                                if (mat < 10596) { // Respawn Anchor:Lit
                                    noSmoothLighting = true;

                                    #include "/lib/materials/specificMaterials/terrain/cryingObsidian.glsl"

                                    vec2 absCoord = abs(signMidCoordPos);
                                    if (NdotU > 0.9 && max(absCoord.x, absCoord.y) < 0.754) { // Portal
                                        highlightMult = 0.0;
                                        smoothnessD = 0.0;
                                        emission = pow2(color.r) * color.r * 16.0;
                                        maRecolor = vec3(0.0);

                                        overlayNoiseIntensity = 0.0;
                                    } else if (color.r + color.g > 1.3) { // Respawn Anchor:Glowstone Part
                                        emission = 4.5 * sqrt3(max0(color.r + color.g - 1.3));
                                    }

                                    emission += 0.3;

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                                else /*if (mat < 10600)*/ { // Redstone Wire:Lit
                                    #include "/lib/materials/specificMaterials/terrain/redstoneBlock.glsl"

                                    #if COLORED_LIGHTING_INTERNAL == 0
                                        emission = pow2(min(color.r, 0.9)) * 4.0;
                                    #else
                                        vec3 colorP = color.rgb / glColor.rgb;
                                        emission = pow2((colorP.r + color.r) * 0.5) * 3.5;
                                    #endif

                                    color.gb *= 0.25;

                                    overlayNoiseIntensity = 0.0;
                                }
                            } else {
                                if (mat < 10604) { // Redstone Wire:Unlit
                                    #include "/lib/materials/specificMaterials/terrain/redstoneBlock.glsl"

                                    overlayNoiseIntensity = 0.0;
                                }
                                else /*if (mat < 10608)*/ { // Redstone Torch
                                    noSmoothLighting = true; noDirectionalShading = true;
                                    lmCoordM.x = min(lmCoordM.x * 0.9, 0.77);

                                    #include "/lib/materials/specificMaterials/terrain/redstoneTorch.glsl"
                                    emission += 0.0001; // No light reducing during noon

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(color, vec4(1.0, 0.0, 0.0, 1.0), emission, 5.0, lViewPos);
                                    #endif

                                    overlayNoiseIntensity = 0.0;
                                }
                            }
                        }
                    } else {
                        if (mat < 10624) {
                            if (mat < 10616) {
                                if (mat < 10612) { // Redstone Block
                                    #include "/lib/materials/specificMaterials/terrain/redstoneBlock.glsl"
                                    #ifdef EMISSIVE_REDSTONE_BLOCK
                                        emission = 0.75 + 3.0 * pow2(pow2(color.r));
                                        color.gb *= 0.65;

                                        #ifdef SNOWY_WORLD
                                            snowFactor = 0.0;
                                        #endif

                                        overlayNoiseIntensity = 0.5, sandNoiseIntensity = 0.5, mossNoiseIntensity = 0.5;
                                    #endif
                                }
                                else /*if (mat < 10616)*/ { // Redstone Ore:Unlit
                                    if (color.r - color.g > 0.2) { // Redstone Ore:Unlit:Redstone Part
                                        #include "/lib/materials/specificMaterials/terrain/redstoneBlock.glsl"
                                        #ifdef GLOWING_ORE_REDSTONE
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = color.r * pow1_5(color.r) * 4.0;

                                                overlayNoiseIntensity = 0.5, overlayNoiseEmission = 0.5;

                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.gb = mix(color.gb, color.gb * (1.0 - 0.9 * min1(GLOWING_ORE_MULT)), skyLightCheck);
                                                #else
                                                    color.gb *= 1.0 - 0.9 * min1(GLOWING_ORE_MULT);
                                                #endif
                                                emission *= min1(GLOWING_ORE_MULT);
                                            }
                                        #endif
                                    } else { // Redstone Ore:Unlit:Stone Part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10620) { // Redstone Ore:Lit
                                    if (color.r - color.g > 0.2) { // Redstone Ore:Lit:Redstone Part
                                        #include "/lib/materials/specificMaterials/terrain/redstoneBlock.glsl"
                                        emission = color.r * pow1_5(color.r) * 4.5;
                                        color.gb *= 0.1;

                                        overlayNoiseIntensity = 0.5, overlayNoiseEmission = 0.5;
                                    } else { // Redstone Ore:Lit:Stone Part
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                    noSmoothLighting = true;
                                }
                                else /*if (mat < 10624)*/ { // Deepslate Redstone Ore:Unlit
                                    if (color.r - color.g > 0.2) { // Deepslate Redstone Ore:Unlit:Redstone Part
                                        #include "/lib/materials/specificMaterials/terrain/redstoneBlock.glsl"
                                        #ifdef GLOWING_ORE_REDSTONE
                                            #ifdef IRIS_HAS_CONNECTED_TEXTURES
                                                if (textureLod(tex, midCoord, 4.0).a > 0.99)
                                            #endif
                                            {
                                                emission = color.r * pow1_5(color.r) * 4.0;

                                                overlayNoiseIntensity = 0.5, overlayNoiseEmission = 0.5;

                                                #ifdef SITUATIONAL_ORES
                                                    emission *= skyLightCheck;
                                                    color.gb = mix(color.gb, color.gb * (1.0 - 0.9 * min1(GLOWING_ORE_MULT)), skyLightCheck);
                                                #else
                                                    color.gb *= 1.0 - 0.9 * min1(GLOWING_ORE_MULT);
                                                #endif
                                                emission *= min1(GLOWING_ORE_MULT);
                                            }
                                        #endif
                                    } else { // Deepslate Redstone Ore:Unlit:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                }
                            }
                        } else {
                            if (mat < 10632) {
                                if (mat < 10628) { // Deepslate Redstone Ore:Lit
                                    if (color.r - color.g > 0.2) { // Deepslate Redstone Ore:Lit:Redstone Part
                                        #include "/lib/materials/specificMaterials/terrain/redstoneBlock.glsl"
                                        emission = color.r * pow1_5(color.r) * 4.7;
                                        color.gb *= 0.05;

                                        overlayNoiseIntensity = 0.5, overlayNoiseEmission = 0.5;
                                    } else { // Deepslate Redstone Ore:Lit:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    }
                                    noSmoothLighting = true;
                                }
                                else /*if (mat < 10632)*/ { // Cave Vines:No Glow Berries
                                    subsurfaceMode = 1;
                                    lmCoordM.x *= 0.875;

                                    sandNoiseIntensity = 0.0, mossNoiseIntensity = 0.0, isFoliage = true;
                                }
                            } else {
                                if (mat < 10636) { // Cave Vines:With Glow Berries
                                    subsurfaceMode = 1;
                                    lmCoordM.x *= 0.875;

                                    if (color.r > 0.64) {
                                        emission = color.r < 0.75 ? 2.5 : 8.0;
                                        color.rgb = color.rgb * vec3(1.0, 0.8, 0.6);
                                        isFoliage = false;
                                    } else {
                                        isFoliage = true;
                                    }

                                    sandNoiseIntensity = 0.0, mossNoiseIntensity = 0.0;
                                }
                                else /*if (mat < 10640)*/ { // Redstone Lamp:Unlit
                                    materialMask = OSIEBCA; // Intense Fresnel
                                    smoothnessG = color.r * 0.5 + 0.2;
                                    float factor = pow2(smoothnessG);
                                    highlightMult = factor * 2.0 + 1.0;
                                    smoothnessD = min1(factor * 2.0);

                                    overlayNoiseIntensity = 0.3;
                                }
                            }
                        }
                    }
                }
            } else {
                if (mat < 10704) {
                    if (mat < 10672) {
                        if (mat < 10656) {
                            if (mat < 10648) {
                                if (mat < 10644) { // Redstone Lamp:Lit
                                    noDirectionalShading = true;
                                    lmCoordM.x = 0.84;

                                    materialMask = OSIEBCA; // Intense Fresnel
                                    smoothnessG = color.r * 0.35 + 0.2;
                                    float factor = pow2(smoothnessG);
                                    highlightMult = factor * 2.0 + 1.0;
                                    smoothnessD = min1(factor * 2.0);

                                    if (color.b > 0.1) {
                                        float dotColor = dot(color.rgb, color.rgb);
                                        #if MC_VERSION >= 11300
                                            emission = pow2(dotColor) * 1.0;
                                        #else
                                            emission = dotColor * 1.2;
                                        #endif
                                        color.rgb = pow1_5(color.rgb);
                                        maRecolor = vec3(emission * 0.2);

                                        overlayNoiseIntensity = 0.3;
                                    }

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 5.0, lViewPos);
                                    #endif
                                }
                                else /*if (mat < 10648)*/ { // Repeater, Comparator
                                    noSmoothLighting = true;

                                    #if ANISOTROPIC_FILTER > 0 && !defined IPBR_COMPAT_MODE
                                        color = texture2D(tex, texCoord); // Fixes artifacts
                                        color.rgb *= glColor.rgb;
                                    #endif

                                    vec3 absDif = abs(vec3(color.r - color.g, color.g - color.b, color.r - color.b));
                                    float maxDif = max(absDif.r, max(absDif.g, absDif.b));
                                    if (maxDif > 0.125 || color.b > 0.99) { // Redstone Parts
                                        if (color.r < 0.999 && color.b > 0.4) color.gb *= 0.5; // Comparator:Emissive Wire

                                        #include "/lib/materials/specificMaterials/terrain/redstoneTorch.glsl"

                                        overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.2;
                                    } else { // Quartz Base
                                        float factor = pow2(color.g) * 0.6;

                                        smoothnessG = factor;
                                        highlightMult = 1.0 + 2.5 * factor;
                                        smoothnessD = factor;
                                    }
                                }
                            } else {
                                if (mat < 10652) { // Shroomlight
                                    noSmoothLighting = true; noDirectionalShading = true;
                                    lmCoordM = vec2(1.0, 0.0);

                                    float dotColor = dot(color.rgb, color.rgb);
                                    emission = min(pow2(pow2(pow2(dotColor * 0.6))), 6.0) * 0.8 + 0.5;

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 2.5, lViewPos);
                                    #endif

                                    overlayNoiseIntensity = 0.3;
                                }
                                else /*if (mat < 10656)*/ { // Campfire:Lit
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                        #ifdef GBUFFERS_COLORWHEEL
                                            fractPos = blockUV - 0.5;
                                        #endif
                                        lmCoordM.x = pow2(pow2(smoothstep1(1.0 - 0.4 * dot(fractPos.xz, fractPos.xz))));

                                        #ifdef LIGHTMAP_CURVES
                                            float campfireBrightnessFactor = mix(1.0, 0.9, clamp01(UPPER_LIGHTMAP_CURVE - 1.0));
                                            lmCoordM.x *= campfireBrightnessFactor;
                                        #endif
                                    #endif

                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.r > color.b && color.r - color.g < 0.15 && dotColor < 1.4) {
                                        #include "/lib/materials/specificMaterials/terrain/oakWood.glsl"
                                    } else if (color.r > color.b || dotColor > 2.9) {
                                        noDirectionalShading = true;
                                        emission = 3.5;
                                        color.rgb *= sqrt1(GetLuminance(color.rgb));

                                        overlayNoiseIntensity = 0.0;

                                        #if defined SOUL_SAND_VALLEY_OVERHAUL_INTERNAL || defined PURPLE_END_FIRE_INTERNAL
                                            float uniformValue = 1.0;
                                            vec3 colorFire = vec3(0.0);
                                            float gradient = 0.0;
                                            #if defined NETHER
                                                uniformValue = inSoulValley;
                                                colorFire = colorSoul;
                                                #ifdef GBUFFERS_TERRAIN
                                                    gradient = mix(1.0, 0.0, clamp01(blockUV.y + 0.5 * blockUV.y));
                                                #elif defined GBUFFERS_HAND
                                                    float handUV = gl_FragCoord.y / viewHeight;
                                                    gradient = mix(1.0, 0.0, handUV + 0.4);
                                                #endif
                                            #endif
                                            #ifdef END
                                                colorFire = colorEndBreath;
                                                #ifdef GBUFFERS_TERRAIN
                                                    gradient = mix(1.0, 0.0, clamp01(blockUV.y + 0.07 - 1.1 * clamp01(sin(texture2DLod(noisetex, vec2(frameTimeCounter * 0.01), 0.0).r) * blockUV.y)));
                                                #elif defined GBUFFERS_HAND
                                                    float handUV = gl_FragCoord.y / viewHeight;
                                                    gradient = mix(1.0, 0.0, clamp01(handUV + 0.3 - 1.3 * clamp01(sin(texture2DLod(noisetex, vec2(frameTimeCounter * 0.01), 0.0).r) * handUV)));
                                                #endif
                                            #endif
                                            color.rgb = mix(color.rgb, mix(color.rgb, vec3(GetLuminance(color.rgb)), 0.88), uniformValue * gradient);
                                            color.rgb *= mix(vec3(1.0), colorFire * 2.0, uniformValue * gradient);
                                        #endif
                                    }
                                }
                            }
                        } else {
                            if (mat < 10664) {
                                if (mat < 10660) { // Soul Campfire:Lit
                                    #if COLORED_LIGHTING_INTERNAL == 0
                                        noSmoothLighting = true;
                                    #else
                                        #ifdef GBUFFERS_TERRAIN
                                            vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                            lmCoordM.x = pow2(pow2(smoothstep1(1.0 - 0.4 * dot(fractPos.xz, fractPos.xz))));
                                            lmCoordM.x *= 0.95;
                                        #endif
                                    #endif

                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.r > color.b) {
                                        #include "/lib/materials/specificMaterials/terrain/oakWood.glsl"
                                    } else if (color.g - color.r > 0.1 || dotColor > 2.9) {
                                        noDirectionalShading = true;
                                        emission = 2.1;
                                        color.rgb *= sqrt1(GetLuminance(color.rgb));

                                        overlayNoiseIntensity = 0.0;
                                    }

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                                else /*if (mat < 10664)*/ { // Campfire:Unlit, Soul Campfire:Unlit
                                    noSmoothLighting = true;

                                    if (color.r > color.b) {
                                        #include "/lib/materials/specificMaterials/terrain/oakWood.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10668) { // Observer
                                    if (color.r > 0.1 && color.g + color.b < 0.1) {
                                        #include "/lib/materials/specificMaterials/terrain/redstoneTorch.glsl"

                                        overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.15;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                    }
                                }
                                else if (mat < 10671) { // Wool+, Carpet+ except Lime, MV: Tripwire
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                } else /*(mat == )*/ { // Tripwire
                                    redstoneIPBR(color.rgb, emission);
                                }
                            }
                        }
                    } else {
                        if (mat < 10688) {
                            if (mat < 10680) {
                                if (mat < 10676) { // Bone Block
                                    smoothnessG = color.r * 0.2;
                                    smoothnessD = smoothnessG;

                                    #ifdef GBUFFERS_TERRAIN
                                        DoBrightBlockTweaks(color.rgb, 0.5, shadowMult, highlightMult);
                                    #endif

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.33;
                                    #endif
                                }
                                else /*if (mat < 10680)*/ { // Barrel, Beehive, Bee Nest, Honeycomb Block
                                    #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
                                }
                            } else {
                                if (mat < 10684) { // Ochre Froglight
                                    float frogPow = 8.0;
                                    #include "/lib/materials/specificMaterials/terrain/froglights.glsl"

                                    overlayNoiseIntensity = 0.3;
                                }
                                else /*if (mat < 10688)*/ { // Verdant Froglight
                                    float frogPow = 16.0;
                                    #include "/lib/materials/specificMaterials/terrain/froglights.glsl"

                                    overlayNoiseIntensity = 0.3;
                                }
                            }
                        } else {
                            if (mat < 10695) {
                                if (mat < 10692) { // Pearlescent Froglight
                                    float frogPow = 24.0;
                                    #include "/lib/materials/specificMaterials/terrain/froglights.glsl"

                                    overlayNoiseIntensity = 0.3;
                                }
                                else /*if (mat < 10695)*/ { // Reinforced Deepslate
                                    if (abs(color.r - color.g) < 0.01) { // Reinforced Deepslate:Deepslate Part
                                        #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    } else { // Reinforced Deepslate:Sculk
                                        float boneFactor = max0(color.r * 1.25 - color.b);

                                        if (boneFactor < 0.0001) emission = 0.15;

                                        smoothnessG = min1(boneFactor * 1.7);
                                        smoothnessD = smoothnessG;
                                    }
                                }
                            } else {
                                if (mat < 10700) { // Sculk, Sculk Catalyst, Sculk Vein, Sculk Sensor:Unlit
                                    float boneFactor = max0(color.r * 1.25 - color.b);

                                    float sculkEmission = pow2(max0(color.g - color.r)) * 1.7;
                                    if (boneFactor < 0.0001) {
                                        overlayNoiseIntensity = 0.0;
                                        #ifdef INTENSE_DEEP_DARK
                                            emission = mix(sculkEmission, sculkEmission * 5.0, darknessFactor);
                                        #else
                                            emission = sculkEmission;
                                        #endif

                                        #ifdef GBUFFERS_TERRAIN
                                            vec2 bpos = floor(playerPos.xz + cameraPosition.xz + 0.501)
                                                    + floor(playerPos.y + cameraPosition.y + 0.501);
                                            bpos = bpos * 0.01 + 0.003 * frameTimeCounter;
                                            emission *= pow2(texture2DLod(noisetex, bpos, 0.0).r * pow1_5(texture2DLod(noisetex, bpos * 0.5, 0.0).r));
                                            emission *= 6.0;
                                        #endif
                                    }

                                    smoothnessG = min1(boneFactor * 1.7);
                                    smoothnessD = smoothnessG;

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                                else /*if (mat < 10704)*/ { // Sculk Shrieker
                                    float boneFactor = max0(color.r * 1.25 - color.b);

                                    if (boneFactor < 0.0001) {
                                        overlayNoiseIntensity = 0.0;
                                        float sculkEmission = pow2(max0(color.g - color.r)) * 2.0;
                                        #ifdef INTENSE_DEEP_DARK
                                            emission = mix(sculkEmission, sculkEmission * 3.0, darknessFactor);
                                        #else
                                            emission = sculkEmission;
                                        #endif

                                        #ifdef GBUFFERS_TERRAIN
                                            vec2 coordFactor = abs(fract(playerPos.xz + cameraPosition.xz) - 0.5);
                                            float coordFactorM = max(coordFactor.x, coordFactor.y);
                                            if (coordFactorM < 0.43) emission += color.g * 7.0;
                                        #endif
                                    }

                                    smoothnessG = min1(boneFactor * 1.7);
                                    smoothnessD = smoothnessG;

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10736) {
                        if (mat < 10720) {
                            if (mat < 10712) {
                                if (mat < 10708) { // Sculk Sensor:Lit
                                    lmCoordM = vec2(0.0, 0.0);
                                    emission = pow2(max0(color.g - color.r)) * 7.0 + 0.7;

                                    overlayNoiseIntensity = 0.0;
                                    redstoneIPBR(color.rgb, emission);
                                }
                                else /*if (mat < 10712)*/ { // Spawner
                                    smoothnessG = color.b + 0.2;
                                    smoothnessD = smoothnessG;

                                    emission = 7.0 * float(CheckForColor(color.rgb, vec3(110, 4, 83)));

                                    overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.15;
                                }
                            } else {
                                if (mat < 10716) { // Tuff++
                                    smoothnessG = color.r * 0.4;
                                    smoothnessD = smoothnessG;
                                }
                                else /*if (mat < 10720)*/ { // Clay
                                    highlightMult = 2.0;
                                    smoothnessG = pow2(pow2(color.g)) * 0.5;
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG * 0.7;

                                    #ifdef GBUFFERS_TERRAIN
                                        DoOceanBlockTweaks(smoothnessD);
                                    #endif

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10728) {
                                if (mat < 10724) { // Ladder
                                    noSmoothLighting = true;
                                }
                                else /*if (mat < 10728)*/ { // Gravel, Suspicious Gravel
                                    #include "/lib/materials/specificMaterials/terrain/stone.glsl"

                                    #ifdef GBUFFERS_TERRAIN
                                        DoOceanBlockTweaks(smoothnessD);
                                    #endif

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 1.25;
                                    #endif
                                }
                            } else {
                                if (mat < 10732) { // Flower Pot, Potted Stuff:Without Subsurface
                                    noSmoothLighting = true;

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;
                                }
                                else /*if (mat < 10736)*/ { // Potted Stuff:With Subsurface
                                    noSmoothLighting = true;

                                    float NdotE = dot(normalM, eastVec);
                                    if (abs(abs(NdotE) - 0.5) < 0.4) {
                                        subsurfaceMode = 1, noDirectionalShading = true, isFoliage = true;
                                    }

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;

                                    #if defined GBUFFERS_TERRAIN && (EMISSIVE_FLOWERS > 0 || defined EMISSIVE_BLOOD_MOON_FLOWERS)
                                        if (mat == 10735 && blockUV.y > 0.4 && isNonGreen(color.rgb)) { // Potted Flowers
                                            isFoliage = false;
                                            #if EMISSIVE_FLOWERS > 0
                                                emission = 2.0 * skyLightCheck;
                                                #if EMISSIVE_FLOWERS == 2
                                                    emission = max(emission, rainFactor + 1.0 * rainFactor);
                                                #endif
                                                #if EMISSIVE_FLOWERS_TYPE == 1
                                                    if (color.b < max(color.r, color.g * 1.1) * 0.95) emission = 0.0;
                                                #elif EMISSIVE_FLOWERS_TYPE == 2
                                                    if (color.r < max(color.b * 1.15, color.g * 1.1) * 0.95) emission = 0.0;
                                                #endif
                                            #else
                                                emission = int(color.r > max(color.b * 1.15, color.g * 2.5) * 0.95) * getBloodMoon(sunVisibility);
                                            #endif
                                            emission *= EMISSIVE_FLOWERS_STRENGTH;
                                        }
                                    #endif
                                }
                            }
                        }
                    } else {
                        if (mat < 10752) {
                            if (mat < 10744) {
                                if (mat < 10738) { // Pitcher Crop
                                    noSmoothLighting = true;
                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;

                                    #if EMISSIVE_FLOWERS > 0 && EMISSIVE_FLOWERS_TYPE < 2 && defined GBUFFERS_TERRAIN
                                        if (isNonGreen(vec3(color.r * 0.97, color.g, color.b * 1.23))) { // Flowers
                                            emission = 1.5 * skyLightCheck;

                                            #if EMISSIVE_FLOWERS == 2
                                                emission = max(emission, rainFactor + 1.0 * rainFactor);
                                            #endif
                                            emission *= EMISSIVE_FLOWERS_STRENGTH;
                                        }
                                    #endif

                                    float NdotE = dot(normalM, eastVec);
                                    if (abs(abs(NdotE) - 0.5) < 0.4) {
                                        subsurfaceMode = 1, noDirectionalShading = true, isFoliage = true;
                                    } else {
                                        emission = 0.0;
                                    }
                                }
                                else if (mat < 10740) { // Structure Block, Jigsaw Block, Test Block, Test Instance Block
                                    float blockRes = absMidCoordPos.x * atlasSize.x;
                                    vec2 signMidCoordPosM = (floor((signMidCoordPos + 1.0) * blockRes) + 0.5) / blockRes - 1.0;
                                    float dotsignMidCoordPos = dot(signMidCoordPosM, signMidCoordPosM);
                                    float lBlockPosM = pow2(max0(1.0 - 1.125 * pow2(dotsignMidCoordPos)));

                                    emission = 2.5 * lBlockPosM + 1.0;
                                    color.rgb = mix(color.rgb, pow2(color.rgb), 0.5);

                                    overlayNoiseIntensity = 0.45, overlayNoiseEmission = 0.2;
                                }
                                else /*if (mat < 10744)*/ { // Chain
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.77); // consistency748523

                                    #include "/lib/materials/specificMaterials/terrain/lanternMetal.glsl"
                                }
                            } else {
                                if (mat < 10748) { // Soul Sand, Soul Soil
                                    smoothnessG = color.r * 0.4;
                                    smoothnessD = color.r * 0.25;
                                    #if defined GBUFFERS_TERRAIN && defined EMISSIVE_SOUL_SAND
                                        if (mat == 10744) {
                                            vec3 playerPosM = playerPos + relativeEyePosition;
                                            if (length(playerPosM) < 3.0 && length(playerPosM.y) > 1.1)
                                            if (color.r < 0.26 && color.r > 0.257 && color.g < 0.2 && color.b < 0.17 && blockUV.y > 0.9999 // A lot of hardcoded stuff
                                            &&(blockUV.x > 0.625 && blockUV.z < 0.5 && blockUV.z > 0.375
                                            || blockUV.x < 0.5 && blockUV.x > 0.25 && blockUV.z < 0.1875
                                            || blockUV.x < 0.375 && blockUV.z > 0.8125)) {
                                                float randomPos = step(0.5, hash13(mod(floor(worldPos + atMidBlock / 64) + frameTimeCounter * 0.0001, vec3(100))));
                                                vec2 flickerNoiseBlock = texture2DLod(noisetex, vec2(frameTimeCounter * 0.04), 0.0).rb;
                                                float noise = mix(1.0, min1(max(flickerNoiseBlock.r, flickerNoiseBlock.g) * 1.7), 0.6) * (clamp(3.0 / length(vec3(playerPosM.x * 1.5, playerPosM.y, playerPosM.z * 1.5)) - 1.0, 0.0, 0.25) * 2.0) * randomPos;
                                                color.rgb = changeColorFunction(color.rgb, 80.0, colorSoul, noise);
                                                emission = 4.0 * noise;
                                                overlayNoiseIntensity = 1.0 - noise;
                                            }
                                        }
                                    #endif
                                }
                                else /*if (mat < 10752)*/ { // Dried Kelp Block
                                    smoothnessG = pow2(color.b) * 0.8;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10760) {
                                if (mat < 10756) { // Bamboo
                                    #if ANISOTROPIC_FILTER == 0
                                        vec4 checkColor = color;
                                    #else
                                        vec4 checkColor = texture2DLod(tex, texCoord, 0); // Fixes artifacts
                                    #endif
                                    if (
                                        CheckForColor(checkColor.rgb, vec3(55, 90, 21)) ||
                                        CheckForColor(checkColor.rgb, vec3(47, 69, 23)) ||
                                        CheckForColor(checkColor.rgb, vec3(82, 137, 25)) ||
                                        CheckForColor(checkColor.rgb, vec3(103, 161, 36)) ||
                                        CheckForColor(checkColor.rgb, vec3(69, 118, 22)) ||
                                        CheckForColor(checkColor.rgb, vec3(43, 62, 22)) ||
                                        CheckForColor(checkColor.rgb, vec3(105, 144, 34)) ||
                                        CheckForColor(checkColor.rgb, vec3(80, 117, 22)) ||
                                        CheckForColor(checkColor.rgb, vec3(148, 187, 79)) ||
                                        CheckForColor(checkColor.rgb, vec3(86, 129, 18))
                                    ) {
                                        subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;
                                    }
                                    // No further material properties as bamboo jungles are already slow

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0, isFoliage = true;
                                }
                                else /*if (mat < 10760)*/ { // Block of Bamboo, Bamboo Planks++
                                    #include "/lib/materials/specificMaterials/planks/bambooPlanks.glsl"
                                }
                            } else {
                                if (mat < 10764) { // Cherry Planks++
                                    #include "/lib/materials/specificMaterials/planks/cherryPlanks.glsl"
                                }
                                else /*if (mat < 10768)*/ { // Cherry Log, Cherry Wood
                                    if (color.g > 0.33) { // Cherry Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/cherryPlanks.glsl"
                                    } else { // Cherry Log:Wood Part, Cherry Wood
                                        smoothnessG = pow2(color.r);
                                        smoothnessD = smoothnessG;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (mat < 10896) {
                if (mat < 10832) {
                    if (mat < 10800) {
                        if (mat < 10784) {
                            if (mat < 10776) {
                                if (mat < 10772) { // Torchflower
                                    #include "/lib/materials/specificMaterials/terrain/torchflower.glsl"
                                }
                                else /*if (mat < 10776)*/ { // Potted Torchflower
                                    noSmoothLighting = true;

                                    float NdotE = dot(normalM, eastVec);
                                    if (abs(abs(NdotE) - 0.5) < 0.4) {
                                        #include "/lib/materials/specificMaterials/terrain/torchflower.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10780) { // Crimson Fungus, Warped Fungus
                                    noSmoothLighting = true;

                                    if (color.r > 0.91) {
                                        emission = 3.0 * color.g;
                                        color.r *= 1.2;
                                        maRecolor = vec3(0.1);

                                        overlayNoiseIntensity = 0.5;
                                    }

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0; isFoliage = false;
                                }
                                else /*if (mat < 10784)*/ { // Potted Crimson Fungus, Potted Warped Fungus
                                    noSmoothLighting = true;

                                    float NdotE = dot(normalM, eastVec);
                                    if (abs(abs(NdotE) - 0.5) < 0.4) {
                                        if (color.r > 0.91) {
                                            emission = 3.0 * color.g;
                                            color.r *= 1.2;
                                            maRecolor = vec3(0.1);
                                        }
                                    }

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;
                                }
                            }
                        } else {
                            if (mat < 10792) {
                                if (mat < 10788) { // Calibrated Sculk Sensor:Unlit
                                    #if ANISOTROPIC_FILTER == 0
                                        vec4 checkColor = color;
                                    #else
                                        vec4 checkColor = texture2D(tex, texCoord); // Fixes artifacts
                                    #endif
                                    if (checkColor.r + checkColor.b > checkColor.g * 2.2 || checkColor.r > 0.99) { // Amethyst Part
                                        #if GLOWING_AMETHYST >= 1
                                            #if defined GBUFFERS_TERRAIN && !defined IPBR_COMPAT_MODE
                                                vec2 absCoord = abs(signMidCoordPos);
                                                float maxBlockPos = max(absCoord.x, absCoord.y);
                                                emission = pow2(max0(1.0 - maxBlockPos) * color.g) * 5.4 + 1.2 * color.g;

                                                color.g *= 1.0 - emission * 0.07;
                                                color.rgb *= color.g;
                                            #else
                                                emission = pow2(color.g + color.b) * 0.32;
                                            #endif
                                        #endif

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.66;
                                        #endif
                                    } else { // Sculk Part
                                        float boneFactor = max0(color.r * 1.25 - color.b);

                                        if (boneFactor < 0.0001) emission = pow2(max0(color.g - color.r));

                                        smoothnessG = min1(boneFactor * 1.7);
                                        smoothnessD = smoothnessG;
                                    }

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif

                                    overlayNoiseIntensity = 0.0;
                                }
                                else /*if (mat < 10792)*/ { // Calibrated Sculk Sensor:Lit
                                    lmCoordM = vec2(0.0, 0.0);

                                    #if ANISOTROPIC_FILTER == 0
                                        vec4 checkColor = color;
                                    #else
                                        vec4 checkColor = texture2D(tex, texCoord); // Fixes artifacts
                                    #endif
                                    if (checkColor.r + checkColor.b > checkColor.g * 2.2 || checkColor.r > 0.99) { // Amethyst Part
                                        lmCoordM.x = 1.0;

                                        #if GLOWING_AMETHYST >= 1
                                            #if defined GBUFFERS_TERRAIN && !defined IPBR_COMPAT_MODE
                                                vec2 absCoord = abs(signMidCoordPos);
                                                float maxBlockPos = max(absCoord.x, absCoord.y);
                                                emission = pow2(max0(1.0 - maxBlockPos) * color.g) * 5.4 + 1.2 * color.g;

                                                color.g *= 1.0 - emission * 0.07;
                                                color.rgb *= color.g;
                                            #else
                                                emission = pow2(color.g + color.b) * 0.32;
                                            #endif
                                        #endif

                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.66;
                                        #endif
                                    } else if (checkColor.g + checkColor.b > checkColor.r * 2.2) { // Sculk Part
                                        emission = pow2(max0(color.g - color.r)) * 7.0 + 0.7;
                                    }

                                    overlayNoiseIntensity = 0.0;
                                    redstoneIPBR(color.rgb, emission);
                                }
                            } else {
                                if (mat < 10796) { // Oak Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/oakPlanks.glsl"

                                    if (mat == 10795) { // Powered Oak Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10800)*/ { // Spruce Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"

                                    if (mat == 10799) { // Powered Spruce Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        }
                    } else {
                        if (mat < 10816) {
                            if (mat < 10808) {
                                if (mat < 10804) { // Birch Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/birchPlanks.glsl"

                                    if (mat == 10803) { // Powered Birch Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10808)*/ { // Jungle Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/junglePlanks.glsl"

                                    if (mat == 10807) { // Powered Jungle Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            } else {
                                if (mat < 10812) { // Acacia Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/acaciaPlanks.glsl"

                                    if (mat == 10811) { // Powered Acacia Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10816)*/ { // Dark Oak Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/darkOakPlanks.glsl"

                                    if (mat == 10815) { // Powered Dark Oak Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        } else {
                            if (mat < 10824) {
                                if (mat < 10820) { // Mangrove Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/mangrovePlanks.glsl"

                                    if (mat == 10819) { // Powered Mangrove Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10824)*/ { // Crimson Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/crimsonPlanks.glsl"

                                    if (mat == 10823) { // Powered Crimson Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            } else {
                                if (mat < 10828) { // Warped Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/warpedPlanks.glsl"

                                    if (mat == 10827) { // Powered Warped Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10832)*/ { // Bamboo Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/bambooPlanks.glsl"

                                    if (mat == 10831) { // Powered Bamboo Door
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10864) {
                        if (mat < 10848) {
                            if (mat < 10840) {
                                if (mat < 10836) { // Cherry Door, Cherry Trapdoor
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/cherryPlanks.glsl"

                                    if (mat == 10835) { // Powered Cherry Door and Cherry Trapdoor
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                                else /*if (mat < 10840)*/ { // Brewing Stand
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 worldPos = playerPos + cameraPosition;
                                        vec3 fractPos = fract(worldPos.xyz);
                                        vec3 coordM = abs(fractPos.xyz - 0.5);
                                        float cLength = dot(coordM, coordM) * 1.3333333;
                                        cLength = pow2(1.0 - cLength);

                                        if (color.r + color.g > color.b * 3.0 && max(coordM.x, coordM.z) < 0.07) {
                                            emission = 2.5 * pow1_5(cLength);
                                        } else {
                                            lmCoordM.x = max(lmCoordM.x * 0.9, cLength);

                                            #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                                        }
                                    #else
                                        emission = max0(color.r + color.g - color.b * 1.8 - 0.3) * 2.2;
                                    #endif

                                    overlayNoiseIntensity = 0.0;

                                    #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                        color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                    #endif
                                    #ifdef PURPLE_END_FIRE_INTERNAL
                                        color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                    #endif
                                }
                            } else {
                                if (mat < 10841) { // Lime Concrete
                                    smoothnessG = 0.4;
                                    highlightMult = 1.5;
                                    smoothnessD = 0.3;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.2;
                                    #endif

                                    #ifdef GREEN_SCREEN_LIME
                                        materialMask = OSIEBCA * 240.0; // Green Screen Lime Blocks
                                    #endif
                                }
                                else if (mat < 10844) { // Blue Carpet, Blue Wool
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif

                                    #ifdef BLUE_SCREEN
                                        materialMask = OSIEBCA * 239.0; // Blue Screen Blue Blocks
                                    #endif
                                }
                                else if (mat < 10846) { // Lime Carpet, Lime Wool, MV: Green stuff
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif

                                    #ifdef GREEN_SCREEN_LIME
                                        materialMask = OSIEBCA * 240.0; // Green Screen Lime Blocks
                                    #endif
                                }
                                else /*if (mat < 10847)*/ { // Blue Concrete
                                    smoothnessG = 0.4;
                                    highlightMult = 1.5;
                                    smoothnessD = 0.3;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.2;
                                    #endif

                                    #ifdef BLUE_SCREEN
                                        materialMask = OSIEBCA * 239.0; // Blue Screen Blue Blocks
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 10856) {
                                if (mat < 10852) { // Crafter
                                    smoothnessG = pow2(color.b);
                                    smoothnessD = max(smoothnessG, 0.2);

                                    if (color.r > 2.5 * (color.g + color.b)) {
                                        emission = 4.0;
                                        color.rgb *= color.rgb;
                                    }
                                }
                                else /*if (mat < 10856)*/ { // Copper Bulb:BrighterOnes
                                    #include "/lib/materials/specificMaterials/terrain/copperBulb.glsl"
                                }
                            } else {
                                if (mat < 10860) { // Copper Bulb:DimmerOnes
                                    #include "/lib/materials/specificMaterials/terrain/copperBulb.glsl"
                                    emission *= 0.85;
                                }
                                else /*if (mat < 10864)*/ { // Copper Door+, Copper Trapdoor+
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"

                                    if (mat == 10863) { // Powered Copper Door+, Copper Trapdoor+
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        }
                    } else {
                        if (mat < 10880) {
                            if (mat < 10872) {
                                if (mat < 10868) { // Copper Trapdoor+
                                    #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"
                                }
                                else /*if (mat < 10872)*/ { // Trial Spawner:NotOminous:Active, Vault:NotOminous:Active
                                    smoothnessG = max0(color.b - color.r * 0.5);
                                    smoothnessD = smoothnessG;

                                    emission = max0(color.r - color.b) * 3.0;
                                    color.rgb = pow(color.rgb, vec3(1.0 + 0.5 * sqrt(emission)));
                                }
                            } else {
                                if (mat < 10876) { // Trial Spawner:Inactive, Vault:Inactive
                                    smoothnessG = max0(color.b - color.r * 0.5);
                                    smoothnessD = smoothnessG;
                                }
                                else /*if (mat < 10880)*/ { // Trial Spawner:Ominous:Active, Vault:Ominous:Active
                                    float maxComponent = max(max(color.r, color.g), color.b);
                                    float minComponent = min(min(color.r, color.g), color.b);
                                    float saturation = (maxComponent - minComponent) / (1.0 - abs(maxComponent + minComponent - 1.0));

                                    smoothnessG = max0(color.b - pow2(saturation) * 0.5) * 0.5 + 0.1;
                                    smoothnessD = smoothnessG;

                                    emission = saturation > 0.5 ? 4.0 : 0.0;
                                    color.rgb = pow(color.rgb, vec3(1.0 + (0.3 + 0.5 * color.r) * emission));
                                }
                            }
                        } else {
                            if (mat < 10888) {
                                if (mat < 10884) { // ACT - WSR non-solid blocks with no properties

                                }
                                else /*if (mat < 10888)*/ { // Weeping Vines, Twisting Vines
                                    noSmoothLighting = true;

                                    #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                        doTileRandomisation = false;
                                    #endif

                                    if (color.r > 0.91 && mat == 10884) {
                                        emission = 3.0 * color.g;
                                        color.r *= 1.2;
                                        maRecolor = vec3(0.1);
                                    }
                                    isFoliage = false;
                                }
                            } else {
                                if (mat < 10891) { // Hay Block
                                    smoothnessG = pow2(color.r) * 0.5;
                                    highlightMult *= 1.5;
                                    smoothnessD = float(color.r > color.g * 2.0) * 0.3;
                                }
                                else /*if (mat < 10896)*/ { // Iron Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                                    color.rgb *= 0.9;
                                    if (mat == 10893) { // Powered Iron Door and Iron Trapdoor
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (mat < 10960) {
                    if (mat < 10928) {
                        if (mat < 10900) { // Iron Trapdoor
                            #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                            color.rgb *= 0.9;
                                    if (mat == 10899) { // Powered Iron Door and Iron Trapdoor
                                        redstoneIPBR(color.rgb, emission);
                                    }
                        }
                        else if (mat < 10923) { // Candles:Lit, Candle Cakes:Lit
                            #include "/lib/materials/specificMaterials/terrain/candle.glsl"
                        }
                        else if (mat < 10924) { // Pale Hanging Moss
                            subsurfaceMode = 3, centerShadowBias = true; noSmoothLighting = true;

                            #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                doTileRandomisation = false;
                            #endif

                            float factor = color.g;
                            smoothnessG = factor * 0.5;
                            highlightMult = factor * 4.0 + 2.0;
                            #ifdef GBUFFERS_TERRAIN
                                float fresnel = clamp(1.0 + dot(normalM, normalize(viewPos)), 0.0, 1.0);
                                highlightMult *= 1.0 - pow2(pow2(fresnel));
                            #else
                                highlightMult *= 0.5;
                            #endif

                            sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0, isFoliage = true;
                        }
                        else /*if (mat < 10928)*/ { // Moss Block+, Pale Moss Block+
                            #include "/lib/materials/specificMaterials/terrain/cobblestone.glsl"
                            mossNoiseIntensity = 0.0;
                        }
                    } else {
                        if (mat < 10944) {
                            if (mat < 10936) {
                                if (mat < 10932) { // Pale Oak Planks++
                                    #include "/lib/materials/specificMaterials/planks/paleOakPlanks.glsl"
                                }
                                else /*if (mat < 10936)*/ { // // Pale Oak Log, Pale Oak Wood
                                    if (color.g > 0.45) { // Pale Oak Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/paleOakPlanks.glsl"
                                    } else { // Pale Oak Log:Wood Part, Pale Oak Wood
                                        #include "/lib/materials/specificMaterials/terrain/paleOakWood.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10940) { // Pale Oak Door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/paleOakPlanks.glsl"
                                }
                                else /*if (mat < 10944)*/ { // Resin++
                                    smoothnessG = color.r * 0.25;
                                    smoothnessD = smoothnessG;
                                }
                            }
                        } else {
                            if (mat < 10952) {
                                if (mat < 10948) { // Creaking Heart: Inactive
                                    #include "/lib/materials/specificMaterials/terrain/paleOakWood.glsl"
                                }
                                else /*if (mat < 10952)*/ { // Creaking Heart: Active
                                    #include "/lib/materials/specificMaterials/terrain/paleOakWood.glsl"

                                    if (color.r + color.g > color.b * 4.0) {
                                        emission = pow2(color.r) * 2.5 + 0.2;
                                    }
                                }
                            } else {
                                if (mat < 10956) { // Snow: Layers 1 to 7
                                    #include "/lib/materials/specificMaterials/terrain/snow.glsl"

                                    #if defined GBUFFERS_TERRAIN && defined TAA
                                        float snowFadeOut = 0.0;
                                        snowFadeOut = clamp01((playerPos.y) * 0.1);
                                        snowFadeOut *= clamp01((lViewPos - 64.0) * 0.01);

                                        if (dither + 0.25 < snowFadeOut) discard;
                                    #endif

                                    overlayNoiseIntensity = 0.0;
                                }
                                else /*if (mat < 10960)*/ { // Target Block: Inactive
                                    smoothnessG = pow2(color.r) * 0.5;
                                    smoothnessD = smoothnessG * 0.5;
                                }
                            }
                        }
                    }
                } else {
                    if (mat < 10992) {
                        if (mat < 10976) {
                            if (mat < 10968) {
                                if (mat < 10964) { // Target Block: Active
                                    smoothnessG = pow2(color.r) * 0.5;
                                    smoothnessD = smoothnessG * 0.5;

                                    if (color.r > color.g + color.b) {
                                        if (CheckForColor(color.rgb, vec3(220, 74, 74))) {
                                            emission = 5.0;
                                            color.rgb *= mix(vec3(1.0), pow2(color.rgb), 0.9);
                                        } else {
                                            emission = 3.0;
                                            color.rgb *= pow2(color.rgb);
                                        }
                                    }
                                }
                                else /*if (mat < 10968)*/ { // Sponge
                                    smoothnessG = pow2(color.g) * 0.2;
                                    smoothnessD = smoothnessG * 0.5;
                                }
                            } else {
                                if (mat < 10972) { // Wet Sponge
                                    smoothnessG = color.g * 0.75;
                                    highlightMult = 0.3;
                                    smoothnessD = smoothnessG * 0.25;
                                }
                                else /*if (mat < 10976)*/ { // Firefly Bush
                                    subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

                                    #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                        doTileRandomisation = false;
                                    #endif

                                    color.rgb *= 1.5;
                                }
                            }
                        } else {
                            if (mat < 10984) {
                                if (mat < 10980) { // Open Eyeblossom
                                    #include "/lib/materials/specificMaterials/terrain/openEyeblossom.glsl"
                                }
                                else /*if (mat < 10984)*/ { // Potted Open Eyeblossom
                                    noSmoothLighting = true;

                                    float NdotE = dot(normalM, eastVec);
                                    if (abs(abs(NdotE) - 0.5) < 0.4) {
                                        #include "/lib/materials/specificMaterials/terrain/openEyeblossom.glsl"
                                    }
                                }
                            } else {
                                if (mat < 10988) { // Copper Torch
                                    noDirectionalShading = true;

                                    float lum = GetLuminance(color.rgb);

                                    if (color.g - color.r > 0.22 || lum > 0.99) {
                                        noSmoothLighting = true;
                                        lmCoordM.x = 1.0;
                                        #ifdef GBUFFERS_TERRAIN
                                            emission = 2.95;
                                        #else
                                            emission = 2.2;
                                        #endif
                                    }

                                    #ifdef GBUFFERS_TERRAIN
                                        else if (abs(NdotU) < 0.5) {
                                            #ifndef IPBR_COMPAT_MODE
                                                lmCoordM.x = min1(0.7 + 0.3 * smoothstep1(max0(0.4 - signMidCoordPos.y)));
                                            #else
                                                lmCoordM.x = 0.82;
                                            #endif
                                        }
                                    #else
                                        else {
                                            color.rgb *= 1.5;
                                        }
                                    #endif

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        //DoDistantLightBokehMaterial(color, vec4(1.0, 0.6, 0.2, 1.0), emission, 5.0, lViewPos);
                                    #endif

                                    emission += 0.0001; // No light reducing during noon
                                }
                                else /*if (mat < 10992)*/ { // Copper Lantern++
                                    noSmoothLighting = true;
                                    lmCoordM.x = 1.0;

                                    float lum = GetLuminance(color.rgb);

                                    #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"

                                    if (color.g - color.r > 0.2 && abs(color.r - color.b) < 0.1 || lum > 0.8) {
                                        emission = 4.0 * lum;
                                    }

                                    #ifdef DISTANT_LIGHT_BOKEH
                                        //DoDistantLightBokehMaterial(color, vec4(1.0, 0.6, 0.2, 1.0), emission, 5.0, lViewPos);
                                    #endif

                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
                                }
                            }
                        }
                    } else {
                        if (mat < 11008) {
                            if (mat < 11000) {
                                if (mat < 10996) { // Sulfur+, Potent Sulfur, Sulfur Spike
                                    if (mat == 10995) { // Sulfur Spike
                                        noDirectionalShading = true;
                                    }

                                    smoothnessG = pow2(pow2(max(color.r, max(color.g, color.b)))) * 0.35;
                                    smoothnessD = smoothnessG;
                                }
                                else /*if (mat < 11000)*/ { // Chiseled Sulfur, Polished Sulfur+, Sulfur Bricks+
                                    smoothnessG = pow2(pow2(max(color.r, max(color.g, color.b)))) * 0.8;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                }
                            } else {
                                if (mat < 11004) { // Cinnabar+
                                    smoothnessG = pow2(pow2(color.r)) * 0.7;
                                    smoothnessD = smoothnessG;
                                }
                                else /*if (mat < 11008)*/ { // Chiseled Cinnabar, Polished Cinnabar+, Cinnabar Bricks+
                                    smoothnessG = pow1_5(color.r) * 0.7;
                                    smoothnessD = smoothnessG;

                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif
                                }
                            }
                        } else {
                            if (mat < 11016) {
                                if (mat < 11012) { // Vine
                                    subsurfaceMode = 3, centerShadowBias = true; noSmoothLighting = true;

                                    #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                        doTileRandomisation = false;
                                    #endif

                                    float factor = color.g;
                                    smoothnessG = factor * 0.5;
                                    highlightMult = factor * 4.0 + 2.0;

                                    #ifdef GBUFFERS_TERRAIN
                                        float fresnel = clamp(1.0 + dot(normalM, normalize(viewPos)), 0.0, 1.0);
                                        highlightMult *= 1.0 - pow2(pow2(fresnel));
                                    #else
                                        highlightMult *= 0.5;
                                    #endif

                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0, isFoliage = true;
                                }
                                else /*if (mat < 11016)*/ { //

                                }
                            } else {
                                if (mat < 11020) { //

                                }
                                else /*if (mat < 11024)*/ { //

                                }
                            }
                        }
                    }
                }
            }
        }
    }
} else {
        if (mat < 11112) { // No Properties Blocks
            isFoliage = false;
        } else if (mat > 20999 && mat < 21025) {
            #ifdef GBUFFERS_TERRAIN
                emission = DoAutomaticEmission(noSmoothLighting, noDirectionalShading, color.rgb, lmCoord.x, blockLightEmission, 1.0);
            #else
                bool doesNothing;
                emission = DoAutomaticEmission(noSmoothLighting, doesNothing, color.rgb, 0.0, 15, 1.0);
            #endif
        }
        else if (mat > 21025 && mat < 21051) {
            emission = 3.0;
} else if (mat != 0 && mat != 65535) {
    if (mat < 12800) {
        if (mat < 12544) {
            if (mat < 12416) {
                if (mat < 12352) {
                    // block.12288 = sparklers
                    noSmoothLighting = true; noDirectionalShading = true;
                    lmCoordM.x = min(lmCoordM.x * 0.9, 0.77);
    
                    float hue = rgb2hsv(color.rgb).r * 360;
                    if (NdotU > 0.85 || hue < 26 || hue > 37) {
                    	emission = 3.0;
                    	color.rgb = pow1_5(color.rgb);
                    	color.rgb = min1(color.rgb + 0.1 * normalize(color.rgb));
    
                    	overlayNoiseIntensity = 0.0;
                    } else if (abs(NdotU) < 0.5) {
                    	lmCoordM.x = min1(0.7 + 0.3 * smoothstep1(max0(0.4 - signMidCoordPos.y)));
                    } else {
                    	lmCoordM.x = 0.7;
                    }
    
                    emission += 0.0001; // No light reducing during noon
    
                    #ifdef DISTANT_LIGHT_BOKEH
                    	DoDistantLightBokehMaterial(emission, 3.0, lViewPos);
                    #endif
    
                } else /*if (mat < 12416)*/ {
                    // block.12352 = candle_holder
                    #if defined GBUFFERS_TERRAIN
                    	noSmoothLighting = true;
    
                    	vec2 pixelTexSize = ivec2(absMidCoordPos * 2.0 * atlasSize);
                    	if (mat % 2 == 0 && pixelTexSize.x == 1 && (pixelTexSize.y == 4 || (NdotU > 0.9 && pixelTexSize.y == 1))) {
                    		color.rgb *= 1.0 + 0.7 * pow2(max(-signMidCoordPos.y + 0.6, float(NdotU > 0.9) * 1.6));
    
                    		#ifdef SNOWY_WORLD
                    			snowFactor = 0.0;
                    		#endif
    
                    		overlayNoiseIntensity = 0.3;
                    	} else if (NdotU > 0.9) {
                    		if (color.r > 0.9) {
                    			#include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                    		} else {
                    			#include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                    		}
                    	}
                    #endif
    
                }
            } else /*if (mat < 12544)*/ {
                if (mat < 12480) {
                    if (mat < 12448) {
                        if (mat < 12432) {
                            // block.12416 = corundum_clusters
                            float factor;
                            if (mat % 16 < 8) {
                                factor = color.b;
                            } else if (mat % 8 < 4) {
                                factor = 0.8 * color.g + 0.2 * color.r;
                            } else if (mat % 2 == 0) {
                                factor = color.g;
                            } else {
                                factor = (color.r + color.b + color.g) / 3;
                            }
    
                            #include "/lib/materials/specificMaterials/terrain/corundumCluster.glsl"
                        } else /*if (mat < 12448)*/ {
                            if (mat < 12440) {
                                // block.12432 = tin_ore
                                if (color.r - color.g > 0.03) {  // Raw Tin Part
                                	#include "/lib/materials/specificMaterials/terrain/spinelBlock.glsl"
    
                                	#ifdef GLOWING_ORE_SPINEL
                                	emission = 1.2 * color.r + 0.1;
    
                                		overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                		#ifdef SITUATIONAL_ORES
                                			emission *= skyLightCheck;
                                			color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                		#else
                                			color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                		#endif
                                		emission *= GLOWING_ORE_MULT;
                                	#endif
                                } else {  // Stone Part
                                	if (mat % 8 == 0) {
                                		#include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                	} else if (mat % 8 == 2) {
                                		#include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                	} else if (mat % 8 == 4) {
                                		#include "/lib/materials/specificMaterials/terrain/cylindrite.glsl"
                                	} else if (mat % 8 == 6) {
                                		#include "/lib/materials/specificMaterials/terrain/cassiterite.glsl"
                                	}
                                }
    
                            } else /*if (mat < 12448)*/ {
                                if (mat < 12444) {
                                    // block.12440 = diamond_lamp
                                    #include "/lib/materials/specificMaterials/terrain/diamondBlock.glsl"
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = pow2(color.r) * 5.5;
                                    color.rgb *= color.rgb;
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                } else /*if (mat < 12448)*/ {
                                    // block.12444 = emerald_lamp
                                    #include "/lib/materials/specificMaterials/terrain/emeraldBlock.glsl"
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = pow2(color.r) * 5.5;
                                    color.rgb *= color.rgb;
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                }
                            }
                        }
                    } else /*if (mat < 12480)*/ {
                        if (mat < 12464) {
                            if (mat < 12456) {
                                if (mat < 12452) {
                                    // block.12448 = lapis_lamp
                                    #include "/lib/materials/specificMaterials/terrain/lapisBlock.glsl"
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = pow2(color.r) * 5.5;
                                    color.rgb *= color.rgb;
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                } else /*if (mat < 12456)*/ {
                                    // block.12452 = lava_lamp
                                    if (
                                        CheckForColor(color.rgb, vec3(237, 72, 53)) ||
                                        CheckForColor(color.rgb, vec3(253, 227, 117)) ||
                                        CheckForColor(color.rgb, vec3(252, 198, 98)) ||
                                        CheckForColor(color.rgb, vec3(252, 153, 88)) ||
                                        CheckForColor(color.rgb, vec3(251, 106, 62)) ||
                                        CheckForColor(color.rgb, vec3(200, 51, 43))
                                    ) {
                                        #include "/lib/materials/specificMaterials/terrain/lava.glsl"
                                        emission *= 1.5;
                                    } else {
                                        lmCoordM.x *= 0.95;
                                        #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                                    }
    
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                        if (mat % 4 == 2) fractPos.zxy = fractPos.xyz;
                                        if (
                                            max(abs(fractPos.x), abs(fractPos.z)) > 0.25 &&
                                            abs(fractPos.y) < 0.45 &&
                                            abs(fractPos.y) > 0.35
                                        ) {
                                            float dist = min(
                                                length(abs(fractPos.xz) - vec2(min(abs(fractPos.x), 0.25), 0.25)),
                                                length(abs(fractPos.xz) - vec2(0.25, min(abs(fractPos.z), 0.25)))
                                            );
                                            lmCoordM.x += 40.0 * (0.45 - abs(fractPos.y)) * pow2(0.25 - dist);
                                        }
                                    #endif
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 3.5, lViewPos);
                                    #endif
                                }
                            } else /*if (mat < 12464)*/ {
                                if (mat < 12460) {
                                    // block.12456 = lava_lamp_2
                                    if (
                                        CheckForColor(color.rgb, vec3(237, 72, 53)) ||
                                        CheckForColor(color.rgb, vec3(253, 227, 117)) ||
                                        CheckForColor(color.rgb, vec3(252, 198, 98)) ||
                                        CheckForColor(color.rgb, vec3(252, 153, 88)) ||
                                        CheckForColor(color.rgb, vec3(251, 106, 62)) ||
                                        CheckForColor(color.rgb, vec3(200, 51, 43))
                                    ) {
                                        #include "/lib/materials/specificMaterials/terrain/lava.glsl"
                                        emission *= 1.5;
                                    } else {
                                        lmCoordM.x *= 0.95;
                                        #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                                    }
    
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                        fractPos.xzy = fractPos.xyz;
                                        if (
                                            max(abs(fractPos.x), abs(fractPos.z)) > 0.25 &&
                                            abs(fractPos.y) < 0.45 &&
                                            abs(fractPos.y) > 0.35
                                        ) {
                                            float dist = min(
                                                length(abs(fractPos.xz) - vec2(min(abs(fractPos.x), 0.25), 0.25)),
                                                length(abs(fractPos.xz) - vec2(0.25, min(abs(fractPos.z), 0.25)))
                                            );
                                            lmCoordM.x += 40.0 * (0.45 - abs(fractPos.y)) * pow2(0.25 - dist);
                                        }
                                    #endif
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 3.5, lViewPos);
                                    #endif
                                } else /*if (mat < 12464)*/ {
                                    // block.12460 = zirconia_lamp
                                    #include "/lib/materials/specificMaterials/terrain/zirconiaBlock.glsl"
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = dot(color.rgb, color.rgb);
                                    color.rgb *= color.rgb;
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                }
                            }
                        } else /*if (mat < 12480)*/ {
                            if (mat < 12472) {
                                if (mat < 12468) {
                                    // block.12464 = spinel_lamp
                                    #include "/lib/materials/specificMaterials/terrain/spinelBlock.glsl"
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = pow3(color.g) * 5.5;
                                    color.rgb *= color.rgb;
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                } else /*if (mat < 12472)*/ {
                                    // block.12468 = turquoise_lamp
                                    #include "/lib/materials/specificMaterials/terrain/turquoiseBlock.glsl"
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = pow2(color.r) * 5.5;
                                    color.rgb *= color.rgb;
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                }
                            } else /*if (mat < 12480)*/ {
                                if (mat < 12476) {
                                    // block.12472 = zirconia_lamp
                                    #include "/lib/materials/specificMaterials/terrain/zirconiaBlock.glsl"
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = dot(color.rgb, color.rgb);
                                    color.rgb *= color.rgb;
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                } else /*if (mat < 12480)*/ {
                                    // block.12476 = brazier [silver]
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                        lmCoordM.x = pow2(pow2(smoothstep1(1.0 - 0.4 * dot(fractPos.xz, fractPos.xz))));
    
                                        float campfireBrightnessFactor = mix(1.0, 0.9, clamp01(UPPER_LIGHTMAP_CURVE - 1.0));
                                        lmCoordM.x *= campfireBrightnessFactor;
                                    #endif
    
                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.r - color.b > 0.1 || dotColor > 2.9) {
                                        noDirectionalShading = true;
                                        emission = 3.5;
                                        color.rgb *= sqrt1(GetLuminance(color.rgb));
    
                                        overlayNoiseIntensity = 0.0;
    
                                        #if defined SOUL_SAND_VALLEY_OVERHAUL_INTERNAL || defined PURPLE_END_FIRE_INTERNAL
                                            float uniformValue = 1.0;
                                            vec3 colorFire = vec3(0.0);
                                            float gradient = 0.0;
    
                                            #if defined NETHER
                                                uniformValue = inSoulValley;
                                                colorFire = colorSoul;
                                                #ifdef GBUFFERS_TERRAIN
                                                    gradient = mix(1.0, 0.0, clamp01(blockUV.y + 0.5 * blockUV.y));
                                                #elif defined GBUFFERS_HAND
                                                    float handUV = gl_FragCoord.y / viewHeight;
                                                    gradient = mix(1.0, 0.0, handUV + 0.4);
                                                #endif
                                            #endif
    
                                            #ifdef END
                                                colorFire = colorEndBreath;
                                                #ifdef GBUFFERS_TERRAIN
                                                    gradient = mix(1.0, 0.0, clamp01(blockUV.y + 0.07 - 1.1 * clamp01(sin(texture2D(noisetex, vec2(frameTimeCounter * 0.01)).r) * blockUV.y)));
                                                #elif defined GBUFFERS_HAND
                                                    float handUV = gl_FragCoord.y / viewHeight;
                                                    gradient = mix(1.0, 0.0, clamp01(handUV + 0.3 - 1.3 * clamp01(sin(texture2D(noisetex, vec2(frameTimeCounter * 0.01)).r) * handUV)));
                                                #endif
                                            #endif
    
                                            color.rgb = mix(color.rgb, mix(color.rgb, vec3(GetLuminance(color.rgb)), 0.88), uniformValue * gradient);
                                            color.rgb *= mix(vec3(1.0), colorFire * 2.0, uniformValue * gradient);
                                        #endif
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
                                    }
                                }
                            }
                        }
                    }
                } else /*if (mat < 12544)*/ {
                    if (mat < 12512) {
                        if (mat < 12496) {
                            if (mat < 12488) {
                                if (mat < 12484) {
                                    // block.12480 = burning_coal
                                    smoothnessG = dot(color.rgb, vec3(0.5));
                                    smoothnessG = min1(smoothnessG);
                                    smoothnessD = smoothnessG;
    
                                    if (color.r > 0.7) {
                                    	emission = 2.35;
                                    	color.rgb *= sqrt1(GetLuminance(color.rgb));
                                    } else emission = 0.1 + color.r;
    
                                } else /*if (mat < 12488)*/ {
                                    // block.12484 = copper_lantern
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.77); // consistency748523
    
                                    #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"
    
                                    if (color.g > 0.73) {
                                    	emission = 2.5 * pow2(color.g) + 0.5;
                                    	color.rgb *= color.rgb;
                                    }
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                    	DoDistantLightBokehMaterial(emission, 3.0, lViewPos);
                                    #endif
    
                                    #ifdef SNOWY_WORLD
                                    	snowFactor = 0.0;
                                    #endif
    
                                    overlayNoiseIntensity = 0.3;
    
                                }
                            } else /*if (mat < 12496)*/ {
                                if (mat < 12492) {
                                    // block.12488 = cupric_brazier [silver]
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                        lmCoordM.x = pow2(pow2(smoothstep1(1.0 - 0.4 * dot(fractPos.xz, fractPos.xz))));
    
                                        float campfireBrightnessFactor = mix(1.0, 0.9, clamp01(UPPER_LIGHTMAP_CURVE - 1.0));
                                        lmCoordM.x *= campfireBrightnessFactor;
                                    #endif
    
                                    if (color.g - color.r > 0.1 || (color.r > 0.8 && color.g > color.r)) {
                                        noDirectionalShading = true;
                                        emission = 2.60;
                                        color.rgb *= sqrt1(GetLuminance(color.rgb));
    
                                        overlayNoiseIntensity = 0.0;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
                                    }
                                } else /*if (mat < 12496)*/ {
                                    // block.12492 = cupric_campfire
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                        lmCoordM.x = pow2(pow2(smoothstep1(1.0 - 0.4 * dot(fractPos.xz, fractPos.xz))));
    
                                        float campfireBrightnessFactor = mix(1.0, 0.9, clamp01(UPPER_LIGHTMAP_CURVE - 1.0));
                                        lmCoordM.x *= campfireBrightnessFactor;
                                    #endif
    
                                    if (color.g - color.r > 0.1 || (color.r > 0.6 && color.g > color.r)) {
                                        noDirectionalShading = true;
                                        emission = 2.50;
                                        color.rgb *= sqrt1(GetLuminance(color.rgb));
    
                                        overlayNoiseIntensity = 0.0;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/oakWood.glsl"
                                    }
                                }
                            }
                        } else /*if (mat < 12512)*/ {
                            if (mat < 12504) {
                                if (mat < 12500) {
                                    // block.12496 = cupric_fire
                                    noSmoothLighting = true, noDirectionalShading = true;
                                    emission = 1.90;
                                    color.rgb = pow1_5(color.rgb);
    
                                    overlayNoiseIntensity = 0.0;
                                } else /*if (mat < 12504)*/ {
                                    // block.12500 = cupric_lantern
                                    noSmoothLighting = true;
                                    lmCoordM.x = min(lmCoordM.x, 0.77); // consistency748523
    
                                    #include "/lib/materials/specificMaterials/terrain/lanternMetal.glsl"
    
                                    if (color.g > 0.65) {
                                        emission = 2.5 * pow2(color.g) + 0.5;
                                    }
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 3.0, lViewPos);
                                    #endif
    
                                    #ifdef SNOWY_WORLD
                                        snowFactor = 0.0;
                                    #endif
    
                                    overlayNoiseIntensity = 0.3;
                                }
                            } else /*if (mat < 12512)*/ {
                                if (mat < 12508) {
                                    // block.12504 = cupric_torch
                                    noSmoothLighting = true; noDirectionalShading = true;
                                    lmCoordM.x = min(lmCoordM.x * 0.9, 0.77);
    
                                    if (color.g - color.r > 0.1 || color.g > 0.7) {
                                        emission = 3.0;
                                        color.rgb = pow1_5(color.rgb);
                                        color.r = min1(color.r + 0.1);
    
                                        overlayNoiseIntensity = 0.0;
                                    }
    
                                    emission += 0.0001; // No light reducing during noon
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 3.0, lViewPos);
                                    #endif
                                } else /*if (mat < 12512)*/ {
                                    // block.12508 = false_hope
                                    lmCoordM.x = 0.77;
                                    if (color.r > 0.9) {
                                     	emission = 1.3 * pow2(color.r);
                                    }
    
                                }
                            }
                        }
                    } else /*if (mat < 12544)*/ {
                        if (mat < 12528) {
                            if (mat < 12520) {
                                if (mat < 12516) {
                                    // block.12512 = floodlight
                                    #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"
    
                                    #ifdef GBUFFERS_TERRAIN
                                    vec2 pixelTexSize = ivec2(absMidCoordPos * 2.0 * atlasSize);
                                    if (pixelTexSize.x == 15 && pixelTexSize.y == 15 && abs(signMidCoordPos.x) < 0.75 && abs(signMidCoordPos.y) < 0.75) {
                                    	vec3 worldPos = playerPos.xyz + cameraPosition.xyz;
                                    	vec3 blockPos = abs(fract(worldPos) - vec3(0.5));
                                    	float maxBlockPos = max(blockPos.x, max(blockPos.y, blockPos.z));
                                    	if (maxBlockPos > 0.4) {
                                    		lmCoordM.x = max0(0.85 - absMidCoordPos.x - absMidCoordPos.y);
                                    		emission = dot(color.rgb, color.rgb) * 0.8;
                                    	}
                                    }
                                    #endif
    
                                } else /*if (mat < 12520)*/ {
                                    // block.12516 = soul_brazier [silver]
                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.g - color.r > 0.1 || dotColor > 2.9) {
                                        noDirectionalShading = true;
                                        emission = 2.1;
                                        color.rgb *= sqrt1(GetLuminance(color.rgb));
    
                                        overlayNoiseIntensity = 0.0;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
                                    }
                                }
                            } else /*if (mat < 12528)*/ {
                                if (mat < 12524) {
                                    // block.12520 = tin_bulb
                                    #include "/lib/materials/specificMaterials/terrain/tinBlock.glsl"
    
                                    float hue = rgb2hsv(color.rgb).r * 360;
                                    if (color.r > 0.3 && color.b < 0.05 && color.g < 0.05) {  // Redstone Part
                                    	#include "/lib/materials/specificMaterials/terrain/redstoneTorch.glsl"
                                    } else if (hue < 60) {  // Tin Block
                                    	#include "/lib/materials/specificMaterials/terrain/tinBlock.glsl"
                                    }
    
                                } else /*if (mat < 12528)*/ {
                                    // block.12524 = copper_bars / copper_button
                                    #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"
    
                                    if (mat % 4 == 1) {
                                        noSmoothLighting = true;
                                    } else if (mat % 4 == 3) {
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        } else /*if (mat < 12544)*/ {
                            if (mat < 12536) {
                                if (mat < 12532) {
                                    // block.12528 = necronium
                                    #include "/lib/materials/specificMaterials/terrain/necroniumBlock.glsl"
                                } else /*if (mat < 12536)*/ {
                                    // block.12532 = sanguine
                                    if (color.r > color.b) {
                                        #include "/lib/materials/specificMaterials/terrain/sanguineBlock.glsl"
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
                                    }
                                }
                            } else /*if (mat < 12544)*/ {
                                if (mat < 12540) {
                                    // block.12536 = spinel_block
                                    #include "/lib/materials/specificMaterials/terrain/spinelBlock.glsl"
                                } else /*if (mat < 12544)*/ {
                                    // block.12540 = tin_block
                                    #include "/lib/materials/specificMaterials/terrain/tinBlock.glsl"
    
                                }
                            }
                        }
                    }
                }
            }
        } else /*if (mat < 12800)*/ {
            if (mat < 12672) {
                if (mat < 12608) {
                    if (mat < 12576) {
                        if (mat < 12560) {
                            if (mat < 12552) {
                                if (mat < 12548) {
                                    // block.12544 = turquoise_block
                                    #include "/lib/materials/specificMaterials/terrain/turquoiseBlock.glsl"
    
                                } else /*if (mat < 12552)*/ {
                                    // block.12548 = zirconia_block
                                    #include "/lib/materials/specificMaterials/terrain/zirconiaBlock.glsl"
    
                                }
                            } else /*if (mat < 12560)*/ {
                                if (mat < 12556) {
                                    // block.12552 = dismantling_table
                                    vec3 hsvColor = rgb2hsv(color.rgb) * vec3(360, 1, 1);
                                    if ((hsvColor.r > 200 && hsvColor.r < 300) || hsvColor.r < 40) {  // Azalea Base
                                    	#include "/lib/materials/specificMaterials/planks/blueAzaleaPlanks.glsl"
                                    } else if (hsvColor.r > 310 && hsvColor.g > 0.3) {  // Spinel Studs
                                    	#include "/lib/materials/specificMaterials/terrain/spinelBlock.glsl"
                                    } else {  // Stone Top
                                    	#include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
    
                                } else /*if (mat < 12560)*/ {
                                    // block.12556 = resistor
                                    noSmoothLighting = true;
    
                                    #if ANISOTROPIC_FILTER > 0 && !defined IPBR_COMPAT_MODE
                                    	color = texture2D(tex, texCoord); // Fixes artifacts
                                    	color.rgb *= glColor.rgb;
                                    #endif
    
                                    vec3 absDif = abs(vec3(color.r - color.g, color.g - color.b, color.r - color.b));
                                    float maxDif = max(absDif.r, max(absDif.g, absDif.b));
                                    if (color.r > 0.68 && color.g < 0.05 && color.b < 0.05) { // Redstone Parts
                                    	color.gb *= 0.5; // Comparator:Emissive Wire
                                    	#include "/lib/materials/specificMaterials/terrain/redstoneTorch.glsl"
    
                                    	overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.2;
                                    } else if (color.r + color.b > color.g * 2.2 || color.r > 0.99) { // Amethyst Part
                                    	#if GLOWING_AMETHYST >= 1
                                    		#if defined GBUFFERS_TERRAIN && !defined IPBR_COMPAT_MODE
                                    			vec2 absCoord = abs(signMidCoordPos);
                                    			float maxBlockPos = max(absCoord.x, absCoord.y);
                                    			emission = pow2(max0(1.0 - maxBlockPos) * color.g) * 5.4 + 1.2 * color.g;
    
                                    			color.g *= 1.0 - emission * 0.07;
                                    			color.rgb *= color.g;
                                    		#else
                                    			emission = pow2(color.g + color.b) * 0.32;
                                    		#endif
                                    	#endif
    
                                    	#ifdef COATED_TEXTURES
                                    		noiseFactor = 0.66;
                                    	#endif
                                    } else { // Tin Base
                                    	#include "/lib/materials/specificMaterials/terrain/tinBlock.glsl"
                                    }
    
                                }
                            }
                        } else /*if (mat < 12576)*/ {
                            if (mat < 12568) {
                                if (mat < 12564) {
                                    // block.12560 = scatterer
                                    if (color.r > 0.5) {  // Tin
                                    	#include "/lib/materials/specificMaterials/terrain/tinBlock.glsl"
                                    } else {  // Cassiterite
                                    	#include "/lib/materials/specificMaterials/terrain/cassiterite.glsl"
                                    }
    
                                } else /*if (mat < 12568)*/ {
                                    // block.12564 = spiked_rail
                                    #if ANISOTROPIC_FILTER == 0
                                        color = texture2DLod(tex, texCoord, 0);
                                    #endif
    
                                    noSmoothLighting = true;
                                    if (color.r > 0.1 && color.g + color.b < 0.1) { // Redstone Parts
                                        noSmoothLighting = true; noDirectionalShading = true;
                                        lmCoordM.x = min(lmCoordM.x * 0.9, 0.77);
    
                                        if (color.r > 0.5) {
                                            color.rgb *= color.rgb;
                                            emission = 8.0 * color.r;
    
                                            overlayNoiseIntensity = 0.35, overlayNoiseEmission = 0.2;
                                        } else if (color.r > color.g * 2.0) {
                                            materialMask = OSIEBCA * 5.0; // Redstone Fresnel
    
                                            float factor = pow2(color.r);
                                            smoothnessG = 0.4;
                                            highlightMult = factor + 0.4;
    
                                            smoothnessD = factor * 0.7 + 0.3;
                                        }
                                    } else if (color.b > color.r) {
                                        #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
                                    } else if (abs(color.r - color.b) < 0.15) { // Iron Parts
                                        #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                                    } else if (color.g > color.b * 2.0) { // Gold Parts
                                        #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                                    } else { // Wood Parts
                                        #include "/lib/materials/specificMaterials/planks/oakPlanks.glsl"
                                    }
                                }
                            } else /*if (mat < 12576)*/ {
                                if (mat < 12572) {
                                    // block.12568 = raw_tin_block
                                    #include "/lib/materials/specificMaterials/terrain/rawTinBlock.glsl"
                                    #ifdef GLOWING_RAW_BLOCKS
                                    	emission = 1.2 * color.r + 0.1;
    
                                    	overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                    	#ifdef SITUATIONAL_ORES
                                    		emission *= skyLightCheck;
                                    		color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                    	#else
                                    		color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                    	#endif
                                    	emission *= GLOWING_ORE_MULT;
                                    #endif
    
                                } else /*if (mat < 12576)*/ {
                                    // block.12572 = silver_ore
                                    if (abs(color.b - color.r) > 0.05 || color.b > 0.8) {  // Raw Silver Part
                                        #include "/lib/materials/specificMaterials/terrain/rawSilverBlock.glsl"
    
                                        #ifdef GLOWING_ORE_SILVER_C
                                            emission = 2.0 * pow1_5(color.b) + min(0.6 * color.r, 0.1);
    
                                            overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                            #ifdef SITUATIONAL_ORES
                                                emission *= skyLightCheck;
                                                color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                            #else
                                                color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                            #endif
                                            emission *= GLOWING_ORE_MULT;
                                        #endif
                                    } else {  // Stone Part
                                        if (mat % 4 == 0) {
                                            #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                        } else {
                                            #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                        }
                                    }
                                }
                            }
                        }
                    } else /*if (mat < 12608)*/ {
                        if (mat < 12592) {
                            if (mat < 12584) {
                                if (mat < 12580) {
                                    // block.12576 = soul_silver_ore
                                    if (color.b > 0.4) {  // Raw Silver Part
                                        #include "/lib/materials/specificMaterials/terrain/rawSilverBlock.glsl"
    
                                        #ifdef GLOWING_ORE_SOULSILVER
                                            emission = 2.0 * pow1_5(color.b) + min(0.6 * color.r, 0.1);
    
                                            overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                            #ifdef SITUATIONAL_ORES
                                                emission *= skyLightCheck;
                                                color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                            #else
                                                color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                            #endif
                                            emission *= GLOWING_ORE_MULT;
                                        #endif
                                    } else {  // Soul Soil Part
                                        smoothnessG = color.r * 0.4;
                                        smoothnessD = color.r * 0.25;
                                        #if defined GBUFFERS_TERRAIN && defined EMISSIVE_SOUL_SAND
                                            vec3 playerPosM = playerPos + relativeEyePosition;
                                            if (length(playerPosM) < 3.0 && length(playerPosM.y) > 1.1)
                                            if (
                                                color.r < 0.26 && color.r > 0.257 && color.g < 0.2 && color.b < 0.17 && blockUV.y > 0.9999 // A lot of hardcoded stuff
                                                && (
                                                    blockUV.x > 0.625 && blockUV.z < 0.5 && blockUV.z > 0.375
                                                    || blockUV.x < 0.5 && blockUV.x > 0.25 && blockUV.z < 0.1875
                                                    || blockUV.x < 0.375 && blockUV.z > 0.8125
                                                )
                                            ) {
                                                float randomPos = step(0.5, hash13(mod(floor(worldPos + atMidBlock / 64) + frameTimeCounter * 0.0001, vec3(100))));
                                                vec2 flickerNoiseBlock = texture2D(noisetex, vec2(frameTimeCounter * 0.04)).rb;
                                                float noise = mix(1.0, min1(max(flickerNoiseBlock.r, flickerNoiseBlock.g) * 1.7), 0.6) * (clamp(3.0 / length(vec3(playerPosM.x * 1.5, playerPosM.y, playerPosM.z * 1.5)) - 1.0, 0.0, 0.25) * 2.0) * randomPos;
                                                color.rgb = changeColorFunction(color.rgb, 80.0, colorSoul, noise);
                                                emission = 4.0 * noise;
                                                overlayNoiseIntensity = 1.0 - noise;
                                            }
                                        #endif
                                    }
                                } else /*if (mat < 12584)*/ {
                                    // block.12580 = spinel_ore
                                    if (color.r - color.g > 0.03) {  // Raw Spinel Part
                                        #include "/lib/materials/specificMaterials/terrain/spinelBlock.glsl"
    
                                        #ifdef GLOWING_ORE_SPINEL
                                            emission = 0.45 * (1.6 * sqrt2(color.r) + 2.2 * pow2(color.r));
    
                                            overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                            #ifdef SITUATIONAL_ORES
                                                emission *= skyLightCheck;
                                                color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                            #else
                                                color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                            #endif
                                            emission *= GLOWING_ORE_MULT;
                                        #endif
                                    } else {  // Stone Part
                                        if (mat % 4 == 0) {
                                            #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                        } else {
                                            #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                        }
                                    }
                                }
                            } else /*if (mat < 12592)*/ {
                                if (mat < 12588) {
                                    // block.12584 = turquoise_ore
                                    if (maxOf(color.rgb) - minOf(color.rgb) > 0.04) {  // Raw Turquoise Part
                                    	#include "/lib/materials/specificMaterials/terrain/turquoiseBlock.glsl"
    
                                    	#ifdef GLOWING_ORE_TURQUOISE
                                    		emission = maxOf(color.rgb) + 1.2;
    
                                    		overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                    		#ifdef SITUATIONAL_ORES
                                    			emission *= skyLightCheck;
                                    			color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                    			#else
                                    			color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                    		#endif
                                    		emission *= GLOWING_ORE_MULT;
                                    	#endif
                                    } else {  // Stone Part
                                    	if (mat % 4 == 0) {
                                    		#include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    	} else {
                                    		#include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    	}
                                    }
    
                                } else /*if (mat < 12592)*/ {
                                    // block.12588 = cassiterite
                                    #include "/lib/materials/specificMaterials/terrain/cassiterite.glsl"
    
                                }
                            }
                        } else /*if (mat < 12608)*/ {
                            if (mat < 12600) {
                                if (mat < 12596) {
                                    // block.12592 = cylindrite
                                    #include "/lib/materials/specificMaterials/terrain/cylindrite.glsl"
    
                                } else /*if (mat < 12600)*/ {
                                    // block.12596 = rhyolite
                                    if (mat % 4 == 2)
                                    	emission = pow2(pow2(color.r)) * 4.0 + 0.15;
    
                                    if (color.r < 0.9) {
                                    	smoothnessG = 6.2 * pow2(pow2(color.r)) + 0.2 * color.r + 0.05;
                                    	smoothnessD = smoothnessG;
                                    }
    
                                }
                            } else /*if (mat < 12608)*/ {
                                if (mat < 12604) {
                                    // block.12600 = rocky_dirt
                                    if (abs(color.r - color.b) < 0.02) {
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/dirt.glsl"
                                    }
                                } else /*if (mat < 12608)*/ {
                                    // block.12604 = sugilite
                                    materialMask = OSIEBCA; // Intense Fresnel
    
                                    float factor = 0.6 * pow2(pow2(color.r + color.b)) + 0.1;
                                    float factor4 = pow4(factor);
                                    highlightMult = factor * 4.0;
                                    color.rgb *= 0.7 + 0.3 * GetLuminance(color.rgb);
    
                                    if (mat % 4 >= 2) factor *= 1.5;
    
                                    smoothnessG = factor * 0.3 - factor4 * 0.2;
                                    smoothnessD = factor - factor4 * 0.2;
    
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
    
                                }
                            }
                        }
                    }
                } else /*if (mat < 12672)*/ {
                    if (mat < 12640) {
                        if (mat < 12624) {
                            if (mat < 12616) {
                                if (mat < 12612) {
                                    // block.12608 = azalea_door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/blueAzaleaPlanks.glsl"
    
                                    if (mat % 4 == 3) {  // Powered Redstone Components
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                } else /*if (mat < 12616)*/ {
                                    // block.12612 = azalea_log
                                    if (color.b > color.r) { // Azalea Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/blueAzaleaPlanks.glsl"
                                    } else { // Azalea Log:Wood Part, Azalea Wood
                                        smoothnessG = pow2(color.r) * 0.5;
                                        smoothnessD = smoothnessG;
    
                                        mossNoiseIntensity = 0.45;
    
                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.77;
                                        #endif
                                    }
                                }
                            } else /*if (mat < 12624)*/ {
                                if (mat < 12620) {
                                    // block.12616 = azalea_wood
                                    #include "/lib/materials/specificMaterials/planks/blueAzaleaPlanks.glsl"
    
                                    if (mat % 4 == 3) {  // Powered Redstone Components
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                } else /*if (mat < 12624)*/ {
                                    // block.12620 = ender_brazier [silver]
                                    #ifdef GBUFFERS_TERRAIN
                                        vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                        lmCoordM.x = pow2(pow2(smoothstep1(1.0 - 0.4 * dot(fractPos.xz, fractPos.xz))));
    
                                        float campfireBrightnessFactor = mix(1.0, 0.9, clamp01(UPPER_LIGHTMAP_CURVE - 1.0));
                                        lmCoordM.x *= campfireBrightnessFactor;
                                    #endif
    
                                    if (
                                        (color.r - color.g > 0.1 && color.b - color.g > 0.1) ||
                                        (color.r > 0.85 && color.b > 0.85 && color.g > 0.85)
                                    ) {
                                        noDirectionalShading = true;
                                        emission = 3.50;
                                        color.rgb *= color.rgb;
    
                                        overlayNoiseIntensity = 0.0;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
                                    }
                                }
                            }
                        } else /*if (mat < 12640)*/ {
                            if (mat < 12632) {
                                if (mat < 12628) {
                                    // block.12624 = chorus_flower
                                    #ifndef NOT_GLOWING_CHORUS_FLOWER
                                        vec3 checkColor = texture2DLod(tex, texCoord, 0).rgb;
                                        if (
                                            CheckForColor(checkColor, vec3(164, 157, 126)) ||
                                            CheckForColor(checkColor, vec3(201, 197, 176)) ||
                                            CheckForColor(checkColor, vec3(226, 221, 188)) ||
                                            CheckForColor(checkColor, vec3(153, 142, 95))
                                        ) {
                                            emission = min(GetLuminance(color.rgb), 0.75) / 0.75;
                                            emission = pow2(pow2(emission)) * 6.5;
                                            color.gb *= 0.85;
    
                                            overlayNoiseIntensity = 0.1, overlayNoiseEmission = 0.8;
                                        } else emission = max0(GetLuminance(color.rgb) - 0.5) * 3.0;
                                    #endif
                                } else /*if (mat < 12632)*/ {
                                    // block.12628 = crates
                                    vec2 absCoord = abs(signMidCoordPos);
                                    if (
                                        (absCoord.x > 0.75 || absCoord.y > 0.75 && NdotU > 0.9) || (
                                            NdotU < 0.1 && NdotU > -0.1 && absCoord.x < 0.75 && (
                                                absCoord.y > 0.75 ||
                                                (signMidCoordPos.y < -0.25 && signMidCoordPos.y > -0.50) ||
                                                (signMidCoordPos.y > 0.0 && signMidCoordPos.y < 0.25) ||
                                                signMidCoordPos.y > 0.50
                                            )
                                        ) || NdotU < -0.9
                                    ) {
                                        #include "/lib/materials/specificMaterials/planks/darkOakPlanks.glsl"
                                        if (mat % 4 == 0) lmCoordM.x -= 0.1;
                                    } else {
                                        if (mat % 4 == 0) {
                                            subsurfaceMode = 1;
                                            lmCoordM.x *= 0.875;
    
                                            if (color.r > 0.64) {
                                                emission = color.r < 0.75 ? 2.5: 8.0;
                                                color.rgb = color.rgb * vec3(1.0, 0.8, 0.6);
                                            }
                                        } else if (mat % 4 == 2) {
                                            #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                                        }
                                    }
                                }
                            } else /*if (mat < 12640)*/ {
                                if (mat < 12636) {
                                    // block.12632 = food_sack
                                    if (color.r > 0.7 && color.g > 0.7 && color.b > 0.7) {
                                        smoothnessG = pow(color.g, 16.0) * 2.0;
                                        smoothnessD = smoothnessG * 0.7;
                                        highlightMult = 2.0;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/sack.glsl"
                                    }
                                } else /*if (mat < 12640)*/ {
                                    // block.12636 = rope
                                    const uint voxelNumbers[4] = uint[](356u, 357u, 358u, 359u);
                                    uint voxelNumber = voxelNumbers[mat % 4];
                                    #include "/lib/materials/specificMaterials/terrain/sack.glsl"
                                }
                            }
                        }
                    } else /*if (mat < 12672)*/ {
                        if (mat < 12656) {
                            if (mat < 12648) {
                                if (mat < 12644) {
                                    // block.12640 = stove
                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.r < 0.4 && color.b < 0.4 && color.g < 0.4) {
                                        #include "/lib/materials/specificMaterials/terrain/anvil.glsl"
                                    } else if (color.r > color.b * 2.0 && dotColor > 0.7) {
                                        emission = 2.5 * dotColor * max0(pow2(pow2(pow2(color.r))) - color.b) + pow(dotColor * 0.35, 32.0);
                                        color.r *= 1.0 + 0.1 * emission;
    
                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                        #endif
                                        #ifdef PURPLE_END_FIRE_INTERNAL
                                            color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                        #endif
                                        overlayNoiseIntensity = 0.0;
                                    } else {
                                        smoothnessG = pow2(color.g);
                                        smoothnessD = smoothnessG;
    
                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.77;
                                        #endif
                                    }
                                } else /*if (mat < 12648)*/ {
                                    // block.12644 = amethyst_lamp
                                    materialMask = OSIEBCA; // Intense Fresnel
                                    float factor = pow2(color.r);
                                    smoothnessG = 0.8 - factor * 0.3;
                                    highlightMult = factor * 3.0;
                                    smoothnessD = factor;
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    emission = pow2(color.g) * 5.5;
                                    color.g *= 1.0 - emission * 0.09;
                                    overlayNoiseIntensity = 0.5;
    
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
                                }
                            } else /*if (mat < 12656)*/ {
                                if (mat < 12652) {
                                    // block.12648 = palladium
                                    #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
    
                                    if (mat % 4 == 3) {  // medium weighted pressure plate
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                } else /*if (mat < 12656)*/ {
                                    // block.12652 = palladium_lattice
                                    noSmoothLighting = true;
                                    if (color.g > 1.3 * color.b && color.r < 0.5) {
                                        #include "/lib/materials/specificMaterials/terrain/leaves.glsl"
                                    } else if (color.r > 0.5 && color.b < 0.5) {
                                        subsurfaceMode = 1;
                                        lmCoordM.x *= 0.875;
    
                                        emission = color.r < 0.75 ? 2.5 : 8.0;
                                        color.rgb = color.rgb * vec3(1.0, 0.8, 0.6);
                                        isFoliage = false;
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/silverBlock.glsl"
                                    }
                                }
                            }
                        } else /*if (mat < 12672)*/ {
                            if (mat < 12664) {
                                if (mat < 12660) {
                                    // block.12656 = blackstone_cabinet
                                    if (color.r > color.b * 3.0) { // Gilded Blackstone:Gilded Part
                                        #include "/lib/materials/specificMaterials/terrain/rawGoldBlock.glsl"
                                        #ifdef GLOWING_ORE_GILDEDBLACKSTONE
                                            emission = color.g * 1.5;
                                            emission *= GLOWING_ORE_MULT;
    
                                            overlayNoiseIntensity = 0.65, overlayNoiseEmission = 0.6;
    
                                            #ifdef SITUATIONAL_ORES
                                                emission *= skyLightCheck;
                                            #endif
                                        #endif
                                    } else { // Gilded Blackstone:Blackstone Part
                                        #include "/lib/materials/specificMaterials/terrain/blackstone.glsl"
                                    }
                                } else /*if (mat < 12664)*/ {
                                    // block.12660 = blazier_block
                                    float dotColor = dot(color.rgb, color.rgb);
                                    if (color.r > color.b || dotColor > 2.9) {
                                    	noDirectionalShading = true;
                                    	overlayNoiseIntensity = 0.0;
    
                                    	if (maxOf(abs(normal)) < 0.8) emission = 3.5;
                                    	else emission = 1.7;
    
                                    	color.rgb *= sqrt1(GetLuminance(color.rgb));
                                    }
    
                                }
                            } else /*if (mat < 12672)*/ {
                                if (mat < 12668) {
                                    // block.12664 = nether_stove
                                    lmCoordM.x *= 0.88;
                                    if (color.r - color.b > 0.1) {
                                        if (color.r < 0.28) {  // nether bricks
                                            float factor = smoothstep1(min1(color.r * 1.5));
                                            factor = factor > 0.12 ? factor : factor * 0.5;
                                            smoothnessG = factor;
                                            smoothnessD = factor;
                                        } else {  // fire
                                            float dotColor = dot(color.rgb, color.rgb);
                                            emission = 2.5 * dotColor * max0(pow2(pow2(pow2(color.r))) - color.b) + pow(dotColor * 0.35, 32.0);
                                            color.r *= 1.0 + 0.1 * emission;
    
                                            #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                            #endif
                                            #ifdef PURPLE_END_FIRE_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                            #endif
                                            overlayNoiseIntensity = 0.0;
                                        }
                                    } else if (color.b - color.r > 0.1 && color.b > 0.35) {
                                        emission = 1.5;
                                        color.rgb = pow1_5(color.rgb);
                                    } else if (abs(color.r - color.b) < 0.1) {  // blackstone
                                        #include "/lib/materials/specificMaterials/terrain/blackstone.glsl"
                                    }
                                } else /*if (mat < 12672)*/ {
                                    // block.12668 = powdery_cane
                                    bool bloomed = mat % 4 == 2;
                                    #include "/lib/materials/specificMaterials/terrain/powderyCane.glsl"
    
                                    if (mat % 4 == 3) {  // cane plants
                                        if (absMidCoordPos.x > 0.005)
                                            subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;
    
                                        sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0, isFoliage = true;
                                    }
                                }
                            }
                        }
                    }
                }
            } else /*if (mat < 12800)*/ {
                if (mat < 12736) {
                    if (mat < 12704) {
                        if (mat < 12688) {
                            if (mat < 12680) {
                                if (mat < 12676) {
                                    // block.12672 = powdery_torch
                                    bool bloomed = true;
                                    #include "/lib/materials/specificMaterials/terrain/powderyCane.glsl"
    
                                    float temp = mat % 4 == 0 ? 1.0 : 1.5;
                                    lmCoordM.x = 0.9 * min1(0.7 + 0.3 * pow2(temp - signMidCoordPos.y - 2.0 * absMidCoordPos.x));
                                } else /*if (mat < 12680)*/ {
                                    // block.12676 = resurgent_soil
                                    if (mat % 4 == 2) lmCoordM.x *= 0.9;
                                    smoothnessG = color.r * 0.4;
                                    smoothnessD = color.r * 0.25;
    
                                    float factor = color.b / color.r;
                                    if (factor > 1.1) {
                                        #ifdef GBUFFERS_TERRAIN
                                            vec2 bpos = floor(playerPos.xz + cameraPosition.xz + 0.5)
                                                      + floor(playerPos.y + cameraPosition.y + 0.5);
                                            bpos = bpos * 0.05 + 0.004 * frameTimeCounter;
                                            emission = 12.0 * pow2(texture2D(noisetex, bpos).r * pow2(texture2D(noisetex, bpos * 0.5).r));
                                            emission *= factor;
                                            emission = min(emission, 5.0);
                                        #endif
                                    }
                                }
                            } else /*if (mat < 12688)*/ {
                                if (mat < 12684) {
                                    // block.12680 = twisting_vines
                                    const uint voxelNumbers[4] = uint[](272u, -1u, 273u, -1u);
                                    uint voxelNumber = voxelNumbers[mat % 4];
                                    noSmoothLighting = true;
    
                                    #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                        doTileRandomisation = false;
                                    #endif
    
                                    if (color.r > color.g) {
                                        emission = 1.5 * color.b;
                                    } else if (color.r > 0.4) {
                                        emission = pow2(color.r);
                                        maRecolor = vec3(0.1);
    
                                        #ifdef GBUFFERS_TERRAIN
                                            vec2 bpos = floor(playerPos.xz + cameraPosition.xz + 0.501)
                                                      + floor(playerPos.y + cameraPosition.y + 0.501);
                                            bpos = bpos * 0.01 + 0.004 * frameTimeCounter;
                                            emission *= texture2D(noisetex, bpos).r * pow1_5(texture2D(noisetex, bpos * 0.5).r);
                                            emission *= 16.0;
                                        #endif
                                    }
    
                                    isFoliage = false;
                                } else /*if (mat < 12688)*/ {
                                    // block.12684 = warped_fungus
                                    noSmoothLighting = true;
    
                                    #ifdef MOD_NETHEREXP
                                        if (color.r > 0.73 && color.b > 0.73) {
                                            emission = 1.5 * color.b;
    
                                            overlayNoiseIntensity = 0.5;
                                        }
                                    #endif
    
                                    if (color.r > 0.91) {
                                        emission = 3.0 * color.g;
                                        color.r *= 1.2;
                                        maRecolor = vec3(0.1);
    
                                        overlayNoiseIntensity = 0.5;
                                    }
    
                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;
                                    isFoliage = false;
                                }
                            }
                        } else /*if (mat < 12704)*/ {
                            if (mat < 12696) {
                                if (mat < 12692) {
                                    // block.12688 = weeping_vines
                                    const uint voxelNumbers[4] = uint[](65u, 65u, 65u, 65u);
                                    uint voxelNumber = voxelNumbers[mat % 4];
                                    #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                        doTileRandomisation = false;
                                    #endif
    
                                    if (color.r > 0.91) {
                                        emission = 3.0 * color.g;
                                        color.r *= 1.2;
                                        maRecolor = vec3(0.1);
                                    }
    
                                    isFoliage = false;
                                } else /*if (mat < 12696)*/ {
                                    // block.12692 = raw_silver
                                    #include "/lib/materials/specificMaterials/terrain/rawSilverBlock.glsl"
                                    #ifdef GLOWING_RAW_BLOCKS
                                        emission = 2.0 * pow1_5(color.b);
    
                                        overlayNoiseIntensity = 0.6, overlayNoiseEmission = 0.5;
                                        #ifdef SITUATIONAL_ORES
                                            emission *= skyLightCheck;
                                            color.rgb = mix(color.rgb, color.rgb * pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT))), skyLightCheck);
                                        #else
                                            color.rgb *= pow(color.rgb, vec3(0.5 * min1(GLOWING_ORE_MULT)));
                                        #endif
    
                                        emission *= GLOWING_ORE_MULT;
                                    #endif
                                }
                            } else /*if (mat < 12704)*/ {
                                if (mat < 12700) {
                                    // block.12696 = ashen_door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/ashenPlanks.glsl"
    
                                    if (mat % 4 == 3) {  // Powered Redstone Components
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                } else /*if (mat < 12704)*/ {
                                    // block.12700 = ashen_log
                                    if (color.r > 0.8 && color.b > 0.8 && color.g > 0.8) { // Ashen Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/ashenPlanks.glsl"
                                    } else { // Ashen Log:Wood Part, Ashen Wood
                                        smoothnessG = pow2(color.r) * 0.1;
                                        smoothnessD = smoothnessG;
    
                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 1.25;
                                        #endif
                                    }
                                }
                            }
                        }
                    } else /*if (mat < 12736)*/ {
                        if (mat < 12720) {
                            if (mat < 12712) {
                                if (mat < 12708) {
                                    // block.12704 = ashen_wood
                                    #include "/lib/materials/specificMaterials/planks/ashenPlanks.glsl"
    
                                    if (mat % 4 == 3) {  // Powered Redstone Components
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                } else /*if (mat < 12712)*/ {
                                    // block.12708 = azalea_door
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/planks/azaleaPlanks.glsl"
    
                                    if (mat % 4 == 3) {  // Powered Redstone Components
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            } else /*if (mat < 12720)*/ {
                                if (mat < 12716) {
                                    // block.12712 = azalea_log
                                    if (color.g < 0.8) { // Azalea Log:Clean Part
                                        #include "/lib/materials/specificMaterials/planks/azaleaPlanks.glsl"
                                    } else { // Azalea Log:Wood Part, Azalea Wood
                                        smoothnessG = pow2(color.r) * 0.1;
                                        smoothnessD = smoothnessG;
    
                                        mossNoiseIntensity = 0.45;
    
                                        #ifdef COATED_TEXTURES
                                            noiseFactor = 0.77;
                                        #endif
                                    }
                                } else /*if (mat < 12720)*/ {
                                    // block.12716 = azalea_wood
                                    #include "/lib/materials/specificMaterials/planks/azaleaPlanks.glsl"
    
                                    if (mat % 4 == 3) {  // Powered Redstone Components
                                        redstoneIPBR(color.rgb, emission);
                                    }
                                }
                            }
                        } else /*if (mat < 12736)*/ {
                            if (mat < 12728) {
                                if (mat < 12724) {
                                    // block.12720 = blackstone_furnace
                                    #include "/lib/materials/specificMaterials/terrain/blackstone.glsl"
                                    if (mat % 4 == 0) {
                                        lmCoordM.x *= 0.98;
    
                                        float dotColor = dot(color.rgb, color.rgb);
                                        emission = 2.5 * dotColor * max0(pow2(pow2(pow2(color.r))) - color.b) + pow(dotColor * 0.35, 32.0);
                                        color.r *= 1.0 + 0.1 * emission;
    
                                        if (color.r > color.b * 2.0 && dotColor > 0.7) {
                                            #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                            #endif
                                            #ifdef PURPLE_END_FIRE_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                            #endif
                                            overlayNoiseIntensity = 0.0;
                                        }
                                    } else if (mat % 4 == 2) {
                                        lmCoordM.x *= 0.98;
    
                                        emission = 1.5;
                                        color.rgb = pow1_5(color.rgb);
                                    }
                                } else /*if (mat < 12728)*/ {
                                    // block.12724 = blaze_lantern
                                    noSmoothLighting = true, noDirectionalShading = true;
                                    lmCoordM.x = 0.85;
    
                                    smoothnessD = min1(max0(0.5 - color.b) * 2.0);
                                    smoothnessG = color.b;
    
                                    float blockRes = absMidCoordPos.x * atlasSize.x;
                                    vec2 signMidCoordPosM = (floor((signMidCoordPos + 1.0) * blockRes) + 0.5) / blockRes - 1.0;
                                    float dotsignMidCoordPos = dot(signMidCoordPosM, signMidCoordPosM);
                                    float lBlockPosM = pow2(max0(1.0 - 1.7 * pow2(pow2(dotsignMidCoordPos))));
                                    emission = pow2(color.r) * 1.6 + 2.2 * lBlockPosM;
                                    emission *= 0.4 + max0(0.6 - 0.006 * lViewPos);
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                                    #endif
    
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.5;
                                    #endif
    
                                    overlayNoiseIntensity = 0.5;
                                }
                            } else /*if (mat < 12736)*/ {
                                if (mat < 12732) {
                                    // block.12728 = blue_nether_bricks
                                    float factor = color.b * 0.8;
                                    factor = color.b > 0.3 ? factor : factor * 0.25;
                                    smoothnessG = factor;
                                    smoothnessD = factor;
    
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                } else /*if (mat < 12736)*/ {
                                    // block.12732 = white_corundum_cluster
                                    float factor = (color.r + color.g + color.b) / 2;
    
                                    materialMask = OSIEBCA; // Intense Fresnel
    
                                    smoothnessG = 0.8 - factor * 0.3;
                                    highlightMult = factor * 3.0;
                                    smoothnessD = factor;
    
                                    noSmoothLighting = true;
                                    lmCoordM.x *= 0.88;
    
                                    #if GLOWING_AMETHYST >= 1 && defined GBUFFERS_TERRAIN
                                        vec3 worldPos = playerPos.xyz + cameraPosition.xyz;
                                        vec3 blockPos = abs(fract(worldPos) - vec3(0.65, 0.7, 0.4));
                                        float maxBlockPos = max(blockPos.x, max(blockPos.y, blockPos.z));
                                        emission = pow2(max0(1.0 - pow1_5(maxBlockPos) * 2.60) * pow2(pow2(min(color.r, min(color.g, color.b))))) * 6.0;
                                        if (color.r < color.b && color.r < color.g) {
                                            color.r *= 1.0 - emission * 0.07;
                                        } else if (color.g < color.r && color.g < color.b) {
                                            color.g *= 1.0 - emission * 0.07;
                                        } else {
                                            color.b *= 1.0 - emission * 0.07;
                                        }
    
                                        emission *= 1.3;
    
                                        overlayNoiseIntensity = 0.5;
                                    #endif
    
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.66;
                                    #endif
                                }
                            }
                        }
                    }
                } else /*if (mat < 12800)*/ {
                    if (mat < 12768) {
                        if (mat < 12752) {
                            if (mat < 12744) {
                                if (mat < 12740) {
                                    // block.12736 = deepslate_furnace
                                    #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                                    if (mat % 4 == 1) {
                                        lmCoordM.x *= 0.95;
    
                                        float dotColor = dot(color.rgb, color.rgb);
                                        emission = 2.5 * dotColor * max0(pow2(pow2(pow2(color.r))) - color.b) + pow(dotColor * 0.35, 32.0);
                                        color.r *= 1.0 + 0.1 * emission;
    
                                        if (color.r > color.b * 2.0 && dotColor > 0.7) {
                                            #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 2.0, colorSoul, inSoulValley);
                                            #endif
                                            #ifdef PURPLE_END_FIRE_INTERNAL
                                                color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                            #endif
                                            overlayNoiseIntensity = 0.0;
                                        }
                                    }
                                } else /*if (mat < 12744)*/ {
                                    // block.12740 = duskbound_lantern
                                    highlightMult = 2.0;
                                    smoothnessG = pow2(pow2(color.b));
                                    smoothnessD = smoothnessG;
    
                                    if (mat % 4 == 2) {
                                        if (color.b > 1.7 * color.r) {
                                            emission = 7.0 - 4.0 * pow2(color.b);
                                            #ifdef DISTANT_LIGHT_BOKEH
                                                DoDistantLightBokehMaterial(emission, 2.5, lViewPos);
                                            #endif
                                        } else {
                                            lmCoordM.x -= 0.1;
                                        }
                                    }
                                }
                            } else /*if (mat < 12752)*/ {
                                if (mat < 12748) {
                                    // block.12744 = ender_watcher
                                    // TODO improve ender watcher shader
                                    if (color.r > 0.5 && color.b < 0.3) {  // Redstone
                                        emission = 1.0;
                                        #include "/lib/materials/specificMaterials/terrain/redstoneTorch.glsl"
                                    } else if (color.b > 0.5) {  // Eye of Ender
                                        smoothnessG = 1.0;
                                        highlightMult = 2.0;
                                        smoothnessD = 1.0;
                                    }
                                } else /*if (mat < 12752)*/ {
                                    // block.12748 = glow_shroom
                                    noSmoothLighting = true;
    
                                    if (color.g > color.b + 0.035 && color.g > 0.72) {
                                        emission = 1.25 * pow2(pow2(color.g)) + 0.3 * pow2(color.b);
                                    } else {
                                        sandNoiseIntensity = 0.0, mossNoiseIntensity = 0.0;
                                    }
    
                                }
                            }
                        } else /*if (mat < 12768)*/ {
                            if (mat < 12760) {
                                if (mat < 12756) {
                                    // block.12752 = glowberry_sack
                                    vec2 absCoord = abs(signMidCoordPos);
                                    if (NdotU > 0.9 && (absCoord.x < 0.875 && absCoord.y < 0.875)) {
                                        subsurfaceMode = 1;
                                        lmCoordM.x *= 0.875;
    
                                        if (color.r > 0.64) {
                                            emission = color.r < 0.75 ? 1.0: 3.0;
                                            color.rgb = color.rgb * vec3(1.0, 0.8, 0.6);
                                        }
                                    } else {
                                        lmCoordM.x -= 0.15;
                                        #include "/lib/materials/specificMaterials/terrain/sack.glsl"
                                    }
                                } else /*if (mat < 12760)*/ {
                                    // block.12756 = gold_bars
                                    noSmoothLighting = true;
                                    #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                                }
                            } else /*if (mat < 12768)*/ {
                                if (mat < 12764) {
                                    // block.12760 = jasper
                                    smoothnessG = min(pow2(pow2(color.r)) * 2.0, 0.8);
                                    smoothnessD = smoothnessG;
                                } else /*if (mat < 12768)*/ {
                                    // block.12764 = magnet
                                    if (color.r - color.g > 0.2 || color.b - color.g > 0.2) {
                                        if (mat % 4 == 2) {
                                            emission = 3.0 * pow2(abs(color.r - color.b)) + 1.0;
                                            color.rgb *= color.rgb;
                                        }
                                    } else {
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
                                }
                            }
                        }
                    } else /*if (mat < 12800)*/ {
                        if (mat < 12784) {
                            if (mat < 12776) {
                                if (mat < 12772) {
                                    // block.12768 = midori_block
                                    if (mat % 4 == 2) lmCoordM.x -= 0.15;
    
                                    highlightMult = 2.0;
                                    smoothnessG = pow3(color.g) + 0.2 * color.g;
                                    smoothnessD = smoothnessG;
    
                                    mossNoiseIntensity = 0.3, sandNoiseIntensity = 0.3;
    
                                    if (color.r > color.g) {
                                        emission = 2.5;
                                    }
    
                                } else /*if (mat < 12776)*/ {
                                    // block.12772 = myalite
                                    vec2 num = (playerPos.xz + cameraPosition.xz) + (playerPos.y + cameraPosition.y);
                                    vec2 noise = texture2D(noisetex, num / 128.0).rb;
    
                                    smoothnessG = 0.5 * pow2(color.b) * (0.4 + (pow2(sin(noise.r) + cos(noise.g))));
                                    smoothnessD = smoothnessG;
                                    highlightMult = 3.0 * pow2(pow2(color.r)) * smoothnessG;
    
                                }
                            } else /*if (mat < 12784)*/ {
                                if (mat < 12780) {
                                    // block.12776 = polished_jasper
                                    smoothnessG = min(pow3(color.r) * 2.5, 1.0);
                                    smoothnessD = smoothnessG;
    
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.77;
                                    #endif
                                } else /*if (mat < 12784)*/ {
                                    // block.12780 = polished_shale
                                    materialMask = OSIEBCA; // Intense Fresnel
    
                                    float factor = pow2(color.b);
                                    float factor2 = pow2(factor);
                                    smoothnessG = 1.3 - 0.7 * factor;
                                    highlightMult = factor2 * 3.0;
                                    smoothnessD = factor;
    
                                    #ifdef COATED_TEXTURES
                                        noiseFactor = 0.20;
                                    #endif
                                }
                            }
                        } else /*if (mat < 12800)*/ {
                            if (mat < 12792) {
                                if (mat < 12788) {
                                    // block.12784 = quark_potted_plants
                                    noSmoothLighting = true;
    
                                    vec3 worldPos = playerPos + cameraPosition;
                                    float fractPos = fract(worldPos.y);
                                    if (fractPos > 0.375) {
                                        subsurfaceMode = 1, noDirectionalShading = true;
    
                                        if (mat % 4 == 0) {  // glow berries
                                            lmCoordM.x *= 0.875;
    
                                            if (color.r > 0.64) {
                                                emission = color.r < 0.75 ? 2.5 : 8.0;
                                                color.rgb = color.rgb * vec3(1.0, 0.8, 0.6);
                                                isFoliage = false;
                                            } else {
                                                isFoliage = true;
                                            }
                                        } else if (mat % 4 == 2) {  // glow lichen
                                            float dotColor = dot(color.rgb, color.rgb);
                                            emission = min(pow2(pow2(dotColor) * dotColor) * 1.4 + dotColor * 0.9, 6.0);
    
                                            color.r *= 1.15;
                                        }
                                    }
    
                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;
    
                                } else /*if (mat < 12792)*/ {
                                    // block.12788 = quark_potted_plants_2
                                    noSmoothLighting = true;
    
                                    vec3 worldPos = playerPos + cameraPosition;
                                    float fractPos = fract(worldPos.y);
                                    if (fractPos > 0.375) {
                                        subsurfaceMode = 1, noDirectionalShading = true;
    
                                        if (mat % 4 == 0) {  // sea pickle
                                            if (color.b > 0.5) { // Sea Pickle:Emissive Part
                                                color.g *= 1.1;
                                                emission = 5.0;
                                            }
                                        } else if (mat % 4 == 2) {  // weeping vines
                                            #if defined COATED_TEXTURES && defined GBUFFERS_TERRAIN
                                                doTileRandomisation = false;
                                            #endif
    
                                            if (color.r > 0.91) {
                                                emission = 3.0 * color.g;
                                                color.r *= 1.2;
                                                maRecolor = vec3(0.1);
                                            }
    
                                            isFoliage = false;
                                        }
                                    }
    
                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;
    
                                }
                            } else /*if (mat < 12800)*/ {
                                if (mat < 12796) {
                                    // block.12792 = quark_potted_plants_3
                                    noSmoothLighting = true;
    
                                    vec3 worldPos = playerPos + cameraPosition;
                                    float fractPos = fract(worldPos.y);
                                    if (fractPos > 0.375) {
                                        subsurfaceMode = 1, noDirectionalShading = true;
    
                                        if (mat % 4 == 0) {  // glow shroom
                                            if (color.g > color.b + 0.035 && color.g > 0.72) {
                                                emission = 1.25 * pow2(pow2(color.g)) + 0.3 * pow2(color.b);
                                            }
                                        }
                                    }
    
                                    sandNoiseIntensity = 0.3, mossNoiseIntensity = 0.0;
    
                                } else /*if (mat < 12800)*/ {
                                    // block.12796 = quark_stone_lamp
                                    if (color.r > 0.85) {
                                        noSmoothLighting = true;
                                        lmCoordM.x = 1.0;
                                        emission = GetLuminance(color.rgb) * 3.2;
    
                                        color.r *= 1.4;
                                        color.b *= 0.5;
                                        overlayNoiseIntensity = 0.0;
    
                                        #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                            if (color.g > 0.999) color.rgb = changeColorFunction(color.rgb, 1.5, colorSoul, inSoulValley);
                                        #endif
                                        #ifdef PURPLE_END_FIRE_INTERNAL
                                            if (color.g > 0.5) color.rgb = changeColorFunction(color.rgb, 2.0, colorEndBreath, 1.0);
                                        #endif
                                    } else {
                                        lmCoordM.x -= 0.13;
                                        #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                                    }
    
                                    #ifdef DISTANT_LIGHT_BOKEH
                                        DoDistantLightBokehMaterial(color, vec4(1.0, 0.6, 0.2, 1.0), emission, 5.0, lViewPos);
                                    #endif
                                }
                            }
                        }
                    }
                }
            }
        }
    } else /*if (mat < 12912)*/ {
        if (mat < 12864) {
            if (mat < 12832) {
                if (mat < 12816) {
                    if (mat < 12808) {
                        if (mat < 12804) {
                            // block.12800 = redstone_randomizer
                            #if ANISOTROPIC_FILTER > 0
                                color = texture2D(tex, texCoord); // Fixes artifacts
                                color.rgb *= glColor.rgb;
                            #endif
    
                            vec3 absDif = abs(vec3(color.r - color.g, color.g - color.b, color.r - color.b));
                            float maxDif = max(absDif.r, max(absDif.g, absDif.b));
                            if (color.g - color.r > 0.1 || CheckForColor(color.rgb, vec3(229, 237, 229)) || CheckForColor(color.rgb, vec3(202, 225, 219))) { // Prismarine
                                smoothnessG = pow2(color.g) * 0.8;
                                highlightMult = 1.5;
                                smoothnessD = smoothnessG;
    
                                if (mat % 4 == 0) emission = pow1_5(color.r) * 2.5 + 0.2;
                                overlayNoiseIntensity = 0.5, overlayNoiseEmission = 0.1;
                            } else if (maxDif > 0.125 || color.b > 0.99) { // Redstone Parts
                                if (color.r < 0.999 && color.b > 0.4) color.gb *= 0.5; // Comparator:Emissive Wire
    
                                #include "/lib/materials/specificMaterials/terrain/redstoneTorch.glsl"
    
                                overlayNoiseIntensity = 0.7, overlayNoiseEmission = 0.2;
                            } else { // Quartz Base
                                float factor = pow2(color.g) * 0.6;
    
                                smoothnessG = factor;
                                highlightMult = 1.0 + 2.5 * factor;
                                smoothnessD = factor;
                            }
                        } else /*if (mat < 12808)*/ {
                            // block.12804 = shale
                            float factor = pow2(color.b);
                            float factor2 = pow2(factor);
                            smoothnessG = 0.6 * (1 - factor);
                            highlightMult = factor2 * 3.0;
                            smoothnessD = factor;
    
                            #ifdef COATED_TEXTURES
                                noiseFactor = 0.45;
                            #endif
                        }
                    } else /*if (mat < 12816)*/ {
                        if (mat < 12812) {
                            // block.12808 = storage_crate
                            if (color.r - color.g > 0.078) {
                                #include "/lib/materials/specificMaterials/terrain/ironBlock.glsl"
                            } else {
                                #include "/lib/materials/specificMaterials/planks/darkOakPlanks.glsl"
                            }
                        } else /*if (mat < 12816)*/ {
                            // block.12812 = trumpet_door
                            noSmoothLighting = true;
                            #include "/lib/materials/specificMaterials/planks/trumpetPlanks.glsl"
    
                            if (mat % 4 == 3) {  // Powered Redstone Components
                                redstoneIPBR(color.rgb, emission);
                            }
                        }
                    }
                } else /*if (mat < 12832)*/ {
                    if (mat < 12824) {
                        if (mat < 12820) {
                            // block.12816 = trumpet_log
                            if (color.r > 0.23) { // Trumpet Log:Clean Part
                                #include "/lib/materials/specificMaterials/planks/trumpetPlanks.glsl"
                            } else { // Trumpet Log:Wood Part, Trumpet Wood
                                smoothnessG = pow2(color.r) * 0.35;
                                smoothnessD = smoothnessG;
    
                                #ifdef COATED_TEXTURES
                                    noiseFactor = 0.77;
                                #endif
                            }
                        } else /*if (mat < 12824)*/ {
                            // block.12820 = trumpet_wood
                            #include "/lib/materials/specificMaterials/planks/trumpetPlanks.glsl"
    
                            if (mat % 4 == 3) {  // Powered Redstone Components
                                redstoneIPBR(color.rgb, emission);
                            }
                        }
                    } else /*if (mat < 12832)*/ {
                        if (mat < 12828) {
                            // block.12824 = blackstone_lamp
                            if (color.b > 0.7) {
                                lmCoordM = vec2(1.0, 0.0);
    
                                float dotColor = dot(color.rgb, color.rgb);
                                emission = pow2(dotColor * 0.6) * 0.8;
                                color.b *= 1.2;
    
                            	color.rgb *= color.rgb;
    
                                #ifdef DISTANT_LIGHT_BOKEH
                                    DoDistantLightBokehMaterial(emission, 2.5, lViewPos);
                                #endif
                            } else {
                                lmCoordM.x *= 0.85;
                                #include "/lib/materials/specificMaterials/terrain/blackstone.glsl"
                            }
    
                        } else /*if (mat < 12832)*/ {
                            // block.12828 = blaze_rod
                            smoothnessG = 1.0;
                            smoothnessD = smoothnessG;
    
                            // TODO try some noise thing similar to lava noise
                            emission = 2.0;
                        }
                    }
                }
            } else /*if (mat < 12864)*/ {
                if (mat < 12848) {
                    if (mat < 12840) {
                        if (mat < 12836) {
                            // block.12832 = clock_block
                            if (color.b < 0.4 && color.r > 0.8 && color.g > 0.8) {  // Gold Part
                                #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                            } else if (color.r > 0.7 && color.b > 0.7 && color.g > 0.7) {  // White Clockface
                                #include "/lib/materials/specificMaterials/terrain/quartzBlock.glsl"
                            } else if (color.r > 0.2) {  // Wooden Part
                                #include "/lib/materials/specificMaterials/planks/darkOakPlanks.glsl"
                            }
                        } else /*if (mat < 12840)*/ {
                            // block.12836 = cog
                            #include "/lib/materials/specificMaterials/terrain/copperBlock.glsl"
                            if (mat % 4 == 2 && color.r > 0.05 && color.g + color.b < 0.2) { // Redstone Parts
                            	emission = pow2(min(color.r, 0.9)) * 3.0;
                            	color.g = min(color.g, 0.1 * color.r);
                            	color.b = min(color.b, 0.1 * color.r);
                            }
    
                        }
                    } else /*if (mat < 12848)*/ {
                        if (mat < 12844) {
                            // block.12840 = crystal_display
                            if (color.r > 0.7 && color.b > 0.7) {
                                emission = 2.5 * color.r;
                            } else {
                                #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                            }
    
                        } else /*if (mat < 12848)*/ {
                            // block.12844 = deepslate_lamp
                            if (color.r > 0.7) {
                                lmCoordM = vec2(1.0, 0.0);
    
                                float dotColor = dot(color.rgb, color.rgb);
                                emission = min(pow2(pow2(pow2(dotColor * 0.6))), 6.0) * 0.5;
                                color.r *= 1.1;
    
                            	color.rgb = pow1_5(color.rgb);
    
                                #ifdef DISTANT_LIGHT_BOKEH
                                    DoDistantLightBokehMaterial(emission, 2.5, lViewPos);
                                #endif
                            } else {
                                lmCoordM.x *= 0.85;
                                #include "/lib/materials/specificMaterials/terrain/deepslate.glsl"
                            }
    
                        }
                    }
                } else /*if (mat < 12864)*/ {
                    if (mat < 12856) {
                        if (mat < 12852) {
                            // block.12848 = endstone_lamp
                            if (color.g < 0.5) {
                                lmCoordM = vec2(1.0, 0.0);
    
                                float dotColor = dot(color.rgb, color.rgb) / 3;
                                color.rgb /= dotColor;
                                emission = sqrt(color.b + 8.0);
    
                                #ifdef DISTANT_LIGHT_BOKEH
                                    DoDistantLightBokehMaterial(emission, 2.5, lViewPos);
                                #endif
                            } else {
                                lmCoordM.x *= 0.85;
                                #include "/lib/materials/specificMaterials/terrain/endStone.glsl"
                            }
                        } else /*if (mat < 12856)*/ {
                            // block.12852 = fire_pit
                            if (mat % 2 == 0) {
                                #ifdef GBUFFERS_TERRAIN
                                    vec3 fractPos = fract(playerPos + cameraPosition) - 0.5;
                                    lmCoordM.x = pow2(pow2(smoothstep1(1.0 - 0.4 * dot(fractPos.xz, fractPos.xz))));
    
                                    float campfireBrightnessFactor = mix(1.0, 0.9, clamp01(UPPER_LIGHTMAP_CURVE - 1.0));
                                    lmCoordM.x *= campfireBrightnessFactor;
                                #endif
                            }
    
                            if (color.r > 0.8) {
                                #include "/lib/materials/specificMaterials/terrain/lumiseneFire.glsl"
                            } else {
                                #include "/lib/materials/specificMaterials/planks/sprucePlanks.glsl"
                            }
                        }
                    } else /*if (mat < 12864)*/ {
                        if (mat < 12860) {
                            // block.12856 = crimson_lantern
                            if (color.r / color.g > 3.0) {
                                noSmoothLighting = true;
                                lmCoordM.x = 0.77;
    
                            	emission = color.r + 0.5;
                            	emission += min(pow2(pow2(0.75 * dot(color.rgb, color.rgb))), 5.0);
    
                            	#ifdef DISTANT_LIGHT_BOKEH
                                    DoDistantLightBokehMaterial(color, vec4(1.0, 0.6, 0.2, 1.0), emission, 5.0, lViewPos);
                                #endif
                            } else {
                                #include "/lib/materials/specificMaterials/terrain/goldBlock.glsl"
                            }
    
                        } else /*if (mat < 12864)*/ {
                            // block.12860 = redstone_illuminator
                            color.r *= color.r * 1.05;
                            color.gb *= pow1_5(color.gb);
    
                            materialMask = OSIEBCA; // Intense Fresnel
                            smoothnessG = color.r * 0.5 + 0.2;
                            float factor = pow2(smoothnessG);
                            highlightMult = factor * 2.0 + 1.0;
                            smoothnessD = min1(factor * 2.0);
    
                            overlayNoiseIntensity = 0.3;
    
                            if (color.r > 0.27) {
                                emission = 3.0 * pow1_5(color.r);
                            }
                        }
                    }
                }
            }
        } else /*if (mat < 12912)*/ {
            if (mat < 12896) {
                if (mat < 12880) {
                    if (mat < 12872) {
                        if (mat < 12868) {
                            // block.12864 = sack
                            #include "/lib/materials/specificMaterials/terrain/sack.glsl"
                        } else /*if (mat < 12872)*/ {
                            // block.12868 = soap_block
                            smoothnessG = pow2(color.r) * 0.4;
                            smoothnessD = smoothnessG;
                            highlightMult = 1.5;
                        }
                    } else /*if (mat < 12880)*/ {
                        if (mat < 12876) {
                            // block.12872 = stone_lamp
                            if (color.r > 0.7) {
                                lmCoordM = vec2(1.0, 0.0);
    
                                float dotColor = dot(color.rgb, color.rgb);
                                emission = min(pow2(pow2(pow2(dotColor * 0.6))), 6.0) * 0.2;
    
                            	color.rgb = pow1_5(color.rgb);
    
                                #ifdef DISTANT_LIGHT_BOKEH
                                    DoDistantLightBokehMaterial(emission, 2.5, lViewPos);
                                #endif
    
                                overlayNoiseIntensity = 0.3;
                            } else {
                                lmCoordM.x *= 0.85;
                                #include "/lib/materials/specificMaterials/terrain/stone.glsl"
                            }
    
                        } else /*if (mat < 12880)*/ {
                            // block.12876 = sugar_cube
                            smoothnessG = pow(color.g, 16.0) * 2.0;
                            smoothnessD = smoothnessG * 0.7;
                            highlightMult = 2.0;
                        }
                    }
                } else /*if (mat < 12896)*/ {
                    if (mat < 12888) {
                        if (mat < 12884) {
                            // block.12880 = paper_lantern
                            if (color.r / color.b > 1.9) {
                                #include "/lib/materials/specificMaterials/planks/oakPlanks.glsl"
                                lmCoordM.x *= 0.88;
                            } else {
                                vec2 bpos = floor(playerPos.xz + cameraPosition.xz + 0.5)
                                + floor(playerPos.y + cameraPosition.y + 0.5);
                                vec2 flickerNoise = texture2D(noisetex, vec2(frameTimeCounter * 0.015 + bpos.r * 0.1)).rb;
    
                                noSmoothLighting = true;
                                lmCoordM.x = 0.77;
    
                                emission = 0.4 * (color.r + color.b + color.g);
    
                                // motion of candle within lantern
                                vec3 fractPos = fract(playerPos.xyz + cameraPosition.xyz) - 0.5;
                                if (abs(NdotU) < 0.1 && max(abs(fractPos.x), abs(fractPos.z)) > 0.1)
                                    emission /= (1 + length(signMidCoordPos - 0.05 * sin(flickerNoise.gr * 5.0)));
    
                                // appearance of flickering
                                emission *= mix(1.0, min1(max(flickerNoise.r, flickerNoise.g) * 1.7), pow2(7 * 0.1));
    
                                #ifdef SOUL_SAND_VALLEY_OVERHAUL_INTERNAL
                                    color.r *= mix(max(emission, 1) + 1, 1, inSoulValley);
                                    color.b *= mix(1, pow3(max(emission, 1)) + 1, inSoulValley);
                                    color.g *= max(emission, 1) + 1;
                                #else
                                    color.r *= pow1_5(max(emission, 1)) + 1;
                                    color.g *= max(emission, 1) + 1;
                                #endif
    
                                #ifdef DISTANT_LIGHT_BOKEH
                                    DoDistantLightBokehMaterial(color, vec4(1.0, 0.6, 0.2, 1.0), emission, 5.0, lViewPos);
                                #endif
                            }
                        } else /*if (mat < 12888)*/ {
                            // block.12884 = polished_schist
                            smoothnessG = 0.7 * pow2(color.g) + 0.08;
                            smoothnessD = smoothnessG;
                        }
                    } else /*if (mat < 12896)*/ {
                        if (mat < 12892) {
                            // block.12888 = schist
                            smoothnessG = 1.2 * pow2(pow2(color.g));
                            smoothnessD = smoothnessG;
                            overlayNoiseIntensity = 0.7;
                        } else /*if (mat < 12896)*/ {
                            // block.12892 = coralstone
                            smoothnessG = pow3(color.g) * 2.5;
                            smoothnessD = smoothnessG;
    
                            #ifdef COATED_TEXTURES
                                noiseFactor = 0.77;
                            #endif
    
                            #ifdef GLOWING_CORALSTONE
                                #include "/lib/materials/specificMaterials/terrain/coral.glsl"
                                float maxDiff = max(
                                    abs(color.r - color.b),
                                    max(abs(color.b - color.g), abs(color.r - color.g))
                                );
                                if (maxDiff > 0.07) {
                                    float dotColor = dot(color.rgb, color.rgb);
                                    emission = dotColor;
                                }
                            #endif
                        }
                    }
                }
            } else /*if (mat < 12912)*/ {
                if (mat < 12904) {
                    if (mat < 12900) {
                        // block.12896 = elder_prismarine_coral
                        smoothnessG = pow2(color.g) * 0.8;
                        highlightMult = 1.5;
                        smoothnessD = smoothnessG;
    
                        #ifdef COATED_TEXTURES
                            noiseFactor = 0.66;
                        #endif
    
                        if (mat % 4 < 2) {
                            noSmoothLighting = true;
    
                            #if defined GBUFFERS_TERRAIN
                                vec3 worldPos = playerPos.xyz + cameraPosition.xyz;
                                vec3 blockPos;
                                if (mat % 4 == 0) {
                                    blockPos = abs(fract(worldPos) - vec3(0.5));
                                } else {
                                    blockPos = abs(fract(worldPos) - vec3(0.5, 0.2, 0.5));
                                }
    
                                float r = length(blockPos);
                                emission = smoothnessG - 0.5 * pow3(color.g);
                                emission *= pow2(max0(1.0 - r * 1.3) * color.r) * 20.0;
                                color.r *= 1.0 - emission * 0.05;
    
                                overlayNoiseIntensity = 0.5;
                            #endif
                        }
                    } else /*if (mat < 12904)*/ {
                        // block.12900 = luminous_prismarine
                        emission = 1.2 * pow2(color.b);
    
                        smoothnessG = pow2(color.g) * 0.8;
                        highlightMult = 1.5;
                        smoothnessD = smoothnessG;
    
                        #ifdef COATED_TEXTURES
                            noiseFactor = 0.66;
                        #endif
                    }
                } else /*if (mat < 12912)*/ {
                    if (mat < 12908) {
                        // block.12904 = prismarine_coral
                        smoothnessG = pow2(color.g) * 0.8;
                        highlightMult = 1.5;
                        smoothnessD = smoothnessG;
    
                        #ifdef COATED_TEXTURES
                            noiseFactor = 0.66;
                        #endif
    
                        if (mat % 4 < 2) {
                            noSmoothLighting = true;
    
                            #if defined GBUFFERS_TERRAIN
                                vec3 worldPos = playerPos.xyz + cameraPosition.xyz;
                                vec3 blockPos;
                                if (mat % 4 == 0) {
                                    blockPos = abs(fract(worldPos) - vec3(0.5));
                                } else {
                                    blockPos = abs(fract(worldPos) - vec3(0.5, 0.2, 0.5));
                                }
    
                                float r = length(blockPos);
                                emission = smoothnessG - 0.5 * pow3(color.g);
                                emission *= pow2(max0(1.0 - r * 1.3) * color.r) * 35.0;
                                color.r *= 1.0 - emission * 0.05;
    
                                overlayNoiseIntensity = 0.5;
                            #endif
                        }
                    } else /*if (mat < 12912)*/ {
                        // block.12908 = tooth_lantern
                        if (color.b > color.r + 0.1) {
                            noSmoothLighting = true;
                            emission = pow2(color.b) * 4.0;
                            color.rgb *= color.rgb;
    
                            #ifdef DISTANT_LIGHT_BOKEH
                                DoDistantLightBokehMaterial(emission, 2.0, lViewPos);
                            #endif
                        } else {
                            lmCoordM.x *= 0.88;
    
                            smoothnessG = color.r * 0.2;
                            smoothnessD = smoothnessG;
    
                            #ifdef GBUFFERS_TERRAIN
                                DoBrightBlockTweaks(color.rgb, 0.5, shadowMult, highlightMult);
                            #endif
    
                            #ifdef COATED_TEXTURES
                                noiseFactor = 0.33;
                            #endif
                        }
                    }
                }
            }
        }
    }
    
}

    }
}

#ifdef GBUFFERS_TERRAIN
    else { // mat < 10000
        // Support for the Enhanced Block Entities mod. The mod makes block entities render in gbuffers_terrain
        int blockEntityId = mat;
        #include "/lib/materials/materialHandling/blockEntityIPBR.glsl"
    }
#endif
