#include "/lib/shaderSettings/materials.glsl"

#ifdef IS_IRIS
#ifndef INCLUDE_VOXELIZATION
    #define INCLUDE_VOXELIZATION

    #if COLORED_LIGHTING_INTERNAL <= 512
        const ivec3 voxelVolumeSize = ivec3(COLORED_LIGHTING_INTERNAL, COLORED_LIGHTING_INTERNAL * 0.5, COLORED_LIGHTING_INTERNAL);
    #else
        const ivec3 voxelVolumeSize = ivec3(COLORED_LIGHTING_INTERNAL, 512 * 0.5, COLORED_LIGHTING_INTERNAL);
    #endif

    float effectiveACTdistance = min(float(COLORED_LIGHTING_INTERNAL), shadowDistance * 2.0);

    vec3 transform(mat4 m, vec3 pos) {
        return mat3(m) * pos + m[3].xyz;
    }

    vec3 SceneToVoxel(vec3 scenePos) {
        return scenePos + cameraPositionBestFract + (0.5 * vec3(voxelVolumeSize));
    }

    bool CheckInsideVoxelVolume(vec3 voxelPos) {
        #ifndef SHADOW
            voxelPos -= voxelVolumeSize / 2;
            voxelPos += sign(voxelPos) * 0.95;
            voxelPos += voxelVolumeSize / 2;
        #endif
        voxelPos /= vec3(voxelVolumeSize);
        return clamp01(voxelPos) == voxelPos;
    }

    uint GetVoxelVolume(ivec3 pos) {
        return texelFetch(voxel_sampler, pos, 0).x & 32767u;
    }

    uint GetVoxelVolumeRaw(ivec3 pos) {
        return texelFetch(voxel_sampler, pos, 0).x;
    }

    vec4 GetComplexLightVolume(vec3 pos, sampler3D ff_sampler) {
        vec4 lightVolume = vec4(0.0);

        #ifndef ACT_CORNER_LEAK_FIX_FOR_WSR
            #if defined COMPOSITE || defined COMPOSITE1 || defined DEFERRED1
                #undef ACT_CORNER_LEAK_FIX
            #endif
        #endif

        #ifndef ACT_CORNER_LEAK_FIX
            lightVolume = texture(ff_sampler, pos);
        #else
            // Manual light filtering - Optimized by Gemini - I don't like AI either but my version was so much slower :(
            ivec3 posTX = ivec3(pos * voxelVolumeSize);
            vec3 texPos = pos * vec3(voxelVolumeSize) - 0.5;
            ivec3 base  = ivec3(floor(texPos));
            vec3 frac   = fract(texPos);

            vec3 w[2] = vec3[2](1.0 - frac, frac);
            float lightDivide = 0.0;

            // Cache the three axial neighbors relative to posTX that lead toward the 'base+1' side
            bool airX = int(GetVoxelVolume(posTX + ivec3(base.x + 1 == posTX.x ? -1 : 1, 0, 0))) == 0;
            bool airY = int(GetVoxelVolume(posTX + ivec3(0, base.y + 1 == posTX.y ? -1 : 1, 0))) == 0;
            bool airZ = int(GetVoxelVolume(posTX + ivec3(0, 0, base.z + 1 == posTX.z ? -1 : 1))) == 0;

            for (int z = 0; z <= 1; z++) {
                for (int y = 0; y <= 1; y++) {
                    for (int x = 0; x <= 1; x++) {
                        ivec3 p = clamp(base + ivec3(x, y, z), ivec3(0), voxelVolumeSize - 1);
                        ivec3 d = abs(p - posTX);
                        int dist = d.x + d.y + d.z;

                        // Light Leak Logic
                        if (dist == 3) continue; // Skip corners
                        if (dist == 2) {
                            // Check if the two axial paths to this edge are blocked
                            bool reachable = false;
                            if (d.x > 0 && d.y > 0) reachable = (airX || airY);
                            else if (d.y > 0 && d.z > 0) reachable = (airY || airZ);
                            else if (d.x > 0 && d.z > 0) reachable = (airX || airZ);
                            if (!reachable) continue;
                        }

                        // Skip Solids
                        if (int(GetVoxelVolume(p)) == 1) continue;

                        float weight = w[x].x * w[y].y * w[z].z;
                        lightVolume += weight * texelFetch(ff_sampler, p, 0);
                        lightDivide += weight;
                    }
                }
            }

            if (lightDivide > 0.0) lightVolume /= lightDivide;
        #endif

        return lightVolume;
    }

    vec4 GetLightVolume(vec3 pos) {
        vec4 lightVolume = vec4(0.0);

        if (int(framemod2) == 0) {
            lightVolume = GetComplexLightVolume(pos, floodfill_sampler_copy);
        } else {
            lightVolume = GetComplexLightVolume(pos, floodfill_sampler);
        }

        return lightVolume;
    }

    int GetVoxelIDs(int mat) {
        /* These return IDs must be consistent across the following files:
        "lightVoxelization.glsl", "blocklightColors.glsl", "item.properties"
        The order of if-checks or block IDs don't matter. The returning IDs matter. */

        if (mat < 12556) {
            if (mat < 12385) {
                if (mat < 12335) {
                    if (mat < 12311) {
                        if (mat < 12299) {
                            if (mat < 12293) {
                                if (mat < 12289) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12288) return 24;
                                    #else 
                                    if (mat == 12288) return 24;
                                    #endif
                                } else { // mat >= 12289
                                    if (mat < 12291) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12290) return 214;
                                        #else 
                                        if (mat == 12290) return 24;
                                        #endif
                                    } else { // mat >= 12291
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12292) return 215;
                                        #else 
                                        if (mat == 12292) return 24;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12293
                                if (mat < 12295) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12294) return 77;
                                    #else 
                                    if (mat == 12294) return 24;
                                    #endif
                                } else { // mat >= 12295
                                    if (mat < 12297) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12296) return 217;
                                        #else 
                                        if (mat == 12296) return 24;
                                        #endif
                                    } else { // mat >= 12297
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12298) return 75;
                                        #else 
                                        if (mat == 12298) return 24;
                                        #endif
                                    }
                                }
                            }
                        } else { // mat >= 12299
                            if (mat < 12305) {
                                if (mat < 12301) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12300) return 218;
                                    #else 
                                    if (mat == 12300) return 24;
                                    #endif
                                } else { // mat >= 12301
                                    if (mat < 12303) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12302) return 219;
                                        #else 
                                        if (mat == 12302) return 24;
                                        #endif
                                    } else { // mat >= 12303
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12304) return 74;
                                        #else 
                                        if (mat == 12304) return 24;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12305
                                if (mat < 12307) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12306) return 220;
                                    #else 
                                    if (mat == 12306) return 24;
                                    #endif
                                } else { // mat >= 12307
                                    if (mat < 12309) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12308) return 76;
                                        #else 
                                        if (mat == 12308) return 24;
                                        #endif
                                    } else { // mat >= 12309
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12310) return 73;
                                        #else 
                                        if (mat == 12310) return 24;
                                        #endif
                                    }
                                }
                            }
                        }
                    } else { // mat >= 12311
                        if (mat < 12323) {
                            if (mat < 12317) {
                                if (mat < 12313) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12312) return 79;
                                    #else 
                                    if (mat == 12312) return 24;
                                    #endif
                                } else { // mat >= 12313
                                    if (mat < 12315) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12314) return 221;
                                        #else 
                                        if (mat == 12314) return 24;
                                        #endif
                                    } else { // mat >= 12315
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12316) return 222;
                                        #else 
                                        if (mat == 12316) return 24;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12317
                                if (mat < 12319) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12318) return 223;
                                    #else 
                                    if (mat == 12318) return 24;
                                    #endif
                                } else { // mat >= 12319
                                    if (mat < 12321) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12320) return 224;
                                        #else 
                                        if (mat == 12320) return 24;
                                        #endif
                                    } else { // mat >= 12321
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12322) return 71;
                                        #else 
                                        if (mat == 12322) return 24;
                                        #endif
                                    }
                                }
                            }
                        } else { // mat >= 12323
                            if (mat < 12329) {
                                if (mat < 12325) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12324) return 80;
                                    #else 
                                    if (mat == 12324) return 24;
                                    #endif
                                } else { // mat >= 12325
                                    if (mat < 12327) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12326) return 78;
                                        #else 
                                        if (mat == 12326) return 24;
                                        #endif
                                    } else { // mat >= 12327
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12328) return 70;
                                        #else 
                                        if (mat == 12328) return 24;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12329
                                if (mat < 12331) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12330) return 225;
                                    #else 
                                    if (mat == 12330) return 24;
                                    #endif
                                } else { // mat >= 12331
                                    if (mat < 12333) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12332) return 226;
                                        #else 
                                        if (mat == 12332) return 24;
                                        #endif
                                    } else { // mat >= 12333
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12334) return 227;
                                        #else 
                                        if (mat == 12334) return 24;
                                        #endif
                                    }
                                }
                            }
                        }
                    }
                } else { // mat >= 12335
                    if (mat < 12363) {
                        if (mat < 12347) {
                            if (mat < 12341) {
                                if (mat < 12337) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12336) return 228;
                                    #else 
                                    if (mat == 12336) return 24;
                                    #endif
                                } else { // mat >= 12337
                                    if (mat < 12339) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12338) return 229;
                                        #else 
                                        if (mat == 12338) return 24;
                                        #endif
                                    } else { // mat >= 12339
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12340) return 72;
                                        #else 
                                        if (mat == 12340) return 24;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12341
                                if (mat < 12343) {
                                    #if defined COLORED_CANDLE_LIGHT
                                    if (mat == 12342) return 174;
                                    #else 
                                    if (mat == 12342) return 174;
                                    #endif
                                } else { // mat >= 12343
                                    if (mat < 12345) {
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12344) return 172;
                                        #else 
                                        if (mat == 12344) return 172;
                                        #endif
                                    } else { // mat >= 12345
                                        #if defined COLORED_CANDLE_LIGHT
                                        if (mat == 12346) return 171;
                                        #else 
                                        if (mat == 12346) return 171;
                                        #endif
                                    }
                                }
                            }
                        } else { // mat >= 12347
                            if (mat < 12357) {
                                if (mat < 12353) {
                                    if (mat == 12352) return 287;
                                } else { // mat >= 12353
                                    if (mat < 12355) {
                                        if (mat == 12354) return 286;
                                    } else { // mat >= 12355
                                        if (mat == 12356) return 290;
                                    }
                                }
                            } else { // mat >= 12357
                                if (mat < 12359) {
                                    if (mat == 12358) return 284;
                                } else { // mat >= 12359
                                    if (mat < 12361) {
                                        if (mat == 12360) return 283;
                                    } else { // mat >= 12361
                                        if (mat == 12362) return 285;
                                    }
                                }
                            }
                        }
                    } else { // mat >= 12363
                        if (mat < 12372) {
                            if (mat < 12369) {
                                if (mat < 12365) {
                                    if (mat == 12364) return 288;
                                } else { // mat >= 12365
                                    if (mat < 12367) {
                                        if (mat == 12366) return 282;
                                    } else { // mat >= 12367
                                        #if defined DO_IPBR_LIGHTS && (!(defined NOT_GLOWING_CHORUS_FLOWER))
                                        if (mat == 12368) return 39;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12369
                                if (mat < 12370) {
                                    #if defined DO_IPBR_LIGHTS && (!(defined NOT_GLOWING_CHORUS_FLOWER))
                                    if (mat == 12369) return 39;
                                    #endif
                                } else { // mat >= 12370
                                    if (mat < 12371) {
                                        #if defined DO_IPBR_LIGHTS && (!(defined NOT_GLOWING_CHORUS_FLOWER))
                                        if (mat == 12370) return 39;
                                        #endif
                                    } else { // mat >= 12371
                                        #if defined DO_IPBR_LIGHTS && (!(defined NOT_GLOWING_CHORUS_FLOWER))
                                        if (mat == 12371) return 39;
                                        #endif
                                    }
                                }
                            }
                        } else { // mat >= 12372
                            if (mat < 12382) {
                                if (mat < 12373) {
                                    if (mat == 12372) return 20;
                                } else { // mat >= 12373
                                    if (mat < 12381) {
                                        if (mat == 12380) return 356;
                                    } else { // mat >= 12381
                                        if (mat == 12381) return 356;
                                    }
                                }
                            } else { // mat >= 12382
                                if (mat < 12383) {
                                    if (mat == 12382) return 356;
                                } else { // mat >= 12383
                                    if (mat < 12384) {
                                        if (mat == 12383) return 356;
                                    } else { // mat >= 12384
                                        if (mat == 12384) return 21;
                                    }
                                }
                            }
                        }
                    }
                }
            } else { // mat >= 12385
                if (mat < 12451) {
                    if (mat < 12411) {
                        if (mat < 12399) {
                            if (mat < 12388) {
                                if (mat < 12386) {
                                    if (mat == 12385) return 21;
                                } else { // mat >= 12386
                                    if (mat < 12387) {
                                        if (mat == 12386) return 21;
                                    } else { // mat >= 12387
                                        if (mat == 12387) return 21;
                                    }
                                }
                            } else { // mat >= 12388
                                if (mat < 12393) {
                                    if (mat == 12392) return 15;
                                } else { // mat >= 12393
                                    if (mat < 12397) {
                                        if (mat == 12396) return 21;
                                    } else { // mat >= 12397
                                        if (mat == 12398) return 29;
                                    }
                                }
                            }
                        } else { // mat >= 12399
                            if (mat < 12406) {
                                if (mat < 12403) {
                                    if (mat == 12402) return 37;
                                } else { // mat >= 12403
                                    if (mat < 12405) {
                                        if (mat == 12404) return 37;
                                    } else { // mat >= 12405
                                        if (mat == 12405) return 37;
                                    }
                                }
                            } else { // mat >= 12406
                                if (mat < 12407) {
                                    if (mat == 12406) return 37;
                                } else { // mat >= 12407
                                    if (mat < 12408) {
                                        if (mat == 12407) return 37;
                                    } else { // mat >= 12408
                                        if (mat == 12410) return 271;
                                    }
                                }
                            }
                        }
                    } else { // mat >= 12411
                        if (mat < 12420) {
                            if (mat < 12417) {
                                if (mat < 12413) {
                                    #if defined DO_IPBR_LIGHTS
                                    if (mat == 12412) return 272;
                                    #endif
                                } else { // mat >= 12413
                                    if (mat < 12415) {
                                        #if defined DO_IPBR_LIGHTS
                                        if (mat == 12414) return 273;
                                        #endif
                                    } else { // mat >= 12415
                                        #if defined DO_IPBR_LIGHTS
                                        if (mat == 12416) return 273;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12417
                                if (mat < 12418) {
                                    #if defined DO_IPBR_LIGHTS
                                    if (mat == 12417) return 273;
                                    #endif
                                } else { // mat >= 12418
                                    if (mat < 12419) {
                                        #if defined DO_IPBR_LIGHTS
                                        if (mat == 12418) return 273;
                                        #endif
                                    } else { // mat >= 12419
                                        #if defined DO_IPBR_LIGHTS
                                        if (mat == 12419) return 273;
                                        #endif
                                    }
                                }
                            }
                        } else { // mat >= 12420
                            if (mat < 12423) {
                                if (mat < 12421) {
                                    #if defined DO_IPBR_LIGHTS
                                    if (mat == 12420) return 65;
                                    #endif
                                } else { // mat >= 12421
                                    if (mat < 12422) {
                                        #if defined DO_IPBR_LIGHTS
                                        if (mat == 12421) return 65;
                                        #endif
                                    } else { // mat >= 12422
                                        #if defined DO_IPBR_LIGHTS
                                        if (mat == 12422) return 65;
                                        #endif
                                    }
                                }
                            } else { // mat >= 12423
                                if (mat < 12424) {
                                    #if defined DO_IPBR_LIGHTS
                                    if (mat == 12423) return 65;
                                    #endif
                                } else { // mat >= 12424
                                    if (mat < 12449) {
                                        if (mat == 12448) return 21;
                                    } else { // mat >= 12449
                                        if (mat == 12450) return 29;
                                    }
                                }
                            }
                        }
                    }
                } else { // mat >= 12451
                    if (mat < 12484) {
                        if (mat < 12467) {
                            if (mat < 12455) {
                                if (mat < 12453) {
                                    if (mat == 12452) return 281;
                                } else { // mat >= 12453
                                    if (mat < 12454) {
                                        if (mat == 12453) return 281;
                                    } else { // mat >= 12454
                                        if (mat == 12454) return 281;
                                    }
                                }
                            } else { // mat >= 12455
                                if (mat < 12456) {
                                    if (mat == 12455) return 281;
                                } else { // mat >= 12456
                                    if (mat < 12461) {
                                        if (mat == 12460) return 289;
                                    } else { // mat >= 12461
                                        if (mat == 12466) return 21;
                                    }
                                }
                            }
                        } else { // mat >= 12467
                            if (mat < 12481) {
                                if (mat < 12471) {
                                    if (mat == 12470) return 300;
                                } else { // mat >= 12471
                                    if (mat < 12477) {
                                        if (mat == 12476) return 301;
                                    } else { // mat >= 12477
                                        if (mat == 12480) return 20;
                                    }
                                }
                            } else { // mat >= 12481
                                if (mat < 12482) {
                                    if (mat == 12481) return 20;
                                } else { // mat >= 12482
                                    if (mat < 12483) {
                                        if (mat == 12482) return 20;
                                    } else { // mat >= 12483
                                        if (mat == 12483) return 20;
                                    }
                                }
                            }
                        }
                    } else { // mat >= 12484
                        if (mat < 12525) {
                            if (mat < 12517) {
                                if (mat < 12513) {
                                    if (mat == 12512) return 20;
                                } else { // mat >= 12513
                                    if (mat < 12515) {
                                        if (mat == 12514) return 34;
                                    } else { // mat >= 12515
                                        if (mat == 12516) return 302;
                                    }
                                }
                            } else { // mat >= 12517
                                if (mat < 12519) {
                                    if (mat == 12518) return 65;
                                } else { // mat >= 12519
                                    if (mat < 12521) {
                                        if (mat == 12520) return 301;
                                    } else { // mat >= 12521
                                        if (mat == 12524) return 2;
                                    }
                                }
                            }
                        } else { // mat >= 12525
                            if (mat < 12528) {
                                if (mat < 12526) {
                                    if (mat == 12525) return 2;
                                } else { // mat >= 12526
                                    if (mat < 12527) {
                                        if (mat == 12526) return 2;
                                    } else { // mat >= 12527
                                        if (mat == 12527) return 2;
                                    }
                                }
                            } else { // mat >= 12528
                                if (mat < 12554) {
                                    if (mat < 12553) {
                                        if (mat == 12552) return 322;
                                    } else { // mat >= 12553
                                        if (mat == 12553) return 322;
                                    }
                                } else { // mat >= 12554
                                    if (mat < 12555) {
                                        if (mat == 12554) return 322;
                                    } else { // mat >= 12555
                                        if (mat == 12555) return 322;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else { // mat >= 12556
            if (mat < 32145) {
                if (mat < 12601) {
                    if (mat < 12578) {
                        if (mat < 12569) {
                            if (mat < 12559) {
                                if (mat < 12557) {
                                    if (mat == 12556) return 40;
                                } else { // mat >= 12557
                                    if (mat < 12558) {
                                        if (mat == 12557) return 40;
                                    } else { // mat >= 12558
                                        if (mat == 12558) return 40;
                                    }
                                }
                            } else { // mat >= 12559
                                if (mat < 12560) {
                                    if (mat == 12559) return 40;
                                } else { // mat >= 12560
                                    if (mat < 12567) {
                                        if (mat == 12566) return 66;
                                    } else { // mat >= 12567
                                        if (mat == 12568) return 36;
                                    }
                                }
                            }
                        } else { // mat >= 12569
                            if (mat < 12575) {
                                if (mat < 12573) {
                                    if (mat == 12572) return 324;
                                } else { // mat >= 12573
                                    if (mat < 12574) {
                                        if (mat == 12573) return 324;
                                    } else { // mat >= 12574
                                        if (mat == 12574) return 324;
                                    }
                                }
                            } else { // mat >= 12575
                                if (mat < 12576) {
                                    if (mat == 12575) return 324;
                                } else { // mat >= 12576
                                    if (mat < 12577) {
                                        if (mat == 12576) return 325;
                                    } else { // mat >= 12577
                                        if (mat == 12577) return 325;
                                    }
                                }
                            }
                        }
                    } else { // mat >= 12578
                        if (mat < 12587) {
                            if (mat < 12581) {
                                if (mat < 12579) {
                                    if (mat == 12578) return 325;
                                } else { // mat >= 12579
                                    if (mat < 12580) {
                                        if (mat == 12579) return 325;
                                    } else { // mat >= 12580
                                        if (mat == 12580) return 326;
                                    }
                                }
                            } else { // mat >= 12581
                                if (mat < 12585) {
                                    if (mat == 12584) return 326;
                                } else { // mat >= 12585
                                    if (mat < 12586) {
                                        if (mat == 12585) return 326;
                                    } else { // mat >= 12586
                                        if (mat == 12586) return 326;
                                    }
                                }
                            }
                        } else { // mat >= 12587
                            if (mat < 12590) {
                                if (mat < 12588) {
                                    if (mat == 12587) return 326;
                                } else { // mat >= 12588
                                    if (mat < 12589) {
                                        if (mat == 12588) return 16;
                                    } else { // mat >= 12589
                                        if (mat == 12589) return 16;
                                    }
                                }
                            } else { // mat >= 12590
                                if (mat < 12591) {
                                    if (mat == 12590) return 16;
                                } else { // mat >= 12591
                                    if (mat < 12592) {
                                        if (mat == 12591) return 16;
                                    } else { // mat >= 12592
                                        if (mat == 12600) return 328;
                                    }
                                }
                            }
                        }
                    }
                } else { // mat >= 12601
                    if (mat < 32133) {
                        if (mat < 12611) {
                            if (mat < 12604) {
                                if (mat < 12602) {
                                    if (mat == 12601) return 328;
                                } else { // mat >= 12602
                                    if (mat < 12603) {
                                        if (mat == 12602) return 328;
                                    } else { // mat >= 12603
                                        if (mat == 12603) return 328;
                                    }
                                }
                            } else { // mat >= 12604
                                if (mat < 12609) {
                                    if (mat == 12608) return 12;
                                } else { // mat >= 12609
                                    if (mat < 12610) {
                                        if (mat == 12609) return 12;
                                    } else { // mat >= 12610
                                        if (mat == 12610) return 12;
                                    }
                                }
                            }
                        } else { // mat >= 12611
                            if (mat < 32130) {
                                if (mat < 12612) {
                                    if (mat == 12611) return 12;
                                } else { // mat >= 12612
                                    if (mat < 32129) {
                                        if (mat == 32128) return 30074;
                                    } else { // mat >= 32129
                                        if (mat == 32129) return 30039;
                                    }
                                }
                            } else { // mat >= 32130
                                if (mat < 32131) {
                                    if (mat == 32130) return 30041;
                                } else { // mat >= 32131
                                    if (mat < 32132) {
                                        if (mat == 32131) return 30074;
                                    } else { // mat >= 32132
                                        if (mat == 32132) return 30059;
                                    }
                                }
                            }
                        }
                    } else { // mat >= 32133
                        if (mat < 32139) {
                            if (mat < 32136) {
                                if (mat < 32134) {
                                    if (mat == 32133) return 30060;
                                } else { // mat >= 32134
                                    if (mat < 32135) {
                                        if (mat == 32134) return 30074;
                                    } else { // mat >= 32135
                                        if (mat == 32135) return 30062;
                                    }
                                }
                            } else { // mat >= 32136
                                if (mat < 32137) {
                                    if (mat == 32136) return 30063;
                                } else { // mat >= 32137
                                    if (mat < 32138) {
                                        if (mat == 32137) return 30064;
                                    } else { // mat >= 32138
                                        if (mat == 32138) return 30065;
                                    }
                                }
                            }
                        } else { // mat >= 32139
                            if (mat < 32142) {
                                if (mat < 32140) {
                                    if (mat == 32139) return 30066;
                                } else { // mat >= 32140
                                    if (mat < 32141) {
                                        if (mat == 32140) return 30067;
                                    } else { // mat >= 32141
                                        if (mat == 32141) return 30074;
                                    }
                                }
                            } else { // mat >= 32142
                                if (mat < 32143) {
                                    if (mat == 32142) return 30069;
                                } else { // mat >= 32143
                                    if (mat < 32144) {
                                        if (mat == 32143) return 30040;
                                    } else { // mat >= 32144
                                        if (mat == 32144) return 30042;
                                    }
                                }
                            }
                        }
                    }
                }
            } else { // mat >= 32145
                if (mat < 32177) {
                    if (mat < 32157) {
                        if (mat < 32151) {
                            if (mat < 32148) {
                                if (mat < 32146) {
                                    if (mat == 32145) return 30072;
                                } else { // mat >= 32146
                                    if (mat < 32147) {
                                        if (mat == 32146) return 30044;
                                    } else { // mat >= 32147
                                        if (mat == 32147) return 30045;
                                    }
                                }
                            } else { // mat >= 32148
                                if (mat < 32149) {
                                    if (mat == 32148) return 30046;
                                } else { // mat >= 32149
                                    if (mat < 32150) {
                                        if (mat == 32149) return 30047;
                                    } else { // mat >= 32150
                                        if (mat == 32150) return 30048;
                                    }
                                }
                            }
                        } else { // mat >= 32151
                            if (mat < 32154) {
                                if (mat < 32152) {
                                    if (mat == 32151) return 30049;
                                } else { // mat >= 32152
                                    if (mat < 32153) {
                                        if (mat == 32152) return 30050;
                                    } else { // mat >= 32153
                                        if (mat == 32153) return 30051;
                                    }
                                }
                            } else { // mat >= 32154
                                if (mat < 32155) {
                                    if (mat == 32154) return 30052;
                                } else { // mat >= 32155
                                    if (mat < 32156) {
                                        if (mat == 32155) return 30053;
                                    } else { // mat >= 32156
                                        if (mat == 32156) return 30054;
                                    }
                                }
                            }
                        }
                    } else { // mat >= 32157
                        if (mat < 32165) {
                            if (mat < 32160) {
                                if (mat < 32158) {
                                    if (mat == 32157) return 30055;
                                } else { // mat >= 32158
                                    if (mat < 32159) {
                                        if (mat == 32158) return 30056;
                                    } else { // mat >= 32159
                                        if (mat == 32159) return 30057;
                                    }
                                }
                            } else { // mat >= 32160
                                if (mat < 32161) {
                                    if (mat == 32160) return 296;
                                } else { // mat >= 32161
                                    if (mat < 32163) {
                                        if (mat == 32162) return 295;
                                    } else { // mat >= 32163
                                        if (mat == 32164) return 299;
                                    }
                                }
                            }
                        } else { // mat >= 32165
                            if (mat < 32171) {
                                if (mat < 32167) {
                                    if (mat == 32166) return 293;
                                } else { // mat >= 32167
                                    if (mat < 32169) {
                                        if (mat == 32168) return 292;
                                    } else { // mat >= 32169
                                        if (mat == 32170) return 294;
                                    }
                                }
                            } else { // mat >= 32171
                                if (mat < 32173) {
                                    if (mat == 32172) return 297;
                                } else { // mat >= 32173
                                    if (mat < 32175) {
                                        if (mat == 32174) return 291;
                                    } else { // mat >= 32175
                                        if (mat == 32176) return 287;
                                    }
                                }
                            }
                        }
                    }
                } else { // mat >= 32177
                    if (mat < 32191) {
                        if (mat < 32183) {
                            if (mat < 32180) {
                                if (mat < 32178) {
                                    if (mat == 32177) return 286;
                                } else { // mat >= 32178
                                    if (mat < 32179) {
                                        if (mat == 32178) return 290;
                                    } else { // mat >= 32179
                                        if (mat == 32179) return 284;
                                    }
                                }
                            } else { // mat >= 32180
                                if (mat < 32181) {
                                    if (mat == 32180) return 283;
                                } else { // mat >= 32181
                                    if (mat < 32182) {
                                        if (mat == 32181) return 285;
                                    } else { // mat >= 32182
                                        if (mat == 32182) return 288;
                                    }
                                }
                            }
                        } else { // mat >= 32183
                            if (mat < 32187) {
                                if (mat < 32184) {
                                    if (mat == 32183) return 282;
                                } else { // mat >= 32184
                                    if (mat < 32185) {
                                        if (mat == 32184) return 298;
                                    } else { // mat >= 32185
                                        if (mat == 32186) return 289;
                                    }
                                }
                            } else { // mat >= 32187
                                if (mat < 32189) {
                                    if (mat == 32188) return 30073;
                                } else { // mat >= 32189
                                    if (mat < 32190) {
                                        if (mat == 32189) return 30073;
                                    } else { // mat >= 32190
                                        if (mat == 32190) return 30073;
                                    }
                                }
                            }
                        }
                    } else { // mat >= 32191
                        if (mat < 32197) {
                            if (mat < 32194) {
                                if (mat < 32192) {
                                    if (mat == 32191) return 30073;
                                } else { // mat >= 32192
                                    if (mat < 32193) {
                                        if (mat == 32192) return 30074;
                                    } else { // mat >= 32193
                                        if (mat == 32193) return 30074;
                                    }
                                }
                            } else { // mat >= 32194
                                if (mat < 32195) {
                                    if (mat == 32194) return 30074;
                                } else { // mat >= 32195
                                    if (mat < 32196) {
                                        if (mat == 32195) return 30074;
                                    } else { // mat >= 32196
                                        if (mat == 32196) return 36;
                                    }
                                }
                            }
                        } else { // mat >= 32197
                            if (mat < 32200) {
                                if (mat < 32198) {
                                    if (mat == 32197) return 36;
                                } else { // mat >= 32198
                                    if (mat < 32199) {
                                        if (mat == 32198) return 36;
                                    } else { // mat >= 32199
                                        if (mat == 32199) return 36;
                                    }
                                }
                            } else { // mat >= 32200
                                if (mat < 32202) {
                                    if (mat < 32201) {
                                        if (mat == 32200) return 327;
                                    } else { // mat >= 32201
                                        if (mat == 32201) return 327;
                                    }
                                } else { // mat >= 32202
                                    if (mat < 32203) {
                                        if (mat == 32202) return 327;
                                    } else { // mat >= 32203
                                        if (mat == 32203) return 327;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (mat < 10604) {
            if (mat < 10396) {
                if (mat < 10300) {
                    if (mat < 10228) {
                        if (mat < 10076) {
                            if (mat == 10056) return  14; // Lava Cauldron
                            if (mat == 10068 || mat == 10070) return  13; // Lava
                            if (mat == 10072) return   5; // Fire
                        } else {
                            if (mat == 10076) return  27; // Soul Fire
                            #if defined GLOWING_NETHER_TREES && defined DO_IPBR_LIGHTS
                            if (mat == 10216) return  62; // Crimson Stem, Crimson Hyphae
                            if (mat == 10224) return  63; // Warped Stem, Warped Hyphae
                            #endif
                        }
                    } else {
                        if (mat < 10276) {
                            if (mat == 10228) return 30055; // Bedrock
                            #if defined GLOWING_ORE_ANCIENTDEBRIS && defined DO_IPBR_LIGHTS
                            if (mat == 10252) return  52; // Ancient Debris
                            #endif
                            #if defined GLOWING_RAW_BLOCKS && defined DO_IPBR_LIGHTS
                            if (mat == 10268) return 43; // Raw Iron Block
                            #endif
                            #if defined GLOWING_ORE_IRON && defined DO_IPBR_LIGHTS
                            if (mat == 10272) return  43; // Iron Ore
                            #endif
                        } else {
                            #if defined GLOWING_ORE_IRON && defined DO_IPBR_LIGHTS
                            if (mat == 10276) return  43; // Deepslate Iron Ore
                            #endif
                            #if defined GLOWING_RAW_BLOCKS && defined DO_IPBR_LIGHTS
                            if (mat == 10280) return 45; // Raw Coper Block
                            #endif
                            #if defined GLOWING_ORE_COPPER && defined DO_IPBR_LIGHTS
                            if (mat == 10284) return  45; // Copper Ore
                            if (mat == 10288) return  45; // Deepslate Copper Ore
                            #endif
                            #if defined GLOWING_RAW_BLOCKS && defined DO_IPBR_LIGHTS
                            if (mat == 10296) return 44; // Raw Gold Block
                            #endif
                        }
                    }
                } else {
                    if (mat < 10340) {
                        if (mat < 10320) {
                            #if defined GLOWING_ORE_GOLD && defined DO_IPBR_LIGHTS
                            if (mat == 10300) return  44; // Gold Ore
                            if (mat == 10302) return  44; // Deepslate Gold Ore
                            #endif
                            #if defined GLOWING_ORE_MODDED && defined DO_IPBR_LIGHTS
                            if (mat == 10304) return  39; // Modded Pink Ore
                            if (mat == 10306) return  36; // Modded Purple Ore
                            #endif
                            #if defined GLOWING_ORE_NETHERGOLD && defined DO_IPBR_LIGHTS
                            if (mat == 10308) return  50; // Nether Gold Ore
                            #endif
                        } else {
                            #if defined GLOWING_ORE_DIAMOND && defined DO_IPBR_LIGHTS
                            if (mat == 10320) return  48; // Diamond Ore
                            if (mat == 10324) return  48; // Deepslate Diamond Ore
                            #endif
                            if (mat == 10332) return  36; // Amethyst Cluster, Amethyst Buds
                            #if defined GLOWING_EMERALD_BLOCK && defined DO_IPBR_LIGHTS
                            if (mat == 10336) return 47; // Emerald Block
                            #endif
                        }
                    } else {
                        if (mat < 10356) {
                            #if defined GLOWING_ORE_EMERALD && defined DO_IPBR_LIGHTS
                            if (mat == 10340) return  47; // Emerald Ore
                            if (mat == 10344) return  47; // Deepslate Emerald Ore
                            #endif
                            #if defined EMISSIVE_LAPIS_BLOCK && defined DO_IPBR_LIGHTS
                            if (mat == 10352) return  42; // Lapis Block
                            #endif
                        } else {
                            #if defined GLOWING_ORE_LAPIS && defined DO_IPBR_LIGHTS
                            if (mat == 10356) return  46; // Lapis Ore
                            if (mat == 10360) return  46; // Deepslate Lapis Ore
                            #endif
                            #if defined GLOWING_ORE_NETHERQUARTZ && defined DO_IPBR_LIGHTS
                            if (mat == 10368) return  49; // Nether Quartz Ore
                            #endif
                        }
                    }
                }
            } else {
                if (mat < 10516) {
                    if (mat < 10476) {
                        if (mat < 10448) {
                            if (mat == 10396) return  11; // Jack o'Lantern
                            if (mat == 10404) return   6; // Sea Pickle:Waterlogged
                            if (mat == 10412) return  10; // Glowstone
                        } else {
                            if (mat == 10448) return  18; // Sea Lantern
                            if (mat == 10452) return  37; // Magma Block
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10456) return  60; // Command Block
                            #endif
                        }
                    } else {
                        if (mat < 10500) {
                            if (mat == 10476) return  26; // Crying Obsidian
                            #if defined GLOWING_ORE_GILDEDBLACKSTONE && defined DO_IPBR_LIGHTS
                            if (mat == 10484) return  51; // Gilded Blackstone
                            #endif
                            if (mat == 10496) return   2; // Torch
                        } else {
                            if (mat == 10500) return   3; // End Rod
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10508) return  39; // Chorus Flower:Alive
                            if (mat == 10512) return  39; // Chorus Flower:Dead
                            #endif
                        }
                    }
                } else {
                    if (mat < 10564) {
                        if (mat < 10548) {
                            if (mat == 10516) return  21; // Furnace:Lit
                            if (mat == 10528) return  28; // Soul Torch
                            if (mat == 10544) return  34; // Glow Lichen
                        } else {
                            if (mat == 10548) return  33; // Enchanting Table
                            if (mat == 10556) return  58; // End Portal Frame:Active
                            if (mat == 10560 || mat == 10562) return  12; // Lantern
                        }
                    } else {
                        if (mat < 10580) {
                            if (mat == 10564) return  29; // Soul Lantern
                            #if defined EMISSIVE_DRAGON_EGG && defined DO_IPBR_LIGHTS
                            if (mat == 10572) return  38; // Dragon Egg
                            #endif
                            if (mat == 10576) return  22; // Smoker:Lit
                        } else {
                            if (mat == 10580) return  23; // Blast Furnace:Lit
                            if (mat == 10592) return  17; // Respawn Anchor:Lit
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10596) return  66; // Redstone Wire:Lit
                            #endif
                        }
                    }
                }
            }
        } else {
            if (mat < 10788) {
                if (mat < 10656) {
                    if (mat < 10632) {
                        if (mat < 10616) {
                            if (mat == 10604) return  35; // Redstone Torch
                            #if defined EMISSIVE_REDSTONE_BLOCK && defined DO_IPBR_LIGHTS
                            if (mat == 10608) return  41; // Redstone Block
                            #endif
                            #if defined GLOWING_ORE_REDSTONE && defined DO_IPBR_LIGHTS
                            if (mat == 10612) return  32; // Redstone Ore:Unlit
                            #endif
                        } else {
                            if (mat == 10616) return  31; // Redstone Ore:Lit
                            #if defined GLOWING_ORE_REDSTONE && defined DO_IPBR_LIGHTS
                            if (mat == 10620) return  32; // Deepslate Redstone Ore:Unlit
                            #endif
                            if (mat == 10624) return  31; // Deepslate Redstone Ore:Lit
                        }
                    } else {
                        if (mat < 10646) {
                            if (mat == 10632) return  20; // Cave Vines:With Glow Berries
                            if (mat == 10640) return  16; // Redstone Lamp:Lit
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10644) return  67; // Repeater:Lit, Comparator:Lit
                            #endif
                        } else {
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10646) return  66; // Comparator:Unlit:Subtract
                            #endif
                            if (mat == 10648) return  19; // Shroomlight
                            if (mat == 10652) return  15; // Campfire:Lit
                        }
                    }
                } else {
                    if (mat < 10704) {
                        if (mat < 10688) {
                            if (mat == 10656) return  30; // Soul Campfire:Lit
                            if (mat == 10680) return   7; // Ochre Froglight
                            if (mat == 10684) return   8; // Verdant Froglight
                        } else {
                            if (mat == 10688) return   9; // Pearlescent Froglight
                            if (mat == 10695 || mat == 10696) return  57; // Sculk, Sculk Catalyst
                            if (mat == 10698) return  57; // Sculk Vein, Sculk Sensor:Unlit
                            if (mat == 10700) return  57; // Sculk Shrieker
                        }
                    } else {
                        if (mat < 10776) {
                            if (mat == 10704) return  57; // Sculk Sensor:Lit
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10708) return  53; // Spawner
                            if (mat == 10736) return  64; // Structure Block, Jigsaw Block, Test Block, Test Instance Block
                            #endif
                        } else {
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10776) return  61; // Warped Fungus, Crimson Fungus
                            if (mat == 10780) return  61; // Potted Warped Fungus, Potted Crimson Fungus
                            #endif
                            if (mat == 10784) return  36; // Calibrated Sculk Sensor:Unlit
                        }
                    }
                }
            } else {
                if (mat < 10980) {
                    if (mat < 10876) {
                        if (mat < 10856) {
                            if (mat == 10788) return  36; // Calibrated Sculk Sensor:Lit
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10836) return  40; // Brewing Stand
                            #endif
                            if (mat == 10852 || mat == 10853) return  55; // Copper Bulb:BrighterOnes:Lit
                        } else {
                            if (mat == 10856 || mat == 10857) return  56; // Copper Bulb:DimmerOnes:Lit
                            if (mat == 10868) return  54; // Trial Spawner:NotOminous:Active, Vault:NotOminous:Active
                            if (mat == 10872) return  68; // Vault:Inactive
                        }
                    } else {
                        if (mat < 10948) {
                            if (mat == 10876) return  69; // Trial Spawner:Ominous:Active, Vault:Ominous:Active
                            #ifdef DO_IPBR_LIGHTS
                            if (mat == 10884) return  65; // Weeping Vines Plant
                            #endif
                            #ifndef COLORED_CANDLE_LIGHT
                            if (mat >= 10900 && mat <= 10922) return 24; // Standard Candles:Lit
                            #else
                            if (mat == 10900) return  24; // Standard Candles:Lit
                            if (mat == 10902) return  70; // Red Candles:Lit
                            if (mat == 10904) return  71; // Orange Candles:Lit
                            if (mat == 10906) return  72; // Yellow Candles:Lit
                            if (mat == 10908) return  73; // Lime Candles:Lit
                            if (mat == 10910) return  74; // Green Candles:Lit
                            if (mat == 10912) return  75; // Cyan Candles:Lit
                            if (mat == 10914) return  76; // Light Blue Candles:Lit
                            if (mat == 10916) return  77; // Blue Candles:Lit
                            if (mat == 10918) return  78; // Purple Candles:Lit
                            if (mat == 10920) return  79; // Magenta Candles:Lit
                            if (mat == 10922) return  80; // Pink Candles:Lit
                            #endif
                        } else {
                            if (mat == 10948) return  82; // Creaking Heart: Active
                            if (mat == 10972) return  83; // Firefly Bush
                            if (mat == 10976) return  81; // Open Eyeblossom
                        }
                    }
                } else {
                    if (mat < 31000) {
                        if (mat < 30012) {
                            if (mat < 21026) {
                                if (mat < 21012) {
                                    if (mat < 21002) {
                                        if (mat == 10980) return 81; // Potted Open Eyeblossom
                                        if (abs(mat - 10986) <= 2) return 84; // Copper Torch, Copper Lantern
                                        if (mat == 21000) return 97; // White Modded Blocks
                                    } else {
                                        if (mat == 21002) return 43; // Brown Modded Blocks
                                        if (mat == 21004) return 70; // Red Modded Blocks
                                        if (mat == 21006) return 71; // Orange Modded Blocks
                                        if (mat == 21008) return 72; // Yellow Modded Blocks
                                        if (mat == 21010) return 73; // Lime Modded Blocks
                                    }
                                } else {
                                    if (mat < 21018) {
                                        if (mat == 21012) return 74; // Green Modded Blocks
                                        if (mat == 21014) return 75; // Cyan Modded Blocks
                                        if (mat == 21016) return 76; // Light Blue Modded Blocks
                                    } else {
                                        if (mat == 21018) return 77; // Blue Modded Blocks
                                        if (mat == 21020) return 78; // Purple Modded Blocks
                                        if (mat == 21022) return 79; // Magenta Modded Blocks
                                        if (mat == 21024) return 80; // Pink Modded Blocks
                                        if (mat == 30008) return 30054; // Tinted Glass
                                    }
                                }
                            } else {
                                if (mat < 21038) {
                                    if (mat < 21032) {
                                        if (mat == 21026) return 97; // White Emissive Blocks
                                        if (mat == 21028) return 43; // Brown Emissive Blocks
                                        if (mat == 21030) return 70; // Red Emissive Blocks
                                    } else {
                                        if (mat == 21032) return 71; // Orange Emissive Blocks
                                        if (mat == 21034) return 72; // Yellow Emissive Blocks
                                        if (mat == 21036) return 73; // Lime Emissive Blocks
                                    }
                                } else {
                                    if (mat < 21044) {
                                        if (mat == 21038) return 74; // Green Emissive Blocks
                                        if (mat == 21040) return 75; // Cyan Emissive Blocks
                                        if (mat == 21042) return 76; // Light Blue Emissive Blocks
                                    } else {
                                        if (mat == 21044) return 77; // Blue Emissive Blocks
                                        if (mat == 21046) return 78; // Purple Emissive Blocks
                                        if (mat == 21048) return 79; // Magenta Emissive Blocks
                                        if (mat == 21050) return 80; // Pink Emissive Blocks
                                    }
                                }
                            }
                        } else {
                            if (mat == 30012) return 30013; // Slime Block
                            if (mat == 30016) return 30001; // Honey Block
                            if (mat == 30020) return  25; // Nether Portal
                        }
                    } else {
                        if (mat < 32008) {
                            if (mat >= 31000 && mat < 32000) return 30000 + (mat - 31000) / 2; // Stained Glass+
                            if (mat == 32004) return 30016; // Ice
                        } else {
                            if (mat == 32008) return 30017; // Glass
                            if (mat == 32012) return 30018; // Glass Pane
                            if (mat == 32016) return   4; // Beacon
                        }
                    }
                }
            }
        }

        return 1; // Standard Block
    }

    #if defined SHADOW && defined VERTEX_SHADER
        void UpdateVoxelMap(int mat) {
            if (mat == 32000 // Water
                || mat < 30000 && mat % 2 == 1 // Non-solid terrain
                || mat < 10000 // Block entities or unknown blocks that we treat as non-solid
                || uint(mat - 10007) <= 5u // Leaves from 10007 to 10012
            ) return;

            vec3 modelPos = gl_Vertex.xyz + at_midBlock.xyz / 64.0;
            vec3 viewPos = transform(gl_ModelViewMatrix, modelPos);
            vec3 scenePos = transform(shadowModelViewInverse, viewPos);
            #ifdef WORLD_CURVATURE
                scenePos.y += doWorldCurvature(scenePos.xz);
            #endif
            vec3 voxelPos = SceneToVoxel(scenePos);

            //#define OPTIMIZATION_ACT_HALF_RATE_VOXELS
            #ifdef OPTIMIZATION_ACT_HALF_RATE_VOXELS
                if (int(framemod2) == 0) {
                    if (scenePos.z > 0.0) return;
                } else {
                    if (scenePos.z < 0.0) return;
                }
            #endif

            #if defined GBUFFERS_COLORWHEEL || defined SHADOW_COLORWHEEL
                bool isEligible = true;
            #else
                bool isEligible = any(equal(ivec4(renderStage), ivec4(
                    MC_RENDER_STAGE_TERRAIN_SOLID,
                    MC_RENDER_STAGE_TERRAIN_TRANSLUCENT,
                    MC_RENDER_STAGE_TERRAIN_CUTOUT,
                    MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED)));
            #endif

            if (isEligible && CheckInsideVoxelVolume(voxelPos)) {
                int voxelData = GetVoxelIDs(mat);

                #if defined GBUFFERS_COLORWHEEL || defined SHADOW_COLORWHEEL
                    voxelData = voxelData | 32768;
                #endif

                imageStore(voxel_img, ivec3(voxelPos), uvec4(voxelData, 0u, 0u, 0u));
            }
        }
    #endif

#endif //INCLUDE_VOXELIZATION
#endif
